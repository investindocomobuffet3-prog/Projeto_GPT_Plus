import { saveToStorage } from '../services/storage.js';
import { renderDashboard } from './dashboard.js';
import { renderCompras, attachComprasCanonicalHandlers } from './compras.js';
import { renderEstoque, attachEstoqueHandlers } from './estoque.js';
import { renderFichas, attachFichasHandlers } from './fichas.js';
import { renderClientes, attachClientesHandlers } from './clientes.js';
import { renderBackup, attachBackupHandlers } from './backup.js';
import { renderGenericPage } from './genericPage.js';
import { renderInsumos, attachInsumosHandlers as attachInsumosMasterHandlers } from './insumos.js';
import { renderFornecedores, attachFornecedoresMasterHandlers } from './fornecedores.js';
import { renderFinanceiro, attachFinanceiroHandlers } from './financeiro.js';
import { renderCartoes, attachCartoesHandlers } from './cartoes.js';

let insumoEditId = null;
let fornecedorEditId = null;
let compraEditId = null;

function page(renderFn, attachFn) {
  return { render: renderFn, attach: attachFn };
}

export function createPages({ data, services }) {
  return {
    dashboard: page(() => renderDashboard(data)),
    compras: page(
      () => renderCompras(
        services.comprasService.list(),
        services.fornecedoresService.list(),
        services.insumosService.listar()
      ),
      () => attachComprasCanonicalHandlers({
        comprasService: services.comprasService,
        fornecedoresService: services.fornecedoresService,
        insumosService: services.insumosService,
        estoqueService: services.estoqueService,
        financeiroService: services.financeiroService,
        rerender: () => window.app.router.render(),
      })
    ),

    estoque: page(
      () => renderEstoque(services.estoqueService,services.insumosService,services.comprasService,services.fornecedoresService),
      () => attachEstoqueHandlers(services.estoqueService,services.insumosService,services.comprasService,services.fornecedoresService,() => window.app.router.render())
    ),
    fichas: page(
      () => renderFichas(services.insumosService, services.estoqueService),
      () => attachFichasHandlers(
        services.insumosService,
        services.estoqueService,
        () => window.app.router.render()
      )
    ),
    producao: page(() => renderGenericPage(data, 'produção')),
    produtos: page(() => renderGenericPage(data, 'produtos')),
    encomendas: page(() => renderGenericPage(data, 'encomendas')),
    clientes: page(
      () => renderClientes(data),
      () => attachClientesHandlers(
        data,
        () => window.app.router.render()
      )
    ),
    vendas: page(() => renderGenericPage(data, 'vendas')),
    relatorios: page(() => renderGenericPage(data, 'relatórios')),
    financeiro: page(
      () => renderFinanceiro(
        services.financeiroService,
        services.comprasService,
        services.fornecedoresService,
        services.cartoesService
      ),
      () => attachFinanceiroHandlers(
        services.financeiroService,
        services.comprasService,
        () => window.app.router.render(),
        services.cartoesService
      )
    ),
    insumos: page(
      () => renderInsumos(
        services.insumosService.listar(),
        services.insumosService.listarTipos()
      ),
      () => attachInsumosMasterHandlers(
        services.insumosService,
        () => window.app.router.render()
      )
    ),
    fornecedores: page(
      () => renderFornecedores(
        services.fornecedoresService
      ),
      () => attachFornecedoresMasterHandlers(
        services.fornecedoresService,
        () => window.app.router.render()
      )
    ),
    cartoes: page(
      () => renderCartoes(services.cartoesService),
      () => attachCartoesHandlers(
        services.cartoesService,
        () => window.app.router.render()
      )
    ),
    backup: page(
      () => renderBackup(data),
      () => attachBackupHandlers(
        data,
        () => window.app.router.render()
      )
    ),
  };
}

function attachInsumosHandlers(services) {
  const form = document.getElementById('insumo-form');
  if (!form) return;

  const cancelButton = document.getElementById('insumo-cancel');

  form.addEventListener('submit', event => {
    event.preventDefault();
    const formData = new FormData(form);
    const payload = {
      nome: formData.get('nome'),
      unidade: formData.get('unidade'),
      quantidade: Number(formData.get('quantidade')),
      custo_unitario: Number(formData.get('custo_unitario')),
      categoria: formData.get('categoria'),
      fornecedorId: formData.get('fornecedorId') || null,
    };

    const insumoId = formData.get('id');
    if (insumoId) {
      services.insumosService.update(insumoId, payload);
      insumoEditId = null;
    } else {
      services.insumosService.create(payload);
    }

    form.reset();
    window.app.router.render();
  });

  if (cancelButton) {
    cancelButton.addEventListener('click', event => {
      event.preventDefault();
      insumoEditId = null;
      window.app.router.render();
    });
  }

  document.querySelectorAll('.edit-insumo').forEach(button => {
    button.addEventListener('click', () => {
      insumoEditId = button.dataset.id;
      window.app.router.render();
    });
  });

  document.querySelectorAll('.delete-insumo').forEach(button => {
    button.addEventListener('click', () => {
      if (!confirm('Remover este insumo?')) {
        return;
      }
      services.insumosService.remove(button.dataset.id);
      insumoEditId = null;
      window.app.router.render();
    });
  });
}

function attachFornecedoresHandlers(services) {
  const form = document.getElementById('fornecedor-form');
  if (!form) return;

  const cancelButton = document.getElementById('fornecedor-cancel');

  form.addEventListener('submit', event => {
    event.preventDefault();
    const formData = new FormData(form);
    const payload = {
      nome: formData.get('nome'),
      contato: formData.get('contato'),
      telefone: formData.get('telefone'),
      email: formData.get('email'),
      endereco: formData.get('endereco'),
    };

    const fornecedorId = formData.get('id');
    if (fornecedorId) {
      services.fornecedoresService.update(fornecedorId, payload);
      fornecedorEditId = null;
    } else {
      services.fornecedoresService.create(payload);
    }

    form.reset();
    window.app.router.render();
  });

  if (cancelButton) {
    cancelButton.addEventListener('click', event => {
      event.preventDefault();
      fornecedorEditId = null;
      window.app.router.render();
    });
  }

  document.querySelectorAll('.edit-fornecedor').forEach(button => {
    button.addEventListener('click', () => {
      fornecedorEditId = button.dataset.id;
      window.app.router.render();
    });
  });

  document.querySelectorAll('.delete-fornecedor').forEach(button => {
    button.addEventListener('click', () => {
      if (!confirm('Remover este fornecedor?')) {
        return;
      }
      services.fornecedoresService.remove(button.dataset.id);
      fornecedorEditId = null;
      window.app.router.render();
    });
  });
}

function attachComprasHandlers(services) {
  const form = document.getElementById('compra-form');

  if (!form) {
    return;
  }

  const cancelButton =
    document.getElementById('compra-cancel');

  const addItemButton =
    document.getElementById('adicionar-item-compra');

  const itemsContainer =
    document.getElementById('compra-itens');

  const template =
    document.getElementById('compra-item-template');

  const totalInput =
    document.getElementById('valor');

  function recalculateTotal() {
    if (!totalInput || !itemsContainer) {
      return;
    }

    let total = 0;

    itemsContainer
      .querySelectorAll('.compra-item-row')
      .forEach(row => {
        const quantidade =
          Number(
            row.querySelector(
              '.compra-item-quantidade'
            )?.value || 0
          );

        const valorUnitario =
          Number(
            row.querySelector(
              '.compra-item-valor'
            )?.value || 0
          );

        if (
          Number.isFinite(quantidade) &&
          Number.isFinite(valorUnitario)
        ) {
          total += quantidade * valorUnitario;
        }
      });

    totalInput.value = total.toFixed(2);
  }

  function collectItems() {
    if (!itemsContainer) {
      return [];
    }

    return Array.from(
      itemsContainer.querySelectorAll(
        '.compra-item-row'
      )
    )
      .map(row => ({
        insumoId:
          row.querySelector(
            '.compra-item-insumo'
          )?.value || null,

        quantidade:
          Number(
            row.querySelector(
              '.compra-item-quantidade'
            )?.value || 0
          ),

        valorUnitario:
          Number(
            row.querySelector(
              '.compra-item-valor'
            )?.value || 0
          ),
      }))
      .filter(item =>
        item.insumoId &&
        Number.isFinite(item.quantidade) &&
        item.quantidade > 0
      );
  }

  if (
    addItemButton &&
    itemsContainer &&
    template
  ) {
    addItemButton.addEventListener(
      'click',
      () => {
        const index =
          itemsContainer
            .querySelectorAll(
              '.compra-item-row'
            )
            .length;

        const html =
          template.innerHTML.replace(
            /__INDEX__/g,
            String(index)
          );

        itemsContainer.insertAdjacentHTML(
          'beforeend',
          html
        );

        recalculateTotal();
      }
    );
  }

  if (itemsContainer) {
    itemsContainer.addEventListener(
      'click',
      event => {
        const button =
          event.target.closest(
            '.remover-item-compra'
          );

        if (!button) {
          return;
        }

        const rows =
          itemsContainer.querySelectorAll(
            '.compra-item-row'
          );

        if (rows.length <= 1) {
          alert(
            'A compra precisa manter pelo menos uma linha de item.'
          );
          return;
        }

        button
          .closest('.compra-item-row')
          ?.remove();

        recalculateTotal();
      }
    );

    itemsContainer.addEventListener(
      'input',
      event => {
        if (
          event.target.matches(
            '.compra-item-quantidade, .compra-item-valor'
          )
        ) {
          recalculateTotal();
        }
      }
    );
  }

  form.addEventListener('submit', event => {
    event.preventDefault();

    const formData = new FormData(form);
    const itens = collectItems();

    if (itens.length === 0) {
      alert(
        'Adicione pelo menos um insumo com quantidade maior que zero.'
      );
      return;
    }

    const ids = itens.map(item => item.insumoId);
    const idsUnicos = new Set(ids);

    if (idsUnicos.size !== ids.length) {
      alert(
        'O mesmo insumo foi informado mais de uma vez. Agrupe a quantidade em uma única linha.'
      );
      return;
    }

    for (const item of itens) {
      if (
        !Number.isFinite(item.valorUnitario) ||
        item.valorUnitario < 0
      ) {
        alert(
          'Informe um valor unitário válido para todos os itens.'
        );
        return;
      }
    }

    const payload = {
      fornecedorId:
        formData.get('fornecedorId') || null,

      data: formData.get('data'),

      itens,
    };

    if (!payload.fornecedorId) {
      alert('Selecione um fornecedor.');
      return;
    }

    if (!payload.data) {
      alert('Informe a data da compra.');
      return;
    }

    const compraId = formData.get('id');

    if (compraId) {
      const atual =
        services.comprasService.getById(
          compraId
        );

      if (
        atual &&
        (
          atual.recebimentoEstoqueId ||
          services.estoqueService
            .compraJaRecebida(compraId)
        )
      ) {
        alert(
          'Desfaça o recebimento antes de editar esta compra.'
        );
        return;
      }

      services.comprasService.update(
        compraId,
        payload
      );

      compraEditId = null;
    } else {
      services.comprasService.create(
        payload
      );
    }

    form.reset();
    window.app.router.render();
  });

  if (cancelButton) {
    cancelButton.addEventListener(
      'click',
      event => {
        event.preventDefault();

        compraEditId = null;
        window.app.router.render();
      }
    );
  }

  document
    .querySelectorAll('.edit-compra')
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          compraEditId =
            button.dataset.id;

          window.app.router.render();
        }
      );
    });

  document
    .querySelectorAll('.delete-compra')
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          const compraId =
            button.dataset.id;

          const compra =
            services.comprasService
              .getById(compraId);

          if (!compra) {
            alert('Compra não encontrada.');
            return;
          }

          if (
            compra.recebimentoEstoqueId ||
            services.estoqueService
              .compraJaRecebida(compraId)
          ) {
            alert(
              'Desfaça o recebimento antes de excluir esta compra.'
            );
            return;
          }

          if (
            !confirm(
              'Remover esta compra?'
            )
          ) {
            return;
          }

          services.comprasService.remove(
            compraId
          );

          compraEditId = null;
          window.app.router.render();
        }
      );
    });

  document
    .querySelectorAll('.receber-compra')
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          const compraId =
            button.dataset.id;

          const compra =
            services.comprasService
              .getById(compraId);

          if (!compra) {
            alert('Compra não encontrada.');
            return;
          }

          if (
            !confirm(
              'Confirmar o recebimento desta compra no estoque? As quantidades dos insumos serão aumentadas.'
            )
          ) {
            return;
          }

          const resultado =
            services.estoqueService
              .receberCompra(compra);

          if (!resultado.sucesso) {
            alert(resultado.erro);
            return;
          }

          const vinculo =
            services.comprasService
              .vincularRecebimentoEstoque(
                compraId,
                resultado.recebimentoId
              );

          if (!vinculo.sucesso) {
            services.estoqueService
              .reverterRecebimentoCompra(
                compraId
              );

            alert(
              'Falha ao vincular a entrada à compra. O estoque foi restaurado automaticamente.'
            );

            return;
          }

          window.app.router.render();
        }
      );
    });

  document
    .querySelectorAll(
      '.desfazer-recebimento-compra'
    )
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          const compraId =
            button.dataset.id;

          if (
            !confirm(
              'Desfazer o recebimento desta compra? As quantidades adicionadas serão retiradas do estoque.'
            )
          ) {
            return;
          }

          const resultado =
            services.estoqueService
              .reverterRecebimentoCompra(
                compraId
              );

          if (!resultado.sucesso) {
            alert(resultado.erro);
            return;
          }

          const desvinculo =
            services.comprasService
              .desvincularRecebimentoEstoque(
                compraId
              );

          if (!desvinculo.sucesso) {
            const compra =
              services.comprasService
                .getById(compraId);

            if (compra) {
              const compensacao =
                services.estoqueService
                  .receberCompra(compra);

              if (compensacao.sucesso) {
                services.comprasService
                  .vincularRecebimentoEstoque(
                    compraId,
                    compensacao.recebimentoId
                  );
              }
            }

            alert(
              'Não foi possível concluir a reversão. O sistema tentou restaurar automaticamente o estado anterior.'
            );

            return;
          }

          window.app.router.render();
        }
      );
    });

  recalculateTotal();
}
