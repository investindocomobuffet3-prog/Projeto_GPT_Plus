const STORAGE_PREFIX = 'oba-';
const LEGACY_STORAGE_KEY = 'oba_doceria_store';

export const STORAGE_COLLECTIONS = [
  'insumos',
  'fornecedores',
  'compras',
  'fichas',
  'producoes',
  'estoque_itens',
  'estoque_mov',
  'montagens',
  'encomendas',
  'vendas',
  'clientes',
  'financeiro',
  'cartoes',
  'movimentacoesEstoque',
];

function markBackupDirty() {
  try {
    if (typeof window._backupDirtyFn === 'function') {
      window._backupDirtyFn();
    }
  } catch {
    // O storage deve continuar funcional mesmo sem o módulo de backup.
  }
}

export const storageProvider = {
  save(collection, value) {
    try {
      window.localStorage.setItem(
        STORAGE_PREFIX + collection,
        JSON.stringify(value),
      );

      markBackupDirty();
    } catch (error) {
      console.error(
        `[LocalStorageProvider] Erro ao salvar ${collection}:`,
        error,
      );

      throw new Error(`Falha ao salvar dados: ${error.message}`);
    }
  },

  get(collection) {
    try {
      const stored = window.localStorage.getItem(
        STORAGE_PREFIX + collection,
      );

      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error(
        `[LocalStorageProvider] Erro ao ler ${collection}:`,
        error,
      );

      return [];
    }
  },

  deleteById(collection, id) {
    const nextValue = this
      .get(collection)
      .filter(item => item.id !== id);

    this.save(collection, nextValue);
  },

  clear(collection) {
    window.localStorage.removeItem(
      STORAGE_PREFIX + collection,
    );
  },

  exists(collection) {
    const value = this.get(collection);
    return value && value.length > 0;
  },

  clearAll() {
    Object.keys(window.localStorage)
      .filter(key => key.startsWith(STORAGE_PREFIX))
      .forEach(key => window.localStorage.removeItem(key));
  },

  getAllKeys() {
    return Object.keys(window.localStorage)
      .filter(key => key.startsWith(STORAGE_PREFIX))
      .map(key => key.replace(STORAGE_PREFIX, ''));
  },

  findById(items, id) {
    if (!items || !Array.isArray(items)) {
      return null;
    }

    const normalizedId = String(id);

    return (
      items.find(item => String(item.id) === normalizedId) ||
      null
    );
  },
};

function readLegacyStore(defaultValue) {
  try {
    const stored = window.localStorage.getItem(
      LEGACY_STORAGE_KEY,
    );

    if (!stored) {
      return { ...defaultValue };
    }

    const parsed = JSON.parse(stored);

    if (!parsed || typeof parsed !== 'object') {
      return { ...defaultValue };
    }

    return {
      ...defaultValue,
      ...parsed,
    };
  } catch (error) {
    console.warn(
      'Erro ao carregar dados do storage legado:',
      error,
    );

    return { ...defaultValue };
  }
}

export function loadFromStorage(defaultValue = {}) {
  const legacyStore = readLegacyStore(defaultValue);

  const result = {
    ...defaultValue,
    ...legacyStore,
  };

  STORAGE_COLLECTIONS.forEach(collection => {
    const physicalKey = STORAGE_PREFIX + collection;
    const hasPublishedStorage =
      window.localStorage.getItem(physicalKey) !== null;

    if (hasPublishedStorage) {
      result[collection] = storageProvider.get(collection);
      return;
    }

    if (Array.isArray(legacyStore[collection])) {
      result[collection] = legacyStore[collection];
    }
  });

  return result;
}

export function saveToStorage(value = {}) {
  STORAGE_COLLECTIONS.forEach(collection => {
    if (!Object.prototype.hasOwnProperty.call(value, collection)) {
      return;
    }

    storageProvider.save(
      collection,
      value[collection],
    );
  });
}