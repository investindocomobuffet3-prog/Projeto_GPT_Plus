import { saveToStorage } from '../services/storage.js';

const BACKUP_HISTORY_KEY = 'oba_backup_history_v2';
const MAX_BACKUPS = 5;

function lerHistorico() {
  try {
    const valor = JSON.parse(localStorage.getItem(BACKUP_HISTORY_KEY) || '[]');
    return Array.isArray(valor) ? valor : [];
  } catch {
    return [];
  }
}

function salvarHistorico(lista) {
  localStorage.setItem(
    BACKUP_HISTORY_KEY,
    JSON.stringify(lista.slice(0, MAX_BACKUPS))
  );
}

function criarPayload(data) {
  return {
    version: '2.0.0',
    timestamp: new Date().toISOString(),
    data,
  };
}

function bytes(payload) {
  return new Blob([JSON.stringify(payload)]).size;
}

function dataHora(value) {
  return new Intl.DateTimeFormat('pt-BR', {
    dateStyle: 'short',
    timeStyle: 'medium',
  }).format(new Date(value));
}

function downloadJson(payload, filename) {
  const blob = new Blob(
    [JSON.stringify(payload, null, 2)],
    { type: 'application/json' }
  );

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function renderBackup() {
  const historico = lerHistorico();

  return `
    <div class="backup-module">
      <div class="mod-header">
        <h2>Backup e Restauração</h2>
      </div>

      <div class="backup-warning">
        <h3><i class="fas fa-triangle-exclamation"></i> Atenção — leia antes de usar</h3>
        <p>
          Os backups automáticos ficam armazenados neste navegador.
          Se você limpar os dados do site, trocar de navegador ou usar outra máquina,
          eles serão apagados.
        </p>
        <p>
          Use o botão <strong>"Criar Backup Agora"</strong> para baixar um arquivo
          <code>.json</code> e guardar em local seguro.
        </p>
      </div>

      <div class="backup-panel modelo-backup-actions">
        <h3>Ações de Backup</h3>

        <div class="backup-how">
          <h4>Como funciona o backup automático</h4>
          <p>✓ Mantém os ${MAX_BACKUPS} backups mais recentes neste navegador</p>
          <p>✓ Cobre os dados carregados pelos módulos da aplicação</p>
          <p>✓ Permite exportar e restaurar um arquivo JSON</p>
        </div>

        <div class="backup-buttons">
          <button type="button" class="btn btn-success" id="btn-criar-backup">
            <i class="fas fa-save"></i> Criar Backup Agora
          </button>

          <button type="button" class="btn btn-info" id="btn-restaurar-arquivo">
            <i class="fas fa-upload"></i> Restaurar de Arquivo
          </button>

          <input
            type="file"
            id="input-upload-backup"
            accept=".json,application/json"
            hidden
          >

          <button type="button" class="btn btn-danger" id="btn-limpar-dados">
            <i class="fas fa-trash"></i> Limpar Todos os Dados
          </button>
        </div>
      </div>

      <div class="backup-list">
        <h3>
          <i class="fas fa-history"></i>
          Backups Disponíveis (${historico.length} válidos)
        </h3>

        ${
          historico.length
            ? historico.map((item, index) => `
                <div class="backup-item">
                  <div class="backup-info">
                    <div class="date">
                      <i class="fas fa-calendar"></i>
                      ${dataHora(item.timestamp)}
                    </div>
                    <div class="details">
                      Versão ${item.version || '2.0.0'} •
                      ${(bytes(item) / 1024).toFixed(2)} KB
                    </div>
                  </div>

                  <div class="backup-actions-item">
                    <button type="button" class="btn btn-sm btn-info backup-download" data-index="${index}">
                      <i class="fas fa-download"></i> Download
                    </button>

                    <button type="button" class="btn btn-sm btn-success backup-restore" data-index="${index}">
                      <i class="fas fa-undo"></i> Restaurar
                    </button>

                    <button type="button" class="btn btn-sm btn-danger backup-delete" data-index="${index}">
                      <i class="fas fa-trash"></i>
                    </button>
                  </div>
                </div>
              `).join('')
            : '<p class="text-muted modelo-empty">Nenhum backup local disponível.</p>'
        }
      </div>
    </div>
  `;
}

export function attachBackupHandlers(data, rerender) {
  const criar = () => {
    const payload = criarPayload(data);
    const historico = [payload, ...lerHistorico()].slice(0, MAX_BACKUPS);
    salvarHistorico(historico);
    downloadJson(payload, `oba-doceria-backup-${new Date().toISOString().slice(0, 10)}.json`);
    rerender();
  };

  document.getElementById('btn-criar-backup')?.addEventListener('click', criar);

  const input = document.getElementById('input-upload-backup');

  document.getElementById('btn-restaurar-arquivo')?.addEventListener('click', () => {
    input?.click();
  });

  input?.addEventListener('change', async () => {
    const file = input.files?.[0];
    if (!file) return;

    try {
      const payload = JSON.parse(await file.text());
      const nextData = payload?.data || payload;

      if (!nextData || typeof nextData !== 'object') {
        throw new Error('Formato inválido');
      }

      if (!confirm('Restaurar este backup? Os dados atuais serão substituídos.')) {
        return;
      }

      saveToStorage(nextData);
      window.location.reload();
    } catch (error) {
      console.error(error);
      alert('Arquivo de backup inválido.');
    }
  });

  document.getElementById('btn-limpar-dados')?.addEventListener('click', () => {
    if (!confirm('Limpar todos os dados locais da aplicação?')) return;
    if (!confirm('Esta ação é destrutiva. Confirma novamente?')) return;

    localStorage.clear();
    window.location.reload();
  });

  document.querySelectorAll('.backup-download').forEach(button => {
    button.addEventListener('click', () => {
      const item = lerHistorico()[Number(button.dataset.index)];
      if (!item) return;
      downloadJson(item, `oba-doceria-backup-${item.timestamp.replaceAll(':', '-')}.json`);
    });
  });

  document.querySelectorAll('.backup-restore').forEach(button => {
    button.addEventListener('click', () => {
      const item = lerHistorico()[Number(button.dataset.index)];
      if (!item) return;
      if (!confirm('Restaurar este backup local?')) return;

      saveToStorage(item.data || {});
      window.location.reload();
    });
  });

  document.querySelectorAll('.backup-delete').forEach(button => {
    button.addEventListener('click', () => {
      const index = Number(button.dataset.index);
      const historico = lerHistorico();
      historico.splice(index, 1);
      salvarHistorico(historico);
      rerender();
    });
  });
}
