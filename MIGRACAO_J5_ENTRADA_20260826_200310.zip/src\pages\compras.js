let formAberto = false;
let editandoId = null;
let itensTemporarios = [];
let itemEditandoIndex = null;

function esc(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function money(value) {
  return Number(value || 0).toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
}

function number(value, casas = 3) {
  const n = Number(value || 0);

  return n.toLocaleString('pt-BR', {
    minimumFractionDigits: 0,
    maximumFractionDigits: casas,
  });
}

function dateBr(value) {
  if (!value) return '-';

  const [ano, mes, dia] = String(value).split('-');

  if (!ano || !mes || !dia) {
    return String(value);
  }

  return `${dia}/${mes}/${ano}`;
}

function hojeISO() {
  const agora = new Date();
  const local = new Date(
    agora.getTime() -
    agora.getTimezoneOffset() * 60000
  );

  return local.toISOString().slice(0, 10);
}

function fornecedorPorId(fornecedores, id) {
  return fornecedores.find(
    item => String(item.id) === String(id)
  ) || null;
}

function insumoPorId(insumos, id) {
  return insumos.find(
    item => String(item.id) === String(id)
  ) || null;
}

function formaPagamentoLabel(value) {
  if (value === 'a_vista') return 'À vista';
  if (value === 'a_prazo') return 'A prazo';
  return value || '-';
}

function totalItens(itens = []) {
  return itens.reduce(
    (total, item) =>
      total + Number(item.subtotal || 0),
    0
  );
}

function economiaCompra(compra) {
  return (compra?.itens || []).reduce(
    (total, item) =>
      total + Number(item.descontoValor || 0),
    0
  );
}

function normalizarItemParaEdicao(item = {}) {
  return {
    ...item,
    quantidade: Number(item.quantidade || 0),
    precoUnitario: Number(item.precoUnitario || 0),
    precoUnitarioLiquido:
      Number(
        item.precoUnitarioLiquido ??
        item.precoUnitario ??
        0
      ),
    descontoValor:
      Number(item.descontoValor || 0),
    subtotal:
      Number(item.subtotal || 0),
    qtdEmbalagens:
      Number(item.qtdEmbalagens || 0),
    precoEmbalagem:
      Number(item.precoEmbalagem || 0),
  };
}

export function renderCompras(
  compras = [],
  fornecedores = [],
  insumos = []
) {
  const compraEditando =
    editandoId
      ? compras.find(
          item =>
            String(item.id) ===
            String(editandoId)
        ) || null
      : null;

  const mostrarForm =
    formAberto || Boolean(compraEditando);

  return `
    <section class="page-content compras-master">

      ${stylesCompras()}

      <div class="cmp-header">
        <div>
          <h2>Compras</h2>
          <p class="page-description">
            Compras de insumos integradas ao estoque e financeiro.
          </p>
        </div>

        <div class="cmp-header-actions">
          <div class="cmp-export-wrap">
            <button
              type="button"
              id="cmp-exportar"
              class="btn btn-secondary"
            >
              ⇩ Exportar
            </button>

            <div
              id="cmp-export-menu"
              class="cmp-export-menu"
              hidden
            >
              <button
                type="button"
                data-export="csv"
              >
                CSV
              </button>

              <button
                type="button"
                data-export="pdf"
              >
                PDF / Imprimir
              </button>
            </div>
          </div>

          <button
            type="button"
            id="cmp-nova-compra"
            class="btn btn-primary"
          >
            + Nova Compra
          </button>
        </div>
      </div>

      ${
        mostrarForm
          ? renderFormulario(
              compraEditando,
              fornecedores,
              insumos
            )
          : ''
      }

      ${renderLista(
        compras,
        fornecedores
      )}

      ${renderModalFornecedor()}
      ${renderModalInsumo()}
      ${renderModalVisualizar()}
      ${renderModalConfirmacao()}

    </section>
  `;
}

function renderFormulario(
  compra,
  fornecedores,
  insumos
) {
  const fornecedorId =
    compra?.fornecedorId || '';

  const data =
    compra?.data || hojeISO();

  const formaPagamento =
    compra?.formaPagamento || '';

  const observacoes =
    compra?.observacoes || '';

  return `
    <section class="card cmp-form-card">

      <div class="cmp-section-title">
        ${compra ? 'Editar Compra' : 'Nova Compra'}
      </div>

      ${
        compra &&
        compra.status !== 'pendente'
          ? `
            <div class="info-box">
              Esta compra já foi recebida.
              Estorne o recebimento antes de editar.
            </div>
          `
          : ''
      }

      <form id="cmp-form">

        <input
          type="hidden"
          id="cmp-id"
          value="${esc(compra?.id || '')}"
        />

        <div class="form-group">
          <label>
            Fornecedor *
            <button
              type="button"
              id="cmp-novo-fornecedor-link"
              class="cmp-link-button"
            >
              + Novo fornecedor
            </button>
          </label>

          <select
            id="cmp-fornecedor"
            class="form-control"
            ${compra && compra.status !== 'pendente' ? 'disabled' : ''}
          >
            <option value="">
              Selecione...
            </option>

            <option value="__novo__">
              + Novo fornecedor...
            </option>

            ${
              [...fornecedores]
                .sort((a, b) =>
                  String(a.nome || '').localeCompare(
                    String(b.nome || ''),
                    'pt-BR'
                  )
                )
                .map(item => `
                  <option
                    value="${esc(item.id)}"
                    ${
                      String(item.id) ===
                      String(fornecedorId)
                        ? 'selected'
                        : ''
                    }
                  >
                    ${esc(item.nome)}
                  </option>
                `)
                .join('')
            }
          </select>
        </div>

        <div class="cmp-form-grid">
          <div class="form-group">
            <label>Data *</label>

            <input
              type="date"
              id="cmp-data"
              class="form-control"
              value="${esc(data)}"
              ${compra && compra.status !== 'pendente' ? 'disabled' : ''}
            />
          </div>

          <div class="form-group">
            <label>Condição de pagamento *</label>

            <select
              id="cmp-forma-pagamento"
              class="form-control"
              ${compra && compra.status !== 'pendente' ? 'disabled' : ''}
            >
              <option value="">
                Selecione...
              </option>

              <option
                value="a_vista"
                ${formaPagamento === 'a_vista' ? 'selected' : ''}
              >
                À vista
              </option>

              <option
                value="a_prazo"
                ${formaPagamento === 'a_prazo' ? 'selected' : ''}
              >
                A prazo
              </option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label>Observações</label>

          <textarea
            id="cmp-observacoes"
            class="form-control"
            rows="2"
            ${compra && compra.status !== 'pendente' ? 'disabled' : ''}
          >${esc(observacoes)}</textarea>
        </div>

        <hr />

        <h4>Itens da Compra</h4>

        ${
          compra && compra.status !== 'pendente'
            ? renderItensTemporarios(
                compra.itens || [],
                insumos,
                true
              )
            : `
              <div class="cmp-item-select-line">

                <select
                  id="cmp-item-insumo"
                  class="form-control"
                >
                  <option value="">
                    Selecione insumo...
                  </option>

                  ${
                    [...insumos]
                      .sort((a, b) =>
                        String(a.nome || '').localeCompare(
                          String(b.nome || ''),
                          'pt-BR'
                        )
                      )
                      .map(item => `
                        <option
                          value="${esc(item.id)}"
                        >
                          ${esc(item.nome)}
                          ${item.marca ? ` - ${esc(item.marca)}` : ''}
                          (${esc(item.unidade || 'un')})
                        </option>
                      `)
                      .join('')
                  }
                </select>

                <button
                  type="button"
                  id="cmp-novo-insumo"
                  class="btn btn-secondary"
                >
                  + Novo
                </button>

                <button
                  type="button"
                  id="cmp-editar-insumo"
                  class="btn btn-secondary"
                  disabled
                >
                  Editar
                </button>
              </div>

              <div
                id="cmp-bloco-entrada"
                class="cmp-entry-card"
              >
                ${renderBlocoEntrada(null)}
              </div>

              <div class="cmp-add-item-row">
                <button
                  type="button"
                  id="cmp-adicionar-item"
                  class="btn btn-secondary"
                >
                  + Adicionar Item
                </button>
              </div>

              <div id="cmp-itens-lista">
                ${renderItensTemporarios(
                  itensTemporarios,
                  insumos
                )}
              </div>
            `
        }

        <div class="cmp-total">
          <strong>
            Total:
            <span id="cmp-total">
              ${money(
                compra && compra.status !== 'pendente'
                  ? Number(compra.total || 0)
                  : totalItens(itensTemporarios)
              )}
            </span>
          </strong>
        </div>

        <div class="form-actions">

          ${
            !compra ||
            compra.status === 'pendente'
              ? `
                <button
                  type="submit"
                  class="btn btn-primary"
                >
                  Salvar
                </button>
              `
              : ''
          }

          <button
            type="button"
            id="cmp-cancelar"
            class="btn btn-secondary"
          >
            Cancelar
          </button>

        </div>
      </form>
    </section>
  `;
}

function renderBlocoEntrada(insumo) {
  if (!insumo) {
    return `
      <div class="cmp-entry-grid">

        <div class="form-group">
          <label>Quantidade</label>
          <input
            type="number"
            id="cmp-item-quantidade"
            class="form-control"
            min="0"
            step="0.01"
            placeholder="0"
          />
        </div>

        <div class="form-group">
          <label>Preço unitário</label>
          <input
            type="number"
            id="cmp-item-preco"
            class="form-control"
            min="0"
            step="0.000001"
            placeholder="0,00"
          />
        </div>

        <div class="form-group">
          <label>Desconto (R$)</label>
          <input
            type="number"
            id="cmp-item-desconto"
            class="form-control"
            min="0"
            step="0.01"
            value="0"
          />
        </div>

        <div class="form-group">
          <label>Unit. líquido</label>
          <input
            type="text"
            id="cmp-item-liquido"
            class="form-control"
            readonly
          />
        </div>

        <div class="form-group">
          <label>Subtotal</label>
          <input
            type="text"
            id="cmp-item-subtotal"
            class="form-control"
            readonly
          />
        </div>
      </div>
    `;
  }

  const unidade =
    insumo.unidade || 'un';

  const qtdPorEmbalagem =
    Number(insumo.qtdPorEmbalagem || 0);

  const embalagem =
    insumo.nomeEmbalagem ||
    'embalagem';

  const qtdOpcoes = [];

  if (qtdPorEmbalagem > 0) {
    qtdOpcoes.push({
      id: 'emb',
      label: embalagem,
    });
  }

  if (unidade === 'g') {
    qtdOpcoes.push({
      id: 'kg',
      label: 'kg',
    });
  }

  if (unidade === 'ml') {
    qtdOpcoes.push({
      id: 'kg',
      label: 'L',
    });
  }

  qtdOpcoes.push({
    id: 'base',
    label: unidade,
  });

  const modoPadrao =
    qtdPorEmbalagem > 0
      ? 'emb'
      : (
          unidade === 'g' ||
          unidade === 'ml'
            ? 'kg'
            : 'base'
        );

  return `
    <div
      class="cmp-entry-meta"
      data-unidade="${esc(unidade)}"
      data-qtd-emb="${qtdPorEmbalagem}"
    >
      ${
        qtdPorEmbalagem > 0
          ? `
            1 ${esc(embalagem)}
            = ${number(qtdPorEmbalagem)}
            ${esc(unidade)}
          `
          : `
            Unidade-base:
            ${esc(unidade)}
          `
      }
    </div>

    <div class="cmp-entry-grid">

      <div class="form-group">
        <label>Quantidade</label>

        <select
          id="cmp-qtd-modo"
          class="form-control cmp-mode-select"
        >
          ${
            qtdOpcoes.map(opcao => `
              <option
                value="${opcao.id}"
                ${opcao.id === modoPadrao ? 'selected' : ''}
              >
                ${esc(opcao.label)}
              </option>
            `).join('')
          }
        </select>

        <input
          type="number"
          id="cmp-item-quantidade"
          class="form-control"
          min="0"
          step="${modoPadrao === 'emb' ? '1' : '0.01'}"
          placeholder="0"
        />
      </div>

      <div class="form-group">
        <label>Preço unitário</label>

        <select
          id="cmp-preco-modo"
          class="form-control cmp-mode-select"
        >
          ${
            qtdOpcoes.map(opcao => `
              <option
                value="${opcao.id}"
                ${opcao.id === modoPadrao ? 'selected' : ''}
              >
                ${
                  opcao.id === 'emb'
                    ? `R$/${esc(embalagem)}`
                    : opcao.id === 'kg'
                      ? `R$/${unidade === 'g' ? 'kg' : 'L'}`
                      : `R$/${esc(unidade)}`
                }
              </option>
            `).join('')
          }
        </select>

        <input
          type="number"
          id="cmp-item-preco"
          class="form-control"
          min="0"
          step="0.000001"
          placeholder="0,00"
        />
      </div>

      <div class="form-group">
        <label>Desconto (R$)</label>

        <input
          type="number"
          id="cmp-item-desconto"
          class="form-control"
          min="0"
          step="0.01"
          value="0"
        />
      </div>

      <div class="form-group">
        <label>Unit. líquido</label>

        <input
          type="text"
          id="cmp-item-liquido"
          class="form-control"
          readonly
        />
      </div>

      <div class="form-group">
        <label>Subtotal</label>

        <input
          type="text"
          id="cmp-item-subtotal"
          class="form-control"
          readonly
        />
      </div>

    </div>

    <div
      id="cmp-preview"
      class="cmp-preview"
    ></div>
  `;
}

function renderItensTemporarios(
  itens,
  insumos,
  bloqueada = false
) {
  if (!itens.length) {
    return `
      <p class="text-muted">
        Nenhum item adicionado
      </p>
    `;
  }

  return `
    <div class="table-container cmp-items-table">
      <table class="table">

        <thead>
          <tr>
            <th>Insumo</th>
            <th>Qtd</th>
            <th>Preço Unit.</th>
            <th>Desconto</th>
            <th>Unit. Líquido</th>
            <th>Subtotal</th>
            ${
              bloqueada
                ? ''
                : '<th>Ações</th>'
            }
          </tr>
        </thead>

        <tbody>
          ${
            itens.map((item, index) => {
              const insumo =
                insumoPorId(
                  insumos,
                  item.insumoId
                );

              const unidade =
                insumo?.unidade || '';

              return `
                <tr>
                  <td>
                    ${esc(insumo?.nome || item.insumoNome || 'Insumo')}
                    ${
                      insumo?.marca
                        ? `<div class="cmp-muted">${esc(insumo.marca)}</div>`
                        : ''
                    }
                  </td>

                  <td>
                    ${number(item.quantidade)}
                    ${esc(unidade)}
                  </td>

                  <td>
                    ${money(item.precoUnitario)}
                  </td>

                  <td>
                    ${
                      Number(item.descontoValor || 0) > 0
                        ? money(item.descontoValor)
                        : '--'
                    }
                  </td>

                  <td>
                    ${money(
                      item.precoUnitarioLiquido ??
                      item.precoUnitario ??
                      0
                    )}
                  </td>

                  <td>
                    ${money(item.subtotal)}
                  </td>

                  ${
                    bloqueada
                      ? ''
                      : `
                        <td class="cmp-actions">
                          <button
                            type="button"
                            class="btn btn-secondary cmp-editar-item"
                            data-index="${index}"
                          >
                            Editar
                          </button>

                          <button
                            type="button"
                            class="btn btn-danger cmp-remover-item"
                            data-index="${index}"
                          >
                            Remover
                          </button>
                        </td>
                      `
                  }
                </tr>
              `;
            }).join('')
          }
        </tbody>

      </table>
    </div>
  `;
}

function renderLista(
  compras,
  fornecedores
) {
  if (!compras.length) {
    return `
      <section class="card">
        <p class="text-muted">
          Nenhuma compra registrada
        </p>
      </section>
    `;
  }

  const ordenadas =
    [...compras].sort(
      (a, b) =>
        new Date(b.data || 0) -
        new Date(a.data || 0)
    );

  return `
    <section class="card cmp-list-card">

      <div class="table-container">
        <table class="table">

          <thead>
            <tr>
              <th>Data</th>
              <th>Fornecedor</th>
              <th>Itens</th>
              <th>Total</th>
              <th>Economia</th>
              <th>Pagamento</th>
              <th>Financeiro</th>
              <th>Status</th>
              <th>Ações</th>
            </tr>
          </thead>

          <tbody>
            ${
              ordenadas.map(compra => {
                const fornecedor =
                  fornecedorPorId(
                    fornecedores,
                    compra.fornecedorId
                  );

                const status =
                  compra.status || 'pendente';

                return `
                  <tr>

                    <td>${dateBr(compra.data)}</td>

                    <td>
                      ${esc(fornecedor?.nome || 'N/A')}
                    </td>

                    <td>
                      ${(compra.itens || []).length}
                    </td>

                    <td>
                      ${money(compra.total)}
                    </td>

                    <td>
                      ${
                        economiaCompra(compra) > 0
                          ? `-${money(economiaCompra(compra))}`
                          : '--'
                      }
                    </td>

                    <td>
                      ${esc(
                        formaPagamentoLabel(
                          compra.formaPagamento
                        )
                      )}
                    </td>

                    <td>
                      ${
                        compra.lancamentoFinanceiroId
                          ? '<span class="cmp-badge ok">Lançado</span>'
                          : '<span class="cmp-badge neutral">Pendente</span>'
                      }
                    </td>

                    <td>
                      <span class="cmp-badge ${esc(status)}">
                        ${esc(status)}
                      </span>
                    </td>

                    <td class="cmp-actions">

                      <button
                        type="button"
                        class="btn btn-secondary cmp-ver"
                        data-id="${esc(compra.id)}"
                      >
                        Ver
                      </button>

                      ${
                        compra.lancamentoFinanceiroId
                          ? `
                            <button
                              type="button"
                              class="btn btn-secondary cmp-ir-financeiro"
                              data-id="${esc(compra.id)}"
                            >
                              Financeiro
                            </button>
                          `
                          : `
                            <button
                              type="button"
                              class="btn btn-secondary cmp-lancar-financeiro"
                              data-id="${esc(compra.id)}"
                            >
                              $ Financeiro
                            </button>
                          `
                      }

                      ${
                        status === 'pendente'
                          ? `
                            <button
                              type="button"
                              class="btn btn-secondary cmp-editar"
                              data-id="${esc(compra.id)}"
                            >
                              Editar
                            </button>

                            <button
                              type="button"
                              class="btn btn-primary cmp-receber"
                              data-id="${esc(compra.id)}"
                            >
                              Receber
                            </button>

                            <button
                              type="button"
                              class="btn btn-danger cmp-excluir"
                              data-id="${esc(compra.id)}"
                            >
                              Excluir
                            </button>
                          `
                          : ''
                      }

                      ${
                        status === 'recebida'
                          ? `
                            <button
                              type="button"
                              class="btn btn-secondary cmp-estornar"
                              data-id="${esc(compra.id)}"
                            >
                              Estornar
                            </button>
                          `
                          : ''
                      }

                    </td>
                  </tr>
                `;
              }).join('')
            }
          </tbody>

        </table>
      </div>
    </section>
  `;
}

function renderModalFornecedor() {
  return `
    <div
      id="cmp-modal-fornecedor"
      class="cmp-modal-overlay"
      hidden
    >
      <div class="cmp-modal">

        <div class="cmp-modal-header">
          <h3>Cadastrar Novo Fornecedor</h3>

          <button
            type="button"
            id="cmp-mf-x"
            class="cmp-modal-x"
          >
            ×
          </button>
        </div>

        <div class="cmp-modal-body">

          <div class="cmp-form-grid">
            <div class="form-group">
              <label>Nome *</label>
              <input
                id="cmp-mf-nome"
                class="form-control"
                placeholder="Razão social ou nome"
              />
            </div>

            <div class="form-group">
              <label>CNPJ / CPF *</label>
              <input
                id="cmp-mf-cnpj"
                class="form-control"
              />
            </div>
          </div>

          <div class="cmp-form-grid">
            <div class="form-group">
              <label>Contato</label>
              <input
                id="cmp-mf-contato"
                class="form-control"
                placeholder="Nome do contato"
              />
            </div>

            <div class="form-group">
              <label>Telefone</label>
              <input
                id="cmp-mf-telefone"
                class="form-control"
              />
            </div>
          </div>

          <div class="form-group">
            <label>Email</label>
            <input
              id="cmp-mf-email"
              type="email"
              class="form-control"
                placeholder="email@fornecedor.com"
              />
          </div>

          <div class="form-group">
            <label>Endereço</label>
            <input
              id="cmp-mf-endereco"
              class="form-control"
                placeholder="Rua, número, cidade..."
              />
          </div>

          <div class="form-group">
            <label>Observações</label>
            <textarea
              id="cmp-mf-obs"
              class="form-control"
              rows="2"
            ></textarea>
          </div>

        </div>

        <div class="cmp-modal-footer">
          <button
            type="button"
            id="cmp-mf-cancelar"
            class="btn btn-secondary"
          >
            Cancelar
          </button>

          <button
            type="button"
            id="cmp-mf-salvar"
            class="btn btn-primary"
          >
            Salvar Fornecedor
          </button>
        </div>

      </div>
    </div>
  `;
}

function renderModalInsumo() {
  return `
    <div
      id="cmp-modal-insumo"
      class="cmp-modal-overlay"
      hidden
    >
      <div class="cmp-modal">

        <div class="cmp-modal-header">
          <h3 id="cmp-mi-titulo">
            Cadastrar Novo Insumo
          </h3>

          <button
            type="button"
            id="cmp-mi-x"
            class="cmp-modal-x"
          >
            ×
          </button>
        </div>

        <div class="cmp-modal-body">

          <input
            type="hidden"
            id="cmp-mi-id"
          />

          <div class="cmp-form-grid">
            <div class="form-group">
              <label>Nome *</label>
              <input
                id="cmp-mi-nome"
                class="form-control"
                placeholder="Ex: Leite Condensado"
              />
            </div>

            <div class="form-group">
              <label>Marca *</label>
              <input
                id="cmp-mi-marca"
                class="form-control"
                placeholder="Ex: Italac"
              />
            </div>
          </div>

          <div class="cmp-form-grid">
            <div class="form-group">
              <label>Tipo *</label>

              <div class="cmp-inline">
                <select
                  id="cmp-mi-tipo"
                  class="form-control"
                ></select>

                <button
                  type="button"
                  id="cmp-mi-novo-tipo"
                  class="btn btn-secondary"
                >
                  + Tipo
                </button>
              </div>
            </div>

            <div class="form-group">
              <label>Unidade *</label>

              <select
                id="cmp-mi-unidade"
                class="form-control"
              >
                <option value="">
                  Selecione...
                </option>

                <option value="g">g (gramas)</option>
                <option value="kg">kg (quilogramas)</option>
                <option value="ml">ml (mililitros)</option>
                <option value="L">L (litros)</option>
                <option value="un">un (unidades)</option>
              </select>
            </div>
          </div>

          <div class="cmp-form-grid">

            <div class="form-group">
              <label>Conteúdo da embalagem</label>
              <input
                type="number"
                id="cmp-mi-qtd-emb"
                class="form-control"
                min="0"
                step="0.01"
              />
            </div>

            <div class="form-group">
              <label>Embalagem</label>

              <div class="cmp-inline">
                <select
                  id="cmp-mi-embalagem"
                  class="form-control"
                ></select>

                <button
                  type="button"
                  id="cmp-mi-nova-embalagem"
                  class="btn btn-secondary"
                >
                  + Embalagem
                </button>
              </div>
            </div>

          </div>

          <div class="form-group">
            <label>Mínimo desejado</label>
            <input
              type="number"
              id="cmp-mi-minimo"
              class="form-control"
              min="0"
              step="0.01"
            />
          </div>

          <div class="form-group">
            <label>Observações</label>
            <textarea
              id="cmp-mi-obs"
              class="form-control"
              rows="2"
            ></textarea>
          </div>

        </div>

        <div class="cmp-modal-footer">
          <button
            type="button"
            id="cmp-mi-cancelar"
            class="btn btn-secondary"
          >
            Cancelar
          </button>

          <button
            type="button"
            id="cmp-mi-salvar"
            class="btn btn-primary"
          >
            Salvar Insumo
          </button>
        </div>

      </div>
    </div>
  `;
}

function renderModalVisualizar() {
  return `
    <div
      id="cmp-modal-ver"
      class="cmp-modal-overlay"
      hidden
    >
      <div class="cmp-modal cmp-modal-large">

        <div class="cmp-modal-header">
          <h3>Detalhes da Compra</h3>

          <button
            type="button"
            id="cmp-ver-x"
            class="cmp-modal-x"
          >
            ×
          </button>
        </div>

        <div
          id="cmp-ver-conteudo"
          class="cmp-modal-body"
        ></div>

        <div class="cmp-modal-footer">
          <button
            type="button"
            id="cmp-ver-fechar"
            class="btn btn-primary"
          >
            Fechar
          </button>
        </div>

      </div>
    </div>
  `;
}

function renderModalConfirmacao() {
  return `
    <div
      id="cmp-modal-confirmar"
      class="cmp-modal-overlay"
      hidden
    >
      <div class="cmp-modal cmp-modal-small">

        <div class="cmp-modal-header">
          <h3 id="cmp-confirmar-titulo">
            Confirmar
          </h3>
        </div>

        <div
          id="cmp-confirmar-texto"
          class="cmp-modal-body"
        ></div>

        <div class="cmp-modal-footer">
          <button
            type="button"
            id="cmp-confirmar-cancelar"
            class="btn btn-secondary"
          >
            Cancelar
          </button>

          <button
            type="button"
            id="cmp-confirmar-ok"
            class="btn btn-primary"
          >
            Confirmar
          </button>
        </div>

      </div>
    </div>
  `;
}

export function attachComprasCanonicalHandlers({
  comprasService,
  fornecedoresService,
  insumosService,
  estoqueService,
  financeiroService,
  rerender,
}) {
  const refresh = () => {
    rerender();
  };

  const on = (
    id,
    event,
    handler
  ) => {
    document
      .getElementById(id)
      ?.addEventListener(
        event,
        handler
      );
  };

  function abrirModal(id) {
    const modal =
      document.getElementById(id);

    if (modal) {
      modal.hidden = false;
      modal.style.display = 'flex';
    }
  }

  function fecharModal(id) {
    const modal =
      document.getElementById(id);

    if (modal) {
      modal.hidden = true;
      modal.style.display = 'none';
    }
  }

  function confirmar({
    titulo = 'Confirmar',
    texto = '',
    botao = 'Confirmar',
    aoConfirmar,
  }) {
    const modal =
      document.getElementById(
        'cmp-modal-confirmar'
      );

    const tituloEl =
      document.getElementById(
        'cmp-confirmar-titulo'
      );

    const textoEl =
      document.getElementById(
        'cmp-confirmar-texto'
      );

    const cancelar =
      document.getElementById(
        'cmp-confirmar-cancelar'
      );

    const ok =
      document.getElementById(
        'cmp-confirmar-ok'
      );

    if (
      !modal ||
      !tituloEl ||
      !textoEl ||
      !cancelar ||
      !ok
    ) {
      return;
    }

    tituloEl.textContent = titulo;
    textoEl.textContent = texto;
    ok.textContent = botao;

    cancelar.onclick = () => {
      fecharModal(
        'cmp-modal-confirmar'
      );
    };

    ok.onclick = () => {
      fecharModal(
        'cmp-modal-confirmar'
      );

      aoConfirmar?.();
    };

    abrirModal(
      'cmp-modal-confirmar'
    );
  }

  function atualizarTotal() {
    const total =
      document.getElementById(
        'cmp-total'
      );

    if (total) {
      total.textContent =
        money(
          totalItens(
            itensTemporarios
          )
        );
    }
  }

  function renderizarItensAtual() {
    const container =
      document.getElementById(
        'cmp-itens-lista'
      );

    if (!container) return;

    container.innerHTML =
      renderItensTemporarios(
        itensTemporarios,
        insumosService.listar()
      );

    attachHandlersItens();
    atualizarTotal();
  }

  function converterQuantidade(
    valor,
    insumo,
    modo
  ) {
    const qtdPorEmb =
      Number(
        insumo?.qtdPorEmbalagem ||
        0
      );

    if (
      modo === 'emb' &&
      qtdPorEmb > 0
    ) {
      return valor * qtdPorEmb;
    }

    if (modo === 'kg') {
      return valor * 1000;
    }

    return valor;
  }

  function converterPreco(
    valor,
    insumo,
    modo
  ) {
    const qtdPorEmb =
      Number(
        insumo?.qtdPorEmbalagem ||
        0
      );

    if (
      modo === 'emb' &&
      qtdPorEmb > 0
    ) {
      return valor / qtdPorEmb;
    }

    if (modo === 'kg') {
      return valor / 1000;
    }

    return valor;
  }

  function recalcularPreview() {
    const select =
      document.getElementById(
        'cmp-item-insumo'
      );

    const insumo =
      insumosService.getById?.(
        select?.value
      ) ||
      insumosService.buscarPorId?.(
        select?.value
      );

    const quantidadeVisual =
      Number(
        document.getElementById(
          'cmp-item-quantidade'
        )?.value ||
        0
      );

    const precoVisual =
      Number(
        document.getElementById(
          'cmp-item-preco'
        )?.value ||
        0
      );

    const desconto =
      Number(
        document.getElementById(
          'cmp-item-desconto'
        )?.value ||
        0
      );

    const qtdModo =
      document.getElementById(
        'cmp-qtd-modo'
      )?.value ||
      'base';

    const precoModo =
      document.getElementById(
        'cmp-preco-modo'
      )?.value ||
      'base';

    const quantidadeBase =
      converterQuantidade(
        quantidadeVisual,
        insumo,
        qtdModo
      );

    const precoBase =
      converterPreco(
        precoVisual,
        insumo,
        precoModo
      );

    const item =
      comprasService.recalcularItem({
        insumoId:
          insumo?.id || null,
        quantidade:
          quantidadeBase,
        precoUnitario:
          precoBase,
        descontoValor:
          desconto,
      });

    const liquido =
      document.getElementById(
        'cmp-item-liquido'
      );

    const subtotal =
      document.getElementById(
        'cmp-item-subtotal'
      );

    const preview =
      document.getElementById(
        'cmp-preview'
      );

    if (liquido) {
      liquido.value =
        money(
          item.precoUnitarioLiquido
        );
    }

    if (subtotal) {
      subtotal.value =
        money(
          item.subtotal
        );
    }

    if (preview && insumo) {
      const unidade =
        insumo.unidade ||
        'un';

      const qtdPorEmb =
        Number(
          insumo.qtdPorEmbalagem ||
          0
        );

      let texto = '';

      if (
        qtdModo === 'emb' &&
        qtdPorEmb > 0
      ) {
        texto +=
          `${number(quantidadeVisual)} ` +
          `${insumo.nomeEmbalagem || 'emb'} = ` +
          `${number(quantidadeBase)} ${unidade}`;
      } else if (qtdModo === 'kg') {
        texto +=
          `${number(quantidadeVisual)} ` +
          `${unidade === 'g' ? 'kg' : 'L'} = ` +
          `${number(quantidadeBase)} ${unidade}`;
      }

      if (
        precoModo !== 'base' &&
        precoVisual > 0
      ) {
        if (texto) {
          texto += ' | ';
        }

        texto +=
          `custo-base ${money(precoBase)}/${unidade}`;
      }

      preview.textContent =
        texto;
    }
  }

  function atualizarBlocoEntrada(
    insumoId
  ) {
    const bloco =
      document.getElementById(
        'cmp-bloco-entrada'
      );

    if (!bloco) return;

    const insumo =
      insumosService.getById?.(
        insumoId
      ) ||
      insumosService.buscarPorId?.(
        insumoId
      );

    bloco.innerHTML =
      renderBlocoEntrada(
        insumo
      );

    [
      'cmp-item-quantidade',
      'cmp-item-preco',
      'cmp-item-desconto',
      'cmp-qtd-modo',
      'cmp-preco-modo',
    ].forEach(id => {
      on(
        id,
        'input',
        recalcularPreview
      );

      on(
        id,
        'change',
        recalcularPreview
      );
    });
  }

  function preencherItemParaEdicao(
    index
  ) {
    const item =
      itensTemporarios[index];

    if (!item) return;

    itemEditandoIndex = index;

    const select =
      document.getElementById(
        'cmp-item-insumo'
      );

    if (select) {
      select.value =
        item.insumoId;
    }

    atualizarBlocoEntrada(
      item.insumoId
    );

    const insumo =
      insumosService.getById?.(
        item.insumoId
      ) ||
      insumosService.buscarPorId?.(
        item.insumoId
      );

    const qtdPorEmb =
      Number(
        insumo?.qtdPorEmbalagem ||
        0
      );

    const unidade =
      insumo?.unidade || '';

    let qtdModo = 'base';
    let precoModo = 'base';
    let qtdVisual =
      Number(item.quantidade || 0);
    let precoVisual =
      Number(item.precoUnitario || 0);

    if (
      qtdPorEmb > 0 &&
      Number(item.qtdEmbalagens || 0) > 0
    ) {
      qtdModo = 'emb';
      qtdVisual =
        Number(item.qtdEmbalagens);

      precoModo = 'emb';
      precoVisual =
        Number(
          item.precoEmbalagem ||
          (
            Number(item.precoUnitario || 0) *
            qtdPorEmb
          )
        );
    } else if (
      unidade === 'g' ||
      unidade === 'ml'
    ) {
      qtdModo = 'kg';
      qtdVisual =
        Number(item.quantidade || 0) /
        1000;

      precoModo = 'kg';
      precoVisual =
        Number(item.precoUnitario || 0) *
        1000;
    }

    const qtdModoEl =
      document.getElementById(
        'cmp-qtd-modo'
      );

    const precoModoEl =
      document.getElementById(
        'cmp-preco-modo'
      );

    const qtdEl =
      document.getElementById(
        'cmp-item-quantidade'
      );

    const precoEl =
      document.getElementById(
        'cmp-item-preco'
      );

    const descontoEl =
      document.getElementById(
        'cmp-item-desconto'
      );

    if (qtdModoEl) {
      qtdModoEl.value =
        qtdModo;
    }

    if (precoModoEl) {
      precoModoEl.value =
        precoModo;
    }

    if (qtdEl) {
      qtdEl.value =
        qtdVisual;
    }

    if (precoEl) {
      precoEl.value =
        precoVisual;
    }

    if (descontoEl) {
      descontoEl.value =
        Number(
          item.descontoValor ||
          0
        );
    }

    recalcularPreview();
  }

  function attachHandlersItens() {
    document
      .querySelectorAll(
        '.cmp-remover-item'
      )
      .forEach(button => {
        button.addEventListener(
          'click',
          () => {
            const index =
              Number(
                button.dataset.index
              );

            itensTemporarios.splice(
              index,
              1
            );

            if (
              itemEditandoIndex ===
              index
            ) {
              itemEditandoIndex = null;
            }

            renderizarItensAtual();
          }
        );
      });

    document
      .querySelectorAll(
        '.cmp-editar-item'
      )
      .forEach(button => {
        button.addEventListener(
          'click',
          () => {
            preencherItemParaEdicao(
              Number(
                button.dataset.index
              )
            );
          }
        );
      });
  }

  function abrirNovoFornecedor() {
    [
      'cmp-mf-nome',
      'cmp-mf-cnpj',
      'cmp-mf-contato',
      'cmp-mf-telefone',
      'cmp-mf-email',
      'cmp-mf-endereco',
      'cmp-mf-obs',
    ].forEach(id => {
      const element =
        document.getElementById(id);

      if (element) {
        element.value = '';
      }
    });

    abrirModal(
      'cmp-modal-fornecedor'
    );

    setTimeout(
      () =>
        document
          .getElementById(
            'cmp-mf-nome'
          )
          ?.focus(),
      50
    );
  }

  function carregarTiposInsumo(
    selecionado = ''
  ) {
    const select =
      document.getElementById(
        'cmp-mi-tipo'
      );

    if (!select) return;

    const tipos =
      insumosService.obterTipos?.() ||
      insumosService.listarTipos?.() ||
      [];

    select.innerHTML =
      '<option value="">Selecione...</option>' +
      tipos.map(item => `
        <option
          value="${esc(item.id)}"
          ${
            String(item.id) ===
            String(selecionado)
              ? 'selected'
              : ''
          }
        >
          ${esc(item.nome)}
        </option>
      `).join('');
  }

  function carregarEmbalagens(
    selecionada = ''
  ) {
    const select =
      document.getElementById(
        'cmp-mi-embalagem'
      );

    if (!select) return;

    const embalagens =
      insumosService.obterEmbalagens?.() ||
      insumosService.listarEmbalagens?.() ||
      [];

    select.innerHTML =
      '<option value="">Selecione...</option>' +
      embalagens.map(nome => `
        <option
          value="${esc(nome)}"
          ${
            String(nome) ===
            String(selecionada)
              ? 'selected'
              : ''
          }
        >
          ${esc(nome)}
        </option>
      `).join('');
  }

  function abrirNovoInsumo() {
    document
      .getElementById(
        'cmp-mi-titulo'
      ).textContent =
        'Cadastrar Novo Insumo';

    document
      .getElementById(
        'cmp-mi-id'
      ).value = '';

    [
      'cmp-mi-nome',
      'cmp-mi-marca',
      'cmp-mi-qtd-emb',
      'cmp-mi-minimo',
      'cmp-mi-obs',
    ].forEach(id => {
      const element =
        document.getElementById(id);

      if (element) {
        element.value = '';
      }
    });

    const unidade =
      document.getElementById(
        'cmp-mi-unidade'
      );

    if (unidade) {
      unidade.value = '';
    }

    carregarTiposInsumo(
      'materia-prima'
    );

    carregarEmbalagens();

    abrirModal(
      'cmp-modal-insumo'
    );

    setTimeout(
      () =>
        document
          .getElementById(
            'cmp-mi-nome'
          )
          ?.focus(),
      50
    );
  }

  function abrirEditarInsumo() {
    const select =
      document.getElementById(
        'cmp-item-insumo'
      );

    const id =
      select?.value;

    if (!id) return;

    const insumo =
      insumosService.getById?.(id) ||
      insumosService.buscarPorId?.(id);

    if (!insumo) {
      alert(
        'Insumo não encontrado.'
      );
      return;
    }

    document
      .getElementById(
        'cmp-mi-titulo'
      ).textContent =
        'Editar Insumo';

    document
      .getElementById(
        'cmp-mi-id'
      ).value =
        insumo.id;

    document
      .getElementById(
        'cmp-mi-nome'
      ).value =
        insumo.nome || '';

    document
      .getElementById(
        'cmp-mi-marca'
      ).value =
        insumo.marca || '';

    document
      .getElementById(
        'cmp-mi-unidade'
      ).value =
        insumo.unidade || '';

    document
      .getElementById(
        'cmp-mi-qtd-emb'
      ).value =
        insumo.qtdPorEmbalagem || '';

    document
      .getElementById(
        'cmp-mi-minimo'
      ).value =
        insumo.minimoDesejado || '';

    document
      .getElementById(
        'cmp-mi-obs'
      ).value =
        insumo.observacoes || '';

    carregarTiposInsumo(
      insumo.tipo || ''
    );

    carregarEmbalagens(
      insumo.nomeEmbalagem || ''
    );

    abrirModal(
      'cmp-modal-insumo'
    );
  }

  on(
    'cmp-nova-compra',
    'click',
    () => {
      formAberto = true;
      editandoId = null;
      itensTemporarios = [];
      itemEditandoIndex = null;
      refresh();
    }
  );

  on(
    'cmp-cancelar',
    'click',
    () => {
      formAberto = false;
      editandoId = null;
      itensTemporarios = [];
      itemEditandoIndex = null;
      refresh();
    }
  );

  on(
    'cmp-novo-fornecedor-link',
    'click',
    abrirNovoFornecedor
  );

  on(
    'cmp-fornecedor',
    'change',
    event => {
      if (
        event.target.value ===
        '__novo__'
      ) {
        event.target.value = '';
        abrirNovoFornecedor();
      }
    }
  );

  on(
    'cmp-mf-x',
    'click',
    () =>
      fecharModal(
        'cmp-modal-fornecedor'
      )
  );

  on(
    'cmp-mf-cancelar',
    'click',
    () =>
      fecharModal(
        'cmp-modal-fornecedor'
      )
  );

  on(
    'cmp-mf-salvar',
    'click',
    () => {
      const payload = {
        nome:
          document
            .getElementById(
              'cmp-mf-nome'
            )
            ?.value || '',

        cnpj:
          document
            .getElementById(
              'cmp-mf-cnpj'
            )
            ?.value || '',

        contato:
          document
            .getElementById(
              'cmp-mf-contato'
            )
            ?.value || '',

        telefone:
          document
            .getElementById(
              'cmp-mf-telefone'
            )
            ?.value || '',

        email:
          document
            .getElementById(
              'cmp-mf-email'
            )
            ?.value || '',

        endereco:
          document
            .getElementById(
              'cmp-mf-endereco'
            )
            ?.value || '',

        observacoes:
          document
            .getElementById(
              'cmp-mf-obs'
            )
            ?.value || '',
      };

      const resultado =
        fornecedoresService.create(
          payload
        );

      if (!resultado.sucesso) {
        alert(
          (
            resultado.erros ||
            [resultado.erro]
          ).join('\n')
        );
        return;
      }

      fecharModal(
        'cmp-modal-fornecedor'
      );

      const fornecedor =
        resultado.fornecedor;

      const select =
        document.getElementById(
          'cmp-fornecedor'
        );

      if (select && fornecedor) {
        const option =
          document.createElement(
            'option'
          );

        option.value =
          fornecedor.id;

        option.textContent =
          fornecedor.nome;

        select.appendChild(
          option
        );

        select.value =
          fornecedor.id;
      }
    }
  );

  on(
    'cmp-novo-insumo',
    'click',
    abrirNovoInsumo
  );

  on(
    'cmp-editar-insumo',
    'click',
    abrirEditarInsumo
  );

  on(
    'cmp-mi-x',
    'click',
    () =>
      fecharModal(
        'cmp-modal-insumo'
      )
  );

  on(
    'cmp-mi-cancelar',
    'click',
    () =>
      fecharModal(
        'cmp-modal-insumo'
      )
  );

  on(
    'cmp-mi-novo-tipo',
    'click',
    () => {
      const nome =
        prompt(
          'Nome do novo tipo:'
        );

      if (!nome) return;

      const tipo =
        insumosService
          .adicionarTipoCustomizado?.(
            nome
          );

      if (!tipo) {
        alert(
          'Não foi possível adicionar o tipo.'
        );
        return;
      }

      carregarTiposInsumo(
        tipo.id
      );
    }
  );

  on(
    'cmp-mi-nova-embalagem',
    'click',
    () => {
      const nome =
        prompt(
          'Nome da nova embalagem:'
        );

      if (!nome) return;

      const embalagem =
        insumosService
          .adicionarEmbalagemCustomizada?.(
            nome
          );

      if (!embalagem) {
        alert(
          'Não foi possível adicionar a embalagem.'
        );
        return;
      }

      carregarEmbalagens(
        typeof embalagem === 'string'
          ? embalagem
          : (
              embalagem.nome ||
              nome
            )
      );
    }
  );

  on(
    'cmp-mi-salvar',
    'click',
    () => {
      const id =
        document
          .getElementById(
            'cmp-mi-id'
          )
          ?.value || '';

      const payload = {
        nome:
          document
            .getElementById(
              'cmp-mi-nome'
            )
            ?.value || '',

        marca:
          document
            .getElementById(
              'cmp-mi-marca'
            )
            ?.value || '',

        tipo:
          document
            .getElementById(
              'cmp-mi-tipo'
            )
            ?.value || '',

        unidade:
          document
            .getElementById(
              'cmp-mi-unidade'
            )
            ?.value || '',

        qtdPorEmbalagem:
          Number(
            document
              .getElementById(
                'cmp-mi-qtd-emb'
              )
              ?.value ||
            0
          ),

        nomeEmbalagem:
          document
            .getElementById(
              'cmp-mi-embalagem'
            )
            ?.value || '',

        minimoDesejado:
          Number(
            document
              .getElementById(
                'cmp-mi-minimo'
              )
              ?.value ||
            0
          ),

        observacoes:
          document
            .getElementById(
              'cmp-mi-obs'
            )
            ?.value || '',
      };

      const resultado =
        id
          ? (
              insumosService.update?.(
                id,
                payload
              ) ||
              insumosService.editar?.(
                id,
                payload
              )
            )
          : (
              insumosService.create?.(
                payload
              ) ||
              insumosService.adicionar?.(
                payload
              )
            );

      if (!resultado?.sucesso) {
        alert(
          (
            resultado?.erros ||
            [resultado?.erro || 'Falha ao salvar insumo']
          ).join('\n')
        );
        return;
      }

      const insumo =
        resultado.insumo;

      fecharModal(
        'cmp-modal-insumo'
      );

      const select =
        document.getElementById(
          'cmp-item-insumo'
        );

      if (
        select &&
        insumo
      ) {
        let option =
          [...select.options].find(
            item =>
              String(item.value) ===
              String(insumo.id)
          );

        if (!option) {
          option =
            document.createElement(
              'option'
            );

          option.value =
            insumo.id;

          select.appendChild(
            option
          );
        }

        option.textContent =
          `${insumo.nome}` +
          `${insumo.marca ? ` - ${insumo.marca}` : ''}` +
          ` (${insumo.unidade || 'un'})`;

        select.value =
          insumo.id;

        const editar =
          document.getElementById(
            'cmp-editar-insumo'
          );

        if (editar) {
          editar.disabled = false;
        }

        atualizarBlocoEntrada(
          insumo.id
        );
      }
    }
  );

  on(
    'cmp-item-insumo',
    'change',
    event => {
      const id =
        event.target.value;

      const editar =
        document.getElementById(
          'cmp-editar-insumo'
        );

      if (editar) {
        editar.disabled = !id;
      }

      atualizarBlocoEntrada(id);
    }
  );

  on(
    'cmp-adicionar-item',
    'click',
    () => {
      const insumoId =
        document
          .getElementById(
            'cmp-item-insumo'
          )
          ?.value || '';

      if (!insumoId) {
        alert(
          'Selecione um insumo.'
        );
        return;
      }

      const insumo =
        insumosService.getById?.(
          insumoId
        ) ||
        insumosService.buscarPorId?.(
          insumoId
        );

      const qtdVisual =
        Number(
          document
            .getElementById(
              'cmp-item-quantidade'
            )
            ?.value ||
          0
        );

      const precoVisual =
        Number(
          document
            .getElementById(
              'cmp-item-preco'
            )
            ?.value ||
          0
        );

      const desconto =
        Number(
          document
            .getElementById(
              'cmp-item-desconto'
            )
            ?.value ||
          0
        );

      const qtdModo =
        document
          .getElementById(
            'cmp-qtd-modo'
          )
          ?.value ||
        'base';

      const precoModo =
        document
          .getElementById(
            'cmp-preco-modo'
          )
          ?.value ||
        'base';

      const quantidadeBase =
        converterQuantidade(
          qtdVisual,
          insumo,
          qtdModo
        );

      const precoBase =
        converterPreco(
          precoVisual,
          insumo,
          precoModo
        );

      if (
        !quantidadeBase ||
        quantidadeBase <= 0
      ) {
        alert(
          'Informe uma quantidade válida.'
        );
        return;
      }

      if (
        precoBase < 0
      ) {
        alert(
          'Informe um preço válido.'
        );
        return;
      }

      const item =
        comprasService.recalcularItem({
          insumoId,
          quantidade:
            quantidadeBase,
          precoUnitario:
            precoBase,
          descontoValor:
            desconto,
        });

      const qtdPorEmb =
        Number(
          insumo?.qtdPorEmbalagem ||
          0
        );

      if (
        qtdModo === 'emb' &&
        qtdPorEmb > 0
      ) {
        item.qtdEmbalagens =
          qtdVisual;
      }

      if (
        precoModo === 'emb' &&
        qtdPorEmb > 0
      ) {
        item.precoEmbalagem =
          precoVisual;
      }

      if (
        itemEditandoIndex !==
        null
      ) {
        itensTemporarios[
          itemEditandoIndex
        ] = item;

        itemEditandoIndex =
          null;
      } else {
        itensTemporarios.push(
          item
        );
      }

      const select =
        document.getElementById(
          'cmp-item-insumo'
        );

      if (select) {
        select.value = '';
      }

      const editar =
        document.getElementById(
          'cmp-editar-insumo'
        );

      if (editar) {
        editar.disabled = true;
      }

      atualizarBlocoEntrada(null);
      renderizarItensAtual();
    }
  );

  on(
    'cmp-form',
    'submit',
    event => {
      event.preventDefault();

      const payload = {
        fornecedorId:
          document
            .getElementById(
              'cmp-fornecedor'
            )
            ?.value || '',

        data:
          document
            .getElementById(
              'cmp-data'
            )
            ?.value || '',

        formaPagamento:
          document
            .getElementById(
              'cmp-forma-pagamento'
            )
            ?.value || '',

        observacoes:
          document
            .getElementById(
              'cmp-observacoes'
            )
            ?.value || '',

        itens:
          itensTemporarios.map(
            normalizarItemParaEdicao
          ),
      };

      const id =
        document
          .getElementById(
            'cmp-id'
          )
          ?.value ||
        editandoId;

      const resultado =
        id
          ? comprasService.update(
              id,
              payload
            )
          : comprasService.create(
              payload
            );

      if (!resultado.sucesso) {
        alert(
          (
            resultado.erros ||
            [resultado.erro]
          ).join('\n')
        );
        return;
      }

      formAberto = false;
      editandoId = null;
      itensTemporarios = [];
      itemEditandoIndex = null;

      refresh();
    }
  );

  document
    .querySelectorAll(
      '.cmp-editar'
    )
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          const compra =
            comprasService.getById(
              button.dataset.id
            );

          if (!compra) {
            return;
          }

          editandoId =
            compra.id;

          formAberto =
            true;

          itensTemporarios =
            (compra.itens || [])
              .map(
                normalizarItemParaEdicao
              );

          itemEditandoIndex =
            null;

          refresh();
        }
      );
    });

  document
    .querySelectorAll(
      '.cmp-ver'
    )
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          const compra =
            comprasService.getById(
              button.dataset.id
            );

          if (!compra) return;

          const fornecedor =
            fornecedoresService.getById(
              compra.fornecedorId
            );

          const conteudo =
            document.getElementById(
              'cmp-ver-conteudo'
            );

          if (!conteudo) return;

          conteudo.innerHTML = `
            <div class="cmp-view-grid">

              <div>
                <strong>Fornecedor</strong>
                <div>
                  ${esc(fornecedor?.nome || '-')}
                </div>
              </div>

              <div>
                <strong>Data</strong>
                <div>
                  ${esc(dateBr(compra.data))}
                </div>
              </div>

              <div>
                <strong>Status</strong>
                <div>
                  ${esc(compra.status || '-')}
                </div>
              </div>

              <div>
                <strong>Pagamento</strong>
                <div>
                  ${esc(
                    formaPagamentoLabel(
                      compra.formaPagamento
                    )
                  )}
                </div>
              </div>

              <div>
                <strong>Financeiro</strong>
                <div>
                  ${
                    compra.lancamentoFinanceiroId
                      ? 'Lançado'
                      : 'Não lançado'
                  }
                </div>
              </div>

            </div>

            <hr />

            <h4>Itens</h4>

            ${
              renderItensTemporarios(
                compra.itens || [],
                insumosService.listar(),
                true
              )
            }

            <div class="cmp-total">
              <strong>
                Total:
                ${money(compra.total)}
              </strong>
            </div>

            <div>
              <strong>Observações</strong>
              <div>
                ${esc(compra.observacoes || '-')}
              </div>
            </div>
          `;

          abrirModal(
            'cmp-modal-ver'
          );
        }
      );
    });

  on(
    'cmp-ver-x',
    'click',
    () =>
      fecharModal(
        'cmp-modal-ver'
      )
  );

  on(
    'cmp-ver-fechar',
    'click',
    () =>
      fecharModal(
        'cmp-modal-ver'
      )
  );

  document
    .querySelectorAll(
      '.cmp-excluir'
    )
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          const compra =
            comprasService.getById(
              button.dataset.id
            );

          if (!compra) return;

          confirmar({
            titulo:
              'Excluir compra?',
            texto:
              compra.lancamentoFinanceiroId
                ? 'A compra possui lançamento financeiro vinculado. Exclua/estorne o lançamento financeiro antes de remover a compra.'
                : 'Esta ação excluirá definitivamente a compra.',
            botao:
              'Excluir',
            aoConfirmar: () => {
              if (
                compra.lancamentoFinanceiroId
              ) {
                alert(
                  'A compra possui lançamento financeiro vinculado.'
                );
                return;
              }

              const resultado =
                comprasService.remove(
                  compra.id
                );

              if (
                !resultado.sucesso
              ) {
                alert(
                  resultado.erro ||
                  'Falha ao excluir.'
                );
                return;
              }

              refresh();
            },
          });
        }
      );
    });

  document
    .querySelectorAll(
      '.cmp-receber'
    )
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          confirmar({
            titulo:
              'Confirmar recebimento?',
            texto:
              'O estoque será atualizado com os itens desta compra.',
            botao:
              'Receber',
            aoConfirmar: () => {
              const resultado =
                comprasService
                  .receberCompra(
                    button.dataset.id,
                    estoqueService
                  );

              if (
                !resultado.sucesso
              ) {
                alert(
                  resultado.erro ||
                  'Falha ao receber compra.'
                );
                return;
              }

              refresh();
            },
          });
        }
      );
    });

  document
    .querySelectorAll(
      '.cmp-estornar'
    )
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          confirmar({
            titulo:
              'Estornar recebimento?',
            texto:
              'As entradas de estoque geradas por esta compra serão removidas.',
            botao:
              'Estornar',
            aoConfirmar: () => {
              const resultado =
                comprasService
                  .estornarRecebimento(
                    button.dataset.id,
                    estoqueService
                  );

              if (
                !resultado.sucesso
              ) {
                alert(
                  resultado.erro ||
                  'Falha ao estornar.'
                );
                return;
              }

              refresh();
            },
          });
        }
      );
    });

  document
    .querySelectorAll(
      '.cmp-lancar-financeiro'
    )
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          const compra =
            comprasService.getById(
              button.dataset.id
            );

          if (!compra) return;

          if (
            compra.formaPagamento ===
            'a_prazo'
          ) {
            confirmar({
              titulo:
                'Abrir Financeiro?',
              texto:
                'Compras a prazo podem exigir configuração de parcelas. Abriremos o módulo Financeiro para concluir o lançamento.',
              botao:
                'Ir para Financeiro',
              aoConfirmar: () => {
                window.location.hash =
                  'financeiro';
              },
            });

            return;
          }

          confirmar({
            titulo:
              'Lançar no Financeiro?',
            texto:
              `Registrar ${money(compra.total)} no Financeiro?`,
            botao:
              'Lançar',
            aoConfirmar: () => {
              const resultado =
                financeiroService
                  .lancarCompra(
                    compra,
                    comprasService,
                    {
                      parcelas: 1,
                      primeiroVencimento:
                        compra.data ||
                        hojeISO(),
                    }
                  );

              if (
                !resultado.sucesso
              ) {
                alert(
                  resultado.erro ||
                  'Falha ao lançar no Financeiro.'
                );
                return;
              }

              refresh();
            },
          });
        }
      );
    });

  document
    .querySelectorAll(
      '.cmp-ir-financeiro'
    )
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          window.location.hash =
            'financeiro';
        }
      );
    });

  on(
    'cmp-exportar',
    'click',
    () => {
      const menu =
        document.getElementById(
          'cmp-export-menu'
        );

      if (menu) {
        menu.hidden =
          !menu.hidden;
      }
    }
  );

  document
    .querySelectorAll(
      '[data-export]'
    )
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          const compras =
            comprasService.list();

          const fornecedores =
            fornecedoresService.list();

          const linhas =
            compras.map(compra => {
              const fornecedor =
                fornecedorPorId(
                  fornecedores,
                  compra.fornecedorId
                );

              return {
                Data:
                  dateBr(compra.data),
                Fornecedor:
                  fornecedor?.nome || '',
                Pagamento:
                  formaPagamentoLabel(
                    compra.formaPagamento
                  ),
                Itens:
                  (compra.itens || []).length,
                Total:
                  Number(compra.total || 0)
                    .toFixed(2)
                    .replace('.', ','),
                Economia:
                  economiaCompra(compra)
                    .toFixed(2)
                    .replace('.', ','),
                Status:
                  compra.status || '',
                Financeiro:
                  compra.lancamentoFinanceiroId
                    ? 'Sim'
                    : 'Não',
              };
            });

          if (
            button.dataset.export ===
            'csv'
          ) {
            exportarCSV(linhas);
          } else {
            exportarPDF(linhas);
          }
        }
      );
    });

  attachHandlersItens();

  if (
    formAberto &&
    !editandoId
  ) {
    atualizarBlocoEntrada(null);
  }
}

function exportarCSV(linhas) {
  const colunas = [
    'Data',
    'Fornecedor',
    'Pagamento',
    'Itens',
    'Total',
    'Economia',
    'Status',
    'Financeiro',
  ];

  const escapeCsv = value => {
    const texto =
      String(value ?? '');

    if (
      /[;"\n\r]/.test(texto)
    ) {
      return `"${texto.replaceAll('"', '""')}"`;
    }

    return texto;
  };

  const csv = [
    colunas.join(';'),
    ...linhas.map(item =>
      colunas
        .map(coluna =>
          escapeCsv(item[coluna])
        )
        .join(';')
    ),
  ].join('\r\n');

  const blob =
    new Blob(
      ['\ufeff', csv],
      {
        type:
          'text/csv;charset=utf-8;',
      }
    );

  const url =
    URL.createObjectURL(blob);

  const link =
    document.createElement('a');

  link.href = url;
  link.download =
    `compras-${hojeISO()}.csv`;

  document.body.appendChild(link);
  link.click();
  link.remove();

  URL.revokeObjectURL(url);
}

function exportarPDF(linhas) {
  const janela =
    window.open(
      '',
      '_blank',
      'width=1100,height=800'
    );

  if (!janela) {
    alert(
      'O navegador bloqueou a janela de impressão.'
    );
    return;
  }

  const rows =
    linhas.map(item => `
      <tr>
        <td>${esc(item.Data)}</td>
        <td>${esc(item.Fornecedor)}</td>
        <td>${esc(item.Pagamento)}</td>
        <td>${esc(item.Itens)}</td>
        <td>${esc(item.Total)}</td>
        <td>${esc(item.Economia)}</td>
        <td>${esc(item.Status)}</td>
        <td>${esc(item.Financeiro)}</td>
      </tr>
    `).join('');

  janela.document.write(`
    <!doctype html>
    <html lang="pt-BR">
      <head>
        <meta charset="utf-8" />
        <title>Compras</title>

        <style>
          body {
            font-family: Arial, sans-serif;
            padding: 24px;
          }

          table {
            width: 100%;
            border-collapse: collapse;
          }

          th,
          td {
            border: 1px solid #ccc;
            padding: 7px;
            text-align: left;
          }

          th {
            background: #5a392b;
            color: white;
          }

          h1 {
            color: #5a392b;
          }
        </style>
      </head>

      <body>
        <h1>Compras</h1>

        <table>
          <thead>
            <tr>
              <th>Data</th>
              <th>Fornecedor</th>
              <th>Pagamento</th>
              <th>Itens</th>
              <th>Total</th>
              <th>Economia</th>
              <th>Status</th>
              <th>Financeiro</th>
            </tr>
          </thead>

          <tbody>
            ${rows}
          </tbody>
        </table>

        <script>
          window.onload = () => {
            window.print();
          };
        </script>
      </body>
    </html>
  `);

  janela.document.close();
}

function stylesCompras() {
  return `
    <style>
      .compras-master {
        display: grid;
        gap: 14px;
      }

      .cmp-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 14px;
      }

      .cmp-header h2 {
        margin: 0;
      }

      .cmp-header-actions {
        display: flex;
        gap: 8px;
        align-items: center;
      }

      .cmp-export-wrap {
        position: relative;
      }

      .cmp-export-menu {
        position: absolute;
        right: 0;
        top: calc(100% + 5px);
        min-width: 150px;
        padding: 5px;
        background: white;
        border: 1px solid var(--border);
        border-radius: 6px;
        box-shadow: var(--shadow);
        z-index: 50;
      }

      .cmp-export-menu button {
        width: 100%;
        border: 0;
        background: transparent;
        text-align: left;
        padding: 8px 10px;
        cursor: pointer;
      }

      .cmp-export-menu button:hover {
        background: #f3efe8;
      }

      .cmp-form-card,
      .cmp-list-card {
        margin: 0;
      }

      .cmp-section-title {
        font-weight: 700;
        margin-bottom: 12px;
        padding-bottom: 8px;
        border-bottom: 1px solid var(--border);
      }

      .cmp-form-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
      }

      .cmp-item-select-line {
        display: grid;
        grid-template-columns: minmax(220px, 1fr) auto auto;
        gap: 6px;
        align-items: center;
        margin-bottom: 10px;
      }

      .cmp-entry-card {
        padding: 10px 0;
      }

      .cmp-entry-meta {
        font-size: 0.78rem;
        color: var(--text-muted);
        margin-bottom: 8px;
      }

      .cmp-entry-grid {
        display: grid;
        grid-template-columns: repeat(5, minmax(105px, 1fr));
        gap: 10px;
        align-items: end;
      }

      .cmp-mode-select {
        margin-bottom: 5px;
      }

      .cmp-preview {
        min-height: 18px;
        color: #247848;
        font-size: 0.8rem;
        margin-top: 4px;
      }

      .cmp-add-item-row {
        margin: 8px 0 10px;
      }

      .cmp-total {
        text-align: right;
        padding: 12px;
        margin-top: 10px;
        background: #fbf8f4;
        border: 1px solid var(--border);
        border-radius: 6px;
      }

      .cmp-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 5px;
        align-items: center;
      }

      .cmp-muted {
        font-size: 0.75rem;
        color: var(--text-muted);
      }

      .cmp-badge {
        display: inline-block;
        padding: 3px 7px;
        border-radius: 999px;
        font-size: 0.75rem;
        font-weight: 700;
      }

      .cmp-badge.pendente,
      .cmp-badge.neutral {
        background: #f1eadf;
        color: #6b4a34;
      }

      .cmp-badge.recebida,
      .cmp-badge.ok {
        background: #e4f3e8;
        color: #27613b;
      }

      .cmp-badge.cancelada {
        background: #f7e4e4;
        color: #8a3030;
      }

      .cmp-link-button {
        border: 0;
        background: transparent;
        color: var(--primary);
        cursor: pointer;
        padding: 0 0 0 6px;
        font: inherit;
        font-weight: 400;
      }

      .cmp-modal-overlay {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.48);
        z-index: 9999;
        align-items: center;
        justify-content: center;
        padding: 20px;
      }

      .cmp-modal {
        width: min(560px, 96vw);
        max-height: 90vh;
        overflow: auto;
        background: white;
        border-radius: 8px;
        box-shadow: 0 12px 40px rgba(0,0,0,.28);
      }

      .cmp-modal-large {
        width: min(900px, 96vw);
      }

      .cmp-modal-small {
        width: min(430px, 96vw);
      }

      .cmp-modal-header,
      .cmp-modal-footer {
        padding: 14px 16px;
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .cmp-modal-header {
        justify-content: space-between;
        border-bottom: 1px solid var(--border);
      }

      .cmp-modal-footer {
        justify-content: flex-end;
        border-top: 1px solid var(--border);
      }

      .cmp-modal-body {
        padding: 16px;
      }

      .cmp-modal-x {
        border: 0;
        background: transparent;
        font-size: 1.5rem;
        cursor: pointer;
      }

      .cmp-inline {
        display: flex;
        gap: 5px;
      }

      .cmp-view-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 12px;
      }

      @media (max-width: 900px) {
        .cmp-entry-grid {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .cmp-view-grid {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }
      }

      @media (max-width: 650px) {
        .cmp-header,
        .cmp-header-actions {
          flex-direction: column;
          align-items: stretch;
        }

        .cmp-form-grid,
        .cmp-entry-grid,
        .cmp-view-grid,
        .cmp-item-select-line {
          grid-template-columns: 1fr;
        }
      }
    
      /* C13 - paridade visual do modulo Compras */
      .compras-master .card {
        background: #fff;
        border-radius: var(--radius);
        box-shadow: var(--shadow);
        padding: 16px;
      }
      .compras-master .form-group {
        display: grid;
        gap: 5px;
        min-width: 0;
      }
      .compras-master .form-group > label {
        display: flex;
        align-items: center;
        gap: 4px;
        font-size: .78rem;
        font-weight: 600;
        color: var(--text);
      }
      .compras-master .form-control {
        width: 100%;
        min-width: 0;
        min-height: 34px;
        box-sizing: border-box;
        border: 1px solid #d7c7b8;
        border-radius: 5px;
        background: #fff;
        color: var(--text);
        padding: 7px 9px;
        font: inherit;
      }
      .compras-master .form-control:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 2px rgba(91,59,43,.10);
      }
      .compras-master textarea.form-control {
        min-height: 64px;
        resize: vertical;
      }
      .compras-master hr {
        border: 0;
        border-top: 1px solid var(--border);
        margin: 14px 0;
      }
      .compras-master h4 { margin: 0 0 8px; font-size: .9rem; }
      .compras-master .cmp-form-card { display: grid; gap: 8px; }
      .compras-master .cmp-form-card form { display: grid; gap: 10px; }
      .compras-master .cmp-form-grid {
        grid-template-columns: repeat(2,minmax(0,1fr));
        gap: 12px;
      }
      .compras-master .cmp-item-select-line {
        grid-template-columns: minmax(280px,1fr) auto auto;
        gap: 7px;
      }
      .compras-master .cmp-entry-grid {
        grid-template-columns: minmax(120px,1.1fr) minmax(140px,1.2fr) minmax(110px,.9fr) minmax(115px,.9fr) minmax(115px,.9fr);
        gap: 10px;
      }
      .compras-master .cmp-entry-grid .form-group { align-content: end; }
      .compras-master .cmp-add-item-row { display: flex; align-items: center; }
      .compras-master .form-actions { display: flex; gap: 8px; align-items: center; margin-top: 2px; }
      .compras-master .table-container { padding: 0; box-shadow: none; border-radius: 0; }
      .compras-master .table th,
      .compras-master .table td { vertical-align: middle; }
      .compras-master .cmp-list-card { padding: 12px; }
      .compras-master .cmp-total { min-height: 40px; display: flex; align-items: center; justify-content: flex-end; }
      .compras-master .cmp-modal .form-control { min-height: 36px; }
      @media (max-width:900px) {
        .compras-master .cmp-entry-grid { grid-template-columns: repeat(2,minmax(0,1fr)); }
      }
      @media (max-width:650px) {
        .compras-master .cmp-form-grid,
        .compras-master .cmp-entry-grid,
        .compras-master .cmp-item-select-line { grid-template-columns: 1fr; }
      }
    </style>
  `;
}