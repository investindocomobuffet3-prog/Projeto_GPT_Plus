import { v4 as uuidv4 } from './uuid.js';
import { saveToStorage } from './storage.js';

function numero(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

export function createComprasService(data) {
  if (!Array.isArray(data.compras)) {
    data.compras = [];
  }

  function list() {
    return data.compras;
  }

  function getById(id) {
    return list().find(
      item => String(item.id) === String(id)
    ) || null;
  }

  function validar(payload = {}) {
    const erros = [];

    if (!payload.fornecedorId) {
      erros.push('Fornecedor é obrigatório');
    }

    if (!payload.data) {
      erros.push('Data é obrigatória');
    }

    if (
      !Array.isArray(payload.itens) ||
      payload.itens.length === 0
    ) {
      erros.push('Adicione pelo menos um item');
    }

    (payload.itens || []).forEach((item, index) => {
      if (!item.insumoId) {
        erros.push(`Item ${index + 1}: Insumo obrigatório`);
      }

      if (!numero(item.quantidade) || numero(item.quantidade) <= 0) {
        erros.push(`Item ${index + 1}: Quantidade inválida`);
      }

      const preco =
        item.precoUnitario !== undefined
          ? numero(item.precoUnitario)
          : numero(item.valorUnitario);

      if (preco < 0) {
        erros.push(`Item ${index + 1}: Preço inválido`);
      }
    });

    return erros;
  }

  function recalcularItem(item = {}) {
    const quantidade = numero(item.quantidade);

    const precoUnitario =
      item.precoUnitario !== undefined
        ? numero(item.precoUnitario)
        : numero(item.valorUnitario);

    const descontoValor =
      Math.max(0, numero(item.descontoValor));

    const descontoUnitario =
      descontoValor > 0 && quantidade > 0
        ? descontoValor / quantidade
        : 0;

    const precoUnitarioLiquido =
      Math.round(
        (precoUnitario - descontoUnitario) * 1000000
      ) / 1000000;

    const subtotal =
      Math.round(
        quantidade * precoUnitarioLiquido * 100
      ) / 100;

    const mapped = {
      insumoId: item.insumoId || null,
      quantidade,
      precoUnitario,
      descontoValor,
      precoUnitarioLiquido,
      subtotal,

      // Compatibilidade temporária.
      valorUnitario: precoUnitario,
    };

    if (numero(item.precoEmbalagem) > 0) {
      mapped.precoEmbalagem = numero(item.precoEmbalagem);
    }

    if (numero(item.qtdEmbalagens) > 0) {
      mapped.qtdEmbalagens = numero(item.qtdEmbalagens);
    }

    return mapped;
  }

  function normalizeItems(items = []) {
    if (!Array.isArray(items)) return [];

    return items
      .map(recalcularItem)
      .filter(item =>
        item.insumoId &&
        item.quantidade > 0
      );
  }

  function calcularTotal(items = []) {
    return normalizeItems(items).reduce(
      (total, item) => total + numero(item.subtotal),
      0
    );
  }

  function calculateTotal(items = []) {
    return calcularTotal(items);
  }

  function create(payload = {}) {
    const itens = normalizeItems(payload.itens || []);

    const erros = validar({
      ...payload,
      itens,
    });

    if (erros.length) {
      return {
        sucesso: false,
        erros,
      };
    }

    const total = calcularTotal(itens);

    const compra = {
      id: payload.id || uuidv4(),
      fornecedorId: payload.fornecedorId,
      data: payload.data,
      itens,
      total,

      // Compatibilidade com Financeiro/modular anterior.
      valor: total,

      formaPagamento: payload.formaPagamento || '',
      observacoes: String(payload.observacoes || '').trim(),
      status: 'pendente',
      lancamentoFinanceiroId: null,
      recebimentoEstoqueId: null,
      criadoEm: new Date().toISOString(),
    };

    data.compras.push(compra);
    persist();

    return {
      sucesso: true,
      compra,
    };
  }

  function update(id, payload = {}) {
    const index = list().findIndex(
      item => String(item.id) === String(id)
    );

    if (index === -1) {
      return {
        sucesso: false,
        erros: ['Compra não encontrada'],
      };
    }

    const atual = data.compras[index];

    if (atual.status !== 'pendente') {
      return {
        sucesso: false,
        erros: ['Apenas compras pendentes podem ser editadas'],
      };
    }

    const itens = normalizeItems(payload.itens || []);

    const erros = validar({
      ...payload,
      itens,
    });

    if (erros.length) {
      return {
        sucesso: false,
        erros,
      };
    }

    const total = calcularTotal(itens);

    data.compras[index] = {
      ...atual,
      fornecedorId: payload.fornecedorId,
      data: payload.data,
      itens,
      total,
      valor: total,
      formaPagamento: payload.formaPagamento || '',
      observacoes: String(payload.observacoes || '').trim(),
      atualizadoEm: new Date().toISOString(),
    };

    persist();

    return {
      sucesso: true,
      compra: data.compras[index],
    };
  }

  function remove(id) {
    const compra = getById(id);

    if (!compra) {
      return {
        sucesso: false,
        erro: 'Compra não encontrada',
      };
    }

    if (compra.status !== 'pendente') {
      return {
        sucesso: false,
        erro: 'Apenas compras pendentes podem ser removidas',
      };
    }

    data.compras = list().filter(
      item => String(item.id) !== String(id)
    );

    persist();

    return { sucesso: true };
  }

  function receberCompra(compraId, estoqueService) {
    const compra = getById(compraId);

    if (!compra) {
      return {
        sucesso: false,
        erro: 'Compra não encontrada',
      };
    }

    if (compra.status !== 'pendente') {
      return {
        sucesso: false,
        erro: 'Esta compra já foi processada',
      };
    }

    const executadas = [];

    for (const item of compra.itens) {
      const resultado =
        estoqueService.registrarEntrada({
          insumoId: item.insumoId,
          quantidade: item.quantidade,
          custoUnitario:
            item.precoUnitarioLiquido ??
            item.precoUnitario,
          origem: 'compra',
          referenciaId: compraId,
        });

      if (!resultado.ok) {
        estoqueService
          .removerEntradasDaCompra(compraId);

        return {
          sucesso: false,
          erro: `Erro no estoque: ${resultado.erro}`,
        };
      }

      executadas.push(resultado);
    }

    const index = list().findIndex(
      item => String(item.id) === String(compraId)
    );

    data.compras[index].status = 'recebida';
    data.compras[index].dataRecebimento =
      new Date().toISOString();

    // Compatibilidade temporária.
    data.compras[index].recebimentoEstoqueId = compraId;

    persist();

    return { sucesso: true };
  }

  function estornarRecebimento(compraId, estoqueService) {
    const compra = getById(compraId);

    if (!compra) {
      return {
        sucesso: false,
        erro: 'Compra não encontrada',
      };
    }

    if (compra.status !== 'recebida') {
      return {
        sucesso: false,
        erro: 'Apenas compras recebidas podem ser estornadas',
      };
    }

    const resultado =
      estoqueService.removerEntradasDaCompra(compraId);

    if (!resultado.sucesso) {
      return resultado;
    }

    const index = list().findIndex(
      item => String(item.id) === String(compraId)
    );

    data.compras[index].status = 'pendente';
    data.compras[index].recebimentoEstoqueId = null;

    delete data.compras[index].dataRecebimento;

    persist();

    return { sucesso: true };
  }

  function vincularLancamentoFinanceiro(compraId, lancamentoId) {
    const compra = getById(compraId);

    if (!compra) {
      return {
        sucesso: false,
        erro: 'Compra não encontrada',
      };
    }

    compra.lancamentoFinanceiroId = lancamentoId;
    persist();

    return {
      sucesso: true,
      compra,
    };
  }

  function desvincularLancamentoFinanceiro(compraId) {
    const compra = getById(compraId);

    if (!compra) {
      return {
        sucesso: false,
        erro: 'Compra não encontrada',
      };
    }

    compra.lancamentoFinanceiroId = null;
    persist();

    return {
      sucesso: true,
      compra,
    };
  }

  function persist() {
    saveToStorage({
      compras: data.compras,
    });
  }

  return {
    list,
    getById,
    validar,
    recalcularItem,
    normalizeItems,
    calcularTotal,
    calculateTotal,
    create,
    update,
    remove,
    receberCompra,
    estornarRecebimento,
    vincularLancamentoFinanceiro,
    desvincularLancamentoFinanceiro,
  };
}