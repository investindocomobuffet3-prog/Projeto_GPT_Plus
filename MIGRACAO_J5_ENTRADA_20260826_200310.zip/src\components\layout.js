import { renderHeader } from './header.js';
import { renderSidebar } from './sidebar.js';

export function renderLayout(root, app) {
  root.innerHTML = `
    <div class="app-shell">
      ${renderHeader()}
      <div class="app-body">
        ${renderSidebar()}
        <main class="app-content" id="app"></main>
      </div>
    </div>
  `;

  document.getElementById('sidebar-toggle').addEventListener('click', () => {
    document.querySelector('.app-sidebar').classList.toggle('open');
    document.querySelector('.sidebar-overlay').classList.toggle('open');
  });
  document.querySelector('.sidebar-overlay').addEventListener('click', () => {
    document.querySelector('.app-sidebar').classList.remove('open');
    document.querySelector('.sidebar-overlay').classList.remove('open');
  });

  document.querySelectorAll('.tab-button').forEach(button => {
    button.addEventListener('click', (event) => {
      event.preventDefault();
      const tab = button.dataset.tab;
      window.location.hash = tab;
    });
  });

  app.render();
}
