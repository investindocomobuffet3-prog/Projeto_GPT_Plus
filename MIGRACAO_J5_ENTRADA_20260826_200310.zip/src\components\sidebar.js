﻿const groups = [
  {
    label: '',
    tabs: [{ key: 'dashboard', label: 'Dashboard', icon: 'fa-chart-line' }]
  },
  {
    label: 'Operação Diária',
    tabs: [
      { key: 'compras', label: 'Compras', icon: 'fa-cart-shopping' },
      { key: 'estoque', label: 'Estoque', icon: 'fa-boxes-stacked' },
      { key: 'fichas', label: 'Fichas Técnicas', icon: 'fa-book' },
      { key: 'producao', label: 'Produção - Fase 1', icon: 'fa-industry' },
      { key: 'produtos', label: 'Produção - Fase 2', icon: 'fa-candy-cane' }
    ]
  },
  {
    label: 'Vendas',
    tabs: [
      { key: 'encomendas', label: 'Encomendas', icon: 'fa-box' },
      { key: 'clientes', label: 'Clientes', icon: 'fa-users' },
      { key: 'vendas', label: 'Vendas', icon: 'fa-handshake' },
      { key: 'relatorios', label: 'Relatórios', icon: 'fa-chart-bar' },
      { key: 'financeiro', label: 'Financeiro', icon: 'fa-dollar-sign' }
    ]
  },
  {
    label: 'Cadastros',
    tabs: [
      { key: 'insumos', label: 'Insumos', icon: 'fa-utensils' },
      { key: 'fornecedores', label: 'Fornecedores', icon: 'fa-truck' },
      { key: 'cartoes', label: 'Cartões', icon: 'fa-credit-card' }
    ]
  },
  {
    label: 'Sistema',
    tabs: [{ key: 'backup', label: 'Backup', icon: 'fa-floppy-disk' }]
  }
];

export function renderSidebar() {
  return `
    <div class="sidebar-overlay"></div>
    <aside class="app-sidebar sidebar">
      ${groups.map(group => `
        ${group.label ? `<div class="sidebar-group-label">${group.label}</div>` : ''}
        ${group.tabs.map(renderTab).join('')}
      `).join('')}
    </aside>
  `;
}

function renderTab(tab) {
  return `
    <button class="tab-button" data-tab="${tab.key}">
      <i class="fas ${tab.icon}"></i>
      <span>${tab.label}</span>
    </button>
  `;
}
