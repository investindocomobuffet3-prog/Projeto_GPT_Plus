export const INSUMO_MODEL = {
  id: 'string',
  nome: 'string',
  marca: 'string',
  tipo: 'string',
  unidade: 'string',
  qtdPorEmbalagem: 'number',
  nomeEmbalagem: 'string',
  minimoDesejado: 'number',
  observacoes: 'string',
  ativo: 'boolean',
  criadoEm: 'string',
  atualizadoEm: 'string',
};

export const FORNECEDOR_MODEL = {
  id: 'string',
  nome: 'string',
  cnpj: 'string',
  contato: 'string',
  telefone: 'string',
  email: 'string',
  endereco: 'string',
  observacoes: 'string',
  ativo: 'boolean',
  criadoEm: 'string',
  atualizadoEm: 'string',
};

export const COMPRA_ITEM_MODEL = {
  insumoId: 'string',
  quantidade: 'number',
  valorUnitario: 'number',
  subtotal: 'number',
};

export const COMPRA_MODEL = {
  id: 'string',
  fornecedorId: 'string',
  data: 'string',
  itens: 'array',
  total: 'number',
  valor: 'number',
  formaPagamento: 'string',
  observacoes: 'string',
  status: 'string',
  lancamentoFinanceiroId: 'string',
  recebimentoEstoqueId: 'string',
  dataRecebimento: 'string',
  criadoEm: 'string',
  atualizadoEm: 'string',
};

export const MOVIMENTACAO_ESTOQUE_MODEL = {
  id: 'string',
  insumoId: 'string',
  tipo: 'string',
  quantidade: 'number',
  custoUnitario: 'number',
  origem: 'string',
  referenciaId: 'string',
  data: 'string',
};

export const FICHA_INGREDIENTE_MODEL = {
  insumoId: 'string',
  quantidade: 'number',
  custoUnitario: 'number',
};

export const FICHA_MODEL = {
  id: 'string',
  nome: 'string',
  tipo: 'string',
  rendimento: 'number',
  unidadeMedida: 'string',
  ingredientes: 'array',
  custoTotal: 'number',
  custoUnitario: 'number',
  pesoPadraoDoce: 'number|null',
  baseId: 'string|null',
  baseQuantidadeG: 'number|null',
  panelaReferencia: 'string|null',
  modoPreparo: 'string',
  observacoes: 'string',
  criadoEm: 'string',
  atualizadoEm: 'string|null',
};
export const DEFAULT_STORE = {
  insumos: [],
  fornecedores: [],
  compras: [],
  movimentacoesEstoque: [],
  estoque_itens: [],
  estoque_mov: [],
};