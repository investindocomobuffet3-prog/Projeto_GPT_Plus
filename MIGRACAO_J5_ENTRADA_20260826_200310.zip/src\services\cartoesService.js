import { storageProvider } from './storage.js';

function generateId() {
  if (globalThis.crypto?.randomUUID) {
    return globalThis.crypto.randomUUID();
  }

  return `card-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function createCartoesService() {
  return {
    listar() {
      return storageProvider.get('cartoes') || [];
    },

    buscarPorId(id) {
      return this.listar().find(item => item.id === id) || null;
    },

    validar(payload) {
      const erros = [];

      if (!payload.banco || payload.banco.trim() === '') {
        erros.push('Banco é obrigatório');
      }

      if (!payload.limite || Number(payload.limite) <= 0) {
        erros.push('Limite deve ser maior que zero');
      }

      if (!payload.ultimos4 || String(payload.ultimos4).trim() === '') {
        erros.push('Últimos 4 dígitos são obrigatórios');
      } else if (!/^\d{4}$/.test(String(payload.ultimos4).trim())) {
        erros.push('Últimos 4 dígitos devem ser exatamente 4 números');
      }

      const diaVirada = Number(payload.diaVirada);

      if (!diaVirada) {
        erros.push('Dia de virada é obrigatório');
      } else if (
        !Number.isInteger(diaVirada) ||
        diaVirada < 1 ||
        diaVirada > 31
      ) {
        erros.push('Dia de virada deve estar entre 1 e 31');
      }

      if (!payload.vencimento || String(payload.vencimento).trim() === '') {
        erros.push('Vencimento é obrigatório');
      }

      return erros;
    },

    adicionar(payload) {
      const erros = this.validar(payload);

      if (erros.length) {
        return { sucesso: false, erros };
      }

      const cartoes = this.listar();

      const cartao = {
        id: generateId(),
        banco: payload.banco.trim(),
        ultimos4: String(payload.ultimos4).trim(),
        limite: Number(payload.limite),
        saldoDisponivel: Number(payload.limite),
        diaVirada: Number(payload.diaVirada),
        vencimento: String(payload.vencimento).trim(),
        compras: [],
        ativo: true,
        criadoEm: new Date().toISOString(),
      };

      cartoes.push(cartao);
      storageProvider.save('cartoes', cartoes);

      return { sucesso: true, cartao };
    },

    editar(id, payload) {
      const erros = this.validar(payload);

      if (erros.length) {
        return { sucesso: false, erros };
      }

      const cartoes = this.listar();
      const index = cartoes.findIndex(item => item.id === id);

      if (index === -1) {
        return {
          sucesso: false,
          erros: ['Cartão não encontrado'],
        };
      }

      const anterior = cartoes[index];
      const novoLimite = Number(payload.limite);
      const utilizado =
        Math.max(0, Number(anterior.limite) - Number(anterior.saldoDisponivel));

      cartoes[index] = {
        ...anterior,
        banco: payload.banco.trim(),
        ultimos4: String(payload.ultimos4).trim(),
        limite: novoLimite,
        saldoDisponivel: Math.max(0, novoLimite - utilizado),
        diaVirada: Number(payload.diaVirada),
        vencimento: String(payload.vencimento).trim(),
        atualizadoEm: new Date().toISOString(),
      };

      storageProvider.save('cartoes', cartoes);

      return {
        sucesso: true,
        cartao: cartoes[index],
      };
    },

    excluir(id) {
      const cartoes = this.listar();
      const cartao = cartoes.find(item => item.id === id);

      if (!cartao) {
        return {
          sucesso: false,
          erros: ['Cartão não encontrado'],
        };
      }

      if (cartao.compras?.length) {
        return {
          sucesso: false,
          erros: ['Não é possível excluir cartão com compras associadas'],
        };
      }

      storageProvider.save(
        'cartoes',
        cartoes.filter(item => item.id !== id)
      );

      return { sucesso: true };
    },

    usarCredito(id, valor, compraId) {
      const cartoes = this.listar();
      const cartao = cartoes.find(item => item.id === id);
      const numero = Number(valor);

      if (!cartao) {
        return { sucesso: false, erro: 'Cartão não encontrado' };
      }

      if (!cartao.ativo) {
        return { sucesso: false, erro: 'Cartão inativo' };
      }

      if (cartao.saldoDisponivel < numero) {
        return {
          sucesso: false,
          erro:
            `Limite insuficiente. Disponível: R$ ` +
            `${Number(cartao.saldoDisponivel).toFixed(2)}`,
        };
      }

      cartao.saldoDisponivel -= numero;
      cartao.compras ||= [];
      cartao.compras.push(compraId);

      storageProvider.save('cartoes', cartoes);

      return {
        sucesso: true,
        saldoRestante: cartao.saldoDisponivel,
      };
    },

    liberarCredito(id, valor, compraId) {
      const cartoes = this.listar();
      const cartao = cartoes.find(item => item.id === id);
      const numero = Number(valor);

      if (!cartao) {
        return { sucesso: false, erro: 'Cartão não encontrado' };
      }

      cartao.saldoDisponivel = Math.min(
        Number(cartao.limite),
        Number(cartao.saldoDisponivel) + numero
      );

      if (cartao.compras) {
        cartao.compras =
          cartao.compras.filter(item => item !== compraId);
      }

      storageProvider.save('cartoes', cartoes);

      return {
        sucesso: true,
        saldoRestante: cartao.saldoDisponivel,
      };
    },

    calcularPercentualLivre(cartao) {
      if (!cartao || !Number(cartao.limite)) {
        return 0;
      }

      return (
        Number(cartao.saldoDisponivel) /
        Number(cartao.limite)
      ) * 100;
    },
  };
}