export function renderGenericPage(data, title) {
  return `
    <section class="page-header">
      <div>
        <h2>${title.charAt(0).toUpperCase() + title.slice(1)}</h2>
        <p class="page-description">Módulo de ${title} em construção.</p>
      </div>
    </section>
    <section class="page-content">
      <div class="empty-state">
        <p>Os dados de ${title} serão exibidos aqui em breve.</p>
      </div>
    </section>
  `;
}
