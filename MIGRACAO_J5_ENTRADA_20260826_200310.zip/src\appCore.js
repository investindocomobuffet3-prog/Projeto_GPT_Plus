import { createRouter } from './services/router.js';
import { createPages } from './pages/index.js';
import { createInsumosService } from './services/insumosService.js';
import { createFornecedoresService } from './services/fornecedoresService.js';
import { createComprasService } from './services/comprasService.js';
import { createEstoqueService } from './services/estoqueService.js';
import { createFinanceiroService } from './services/financeiroService.js';
import { createCartoesService } from './services/cartoesService.js';

export function createApp({ data }) {
  const services = {
    insumosService: createInsumosService(data),
    fornecedoresService: createFornecedoresService(data),
    comprasService: createComprasService(data),
    estoqueService: createEstoqueService(data),
    financeiroService: createFinanceiroService(data),
    cartoesService: createCartoesService(),
  };

  const pages = createPages({ data, services });
  const router = createRouter({ pages, defaultPage: 'dashboard' });

  return {
    data,
    services,
    router,
    render() {
      router.render();
    },
  };
}
