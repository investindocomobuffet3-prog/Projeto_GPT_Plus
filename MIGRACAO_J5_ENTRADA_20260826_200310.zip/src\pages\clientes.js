export function renderClientes(data) {
  const count = data.clientes?.length || 0;
  return `
    <section class="page-header">
      <div>
        <h2>Clientes</h2>
        <p class="page-description">Lista de clientes cadastrados e histórico de relacionamento.</p>
      </div>
    </section>
    <section class="page-content">
      <div class="info-box">
        <p>Total de clientes: <strong>${count}</strong></p>
      </div>
      ${count === 0 ? renderEmpty() : renderClientTable(data.clientes)}
    </section>
  `;
}

function renderEmpty() {
  return `
    <div class="empty-state">
      <p>Não há clientes registrados no backup atual.</p>
    </div>
  `;
}

function renderClientTable(clientes) {
  return `
    <div class="table-container">
      <table class="table">
        <thead>
          <tr>
            <th>Nome</th>
            <th>Contato</th>
            <th>Tipo</th>
          </tr>
        </thead>
        <tbody>
          ${clientes.map(cliente => `
            <tr>
              <td>${cliente.nome || '-'}</td>
              <td>${cliente.contato || cliente.email || '-'}</td>
              <td>${cliente.tipo || '-'}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}
