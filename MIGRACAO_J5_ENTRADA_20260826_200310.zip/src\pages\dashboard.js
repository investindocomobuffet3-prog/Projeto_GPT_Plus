﻿function n(value) {
  return Number(value || 0);
}

function todayBR() {
  return new Intl.DateTimeFormat('pt-BR').format(new Date());
}

export function renderDashboard(data) {
  const insumos = data.insumos || [];
  const compras = data.compras || [];
  const estoque = data.estoque_itens || [];
  const fichas = data.fichas || [];
  const producoes = data.producoes || [];

  const estoqueBaixo = estoque.filter(item =>
    n(item.quantidade ?? item.estoqueAtual) <= n(item.estoqueMinimo)
  );

  const comprasPendentes = compras.filter(item =>
    String(item.status || 'pendente').toLowerCase() === 'pendente'
  );

  const hoje = new Date().toISOString().slice(0, 10);
  const producoesHoje = producoes.filter(item =>
    String(item.data || item.dataProducao || '').slice(0, 10) === hoje
  );

  return `
    <div class="dashboard-module">
      <div class="modulo-header dashboard-title">
        <h2><i class="fas fa-chart-line"></i> Dashboard</h2>
      </div>

      <div class="dashboard-cards">
        ${card('Estoque Total', estoque.length, `${insumos.length} insumos cadastrados`)}
        ${card('Estoque Baixo', estoqueBaixo.length, estoqueBaixo.length ? 'Requer atenção' : 'Tudo OK', 'success')}
        ${card('Compras Pendentes', comprasPendentes.length, comprasPendentes.length ? 'Verificar compras' : 'Nenhuma pendente', 'success')}
        ${card('Produções Hoje', producoesHoje.length, todayBR(), 'success')}
      </div>

      <div class="dashboard-finance-label">Financeiro — Visão Rápida</div>

      <div class="dashboard-cards dashboard-finance">
        ${card('⚠ Contas Vencidas', 0, 'Nenhuma vencida', 'success')}
        ${card('📅 Vence Hoje', 0, 'Nada vence hoje', 'success')}
        ${card('📆 A Vencer (7 dias)', 0, 'Nada a vencer', 'success')}
        ${card('🧾 Sem Lançamento', 0, 'Todas registradas', 'success')}
      </div>

      <div class="dashboard-sections">
        ${section('fa-exclamation-triangle', 'Insumos com Estoque Baixo',
          estoqueBaixo.length ? `${estoqueBaixo.length} item(ns) requerem atenção` : '✓ Todos os insumos com estoque adequado')}
        ${section('fa-shopping-cart', 'Compras Pendentes',
          comprasPendentes.length ? `${comprasPendentes.length} compra(s) pendente(s)` : '✓ Nenhuma compra pendente')}
        ${section('fa-star', 'Insumos Mais Usados',
          fichas.length ? 'Dados disponíveis nas fichas técnicas' : 'Nenhuma ficha técnica cadastrada ainda')}
        ${section('fa-industry', 'Produções Recentes (7 dias)',
          producoes.length ? `${producoes.length} produção(ões) registrada(s)` : 'Nenhuma produção nos últimos 7 dias')}
      </div>
    </div>
  `;
}

function card(title, value, label, extra = '') {
  return `
    <div class="dashboard-card ${extra}">
      <h3>${title}</h3>
      <div class="value">${value}</div>
      <div class="label">${label}</div>
    </div>
  `;
}

function section(icon, title, text) {
  return `
    <div class="dashboard-section">
      <h3><i class="fas ${icon}"></i> ${title}</h3>
      <div class="empty-state">${text}</div>
    </div>
  `;
}
