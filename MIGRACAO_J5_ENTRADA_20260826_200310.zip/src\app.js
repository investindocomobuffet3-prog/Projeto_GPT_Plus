import { createApp } from './appCore.js';
import { loadInitialData } from './services/dataStore.js';
import { renderLayout } from './components/layout.js';

const root = document.getElementById('root');

async function init() {
  const data = await loadInitialData();
  const app = createApp({ data });
  window.app = app;
  renderLayout(root, app);
}

init().catch(error => {
  console.error('Erro ao iniciar a aplicação:', error);
  root.innerHTML = '<div class="app-error">Falha ao carregar a aplicação.</div>';
});
