function moeda(valor) {
  return Number(valor || 0).toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
}

export function renderCartoes(service) {
  const cartoes = service.listar();

  return `
    <section class="page-section">
      <div class="page-header">
        <div>
          <h2>Cartões de Crédito</h2>
          <p>Controle de limites e cartões utilizados pela operação.</p>
        </div>
      </div>

      <form id="cartao-form" class="card form-grid">
        <input type="hidden" name="id" id="cartao-id">

        <label>
          Banco
          <input name="banco" required>
        </label>

        <label>
          Limite
          <input name="limite" type="number" min="0.01" step="0.01" required>
        </label>

        <label>
          Últimos 4 dígitos
          <input name="ultimos4" maxlength="4" pattern="[0-9]{4}" required>
        </label>

        <label>
          Dia da virada
          <input name="diaVirada" type="number" min="1" max="31" value="5" required>
        </label>

        <label>
          Vencimento
          <input name="vencimento" placeholder="Ex.: dia 20" required>
        </label>

        <div>
          <button type="submit" class="btn btn-primary">Salvar cartão</button>
          <button type="button" id="cartao-cancel" class="btn">Cancelar</button>
        </div>
      </form>

      <div class="card">
        ${
          cartoes.length === 0
            ? '<p>Nenhum cartão cadastrado.</p>'
            : `
              <table class="table">
                <thead>
                  <tr>
                    <th>Banco</th>
                    <th>Limite</th>
                    <th>Disponível</th>
                    <th>% livre</th>
                    <th>Virada</th>
                    <th>Vencimento</th>
                    <th>Ações</th>
                  </tr>
                </thead>
                <tbody>
                  ${cartoes.map(cartao => {
                    const percentual =
                      service.calcularPercentualLivre(cartao);

                    return `
                      <tr>
                        <td>
                          <strong>${cartao.banco}</strong>
                          ${cartao.ultimos4 ? `<br><small>****${cartao.ultimos4}</small>` : ''}
                        </td>
                        <td>${moeda(cartao.limite)}</td>
                        <td>${moeda(cartao.saldoDisponivel)}</td>
                        <td>${percentual.toFixed(1)}%</td>
                        <td>Dia ${cartao.diaVirada}</td>
                        <td>${cartao.vencimento || '-'}</td>
                        <td>
                          <button
                            type="button"
                            class="btn edit-cartao"
                            data-id="${cartao.id}"
                          >Editar</button>

                          <button
                            type="button"
                            class="btn delete-cartao"
                            data-id="${cartao.id}"
                          >Excluir</button>
                        </td>
                      </tr>
                    `;
                  }).join('')}
                </tbody>
              </table>
            `
        }
      </div>
    </section>
  `;
}

export function attachCartoesHandlers(service, rerender) {
  const form = document.getElementById('cartao-form');

  if (!form) return;

  const cancel = document.getElementById('cartao-cancel');

  form.addEventListener('submit', event => {
    event.preventDefault();

    const dados = Object.fromEntries(new FormData(form).entries());
    const id = dados.id;

    const resultado = id
      ? service.editar(id, dados)
      : service.adicionar(dados);

    if (!resultado.sucesso) {
      alert((resultado.erros || [resultado.erro]).join('\n'));
      return;
    }

    rerender();
  });

  cancel?.addEventListener('click', () => rerender());

  document.querySelectorAll('.edit-cartao').forEach(button => {
    button.addEventListener('click', () => {
      const cartao = service.buscarPorId(button.dataset.id);

      if (!cartao) return;

      form.elements.id.value = cartao.id;
      form.elements.banco.value = cartao.banco || '';
      form.elements.limite.value = cartao.limite || '';
      form.elements.ultimos4.value = cartao.ultimos4 || '';
      form.elements.diaVirada.value = cartao.diaVirada || 5;
      form.elements.vencimento.value = cartao.vencimento || '';

      form.scrollIntoView({ behavior: 'smooth' });
    });
  });

  document.querySelectorAll('.delete-cartao').forEach(button => {
    button.addEventListener('click', () => {
      if (!confirm('Excluir este cartão?')) return;

      const resultado = service.excluir(button.dataset.id);

      if (!resultado.sucesso) {
        alert(resultado.erros.join('\n'));
        return;
      }

      rerender();
    });
  });
}