﻿export function renderHeader() {
  return `
    <header class="app-header header">
      <button class="sidebar-toggle" id="sidebar-toggle" aria-label="Menu">
        <i class="fas fa-bars"></i>
      </button>
      <h1>OBA Doceria</h1>
    </header>
  `;
}
