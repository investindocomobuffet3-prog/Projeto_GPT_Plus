import fs from "fs";
import http from "http";
import path from "path";
import os from "os";
import { spawn } from "child_process";

const root = process.argv[2];
const out = process.argv[3];
const chromePath = process.argv[4];
const resultPath = process.argv[5];

const modelBase = "https://oba-doceria.pages.dev";
const localBase = "http://127.0.0.1:8133";
const debugPort = 9334;

const modules = [
  ["Dashboard","dashboard"],
  ["Compras","compras"],
  ["Estoque","estoque"],
  ["Fichas Tecnicas","fichas"],
  ["Clientes","clientes"],
  ["Backup","backup"],
  ["Insumos","insumos"],
  ["Fornecedores","fornecedores"],
  ["Financeiro","financeiro"],
  ["Cartoes","cartoes"]
];

function mime(file) {
  const ext = path.extname(file).toLowerCase();
  return ({
    ".html":"text/html; charset=utf-8",
    ".js":"text/javascript; charset=utf-8",
    ".css":"text/css; charset=utf-8",
    ".json":"application/json; charset=utf-8",
    ".svg":"image/svg+xml",
    ".png":"image/png",
    ".jpg":"image/jpeg",
    ".jpeg":"image/jpeg"
  })[ext] || "application/octet-stream";
}

const staticRoot = path.join(root, "src");

const server = http.createServer((req,res)=>{
  try {
    let p = decodeURIComponent(new URL(req.url, localBase).pathname);
    if (p === "/") p = "/index.html";
    const file = path.normalize(path.join(staticRoot, p));
    if (!file.startsWith(path.normalize(staticRoot)) ||
        !fs.existsSync(file) ||
        !fs.statSync(file).isFile()) {
      res.writeHead(404);
      res.end("404");
      return;
    }

    const data = fs.readFileSync(file);
    res.writeHead(200,{
      "Content-Type": mime(file),
      "Content-Length": data.length,
      "Cache-Control":"no-store"
    });
    res.end(data);
  } catch {
    res.writeHead(500);
    res.end("500");
  }
});

await new Promise((resolve,reject)=>{
  server.once("error",reject);
  server.listen(8133,"127.0.0.1",resolve);
});

const profile = path.join(os.tmpdir(), `oba_j4_${Date.now()}`);
fs.mkdirSync(profile,{recursive:true});

const chrome = spawn(chromePath,[
  "--headless=new",
  "--disable-gpu",
  "--no-first-run",
  "--no-default-browser-check",
  "--disable-extensions",
  "--remote-debugging-address=127.0.0.1",
  `--remote-debugging-port=${debugPort}`,
  `--user-data-dir=${profile}`,
  "--window-size=1440,1100",
  "about:blank"
],{
  stdio:"ignore",
  windowsHide:true
});

async function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }

async function waitTargets() {
  let lastErr;
  for(let i=0;i<80;i++){
    try {
      const r = await fetch(`http://127.0.0.1:${debugPort}/json/list`);
      const arr = await r.json();
      const target = arr.find(x=>x.type==="page" && x.webSocketDebuggerUrl);
      if(target) return target;
    } catch(e){ lastErr=e; }
    await sleep(250);
  }
  throw new Error(`DevTools nao ficou pronto: ${lastErr || "timeout"}`);
}

const target = await waitTargets();
const ws = new WebSocket(target.webSocketDebuggerUrl);

await new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>reject(new Error("Timeout WebSocket CDP")),10000);
  ws.addEventListener("open",()=>{clearTimeout(timer);resolve();},{once:true});
  ws.addEventListener("error",(e)=>{clearTimeout(timer);reject(e);},{once:true});
});

let seq=0;
const pending=new Map();

ws.addEventListener("message",(event)=>{
  const msg=JSON.parse(event.data);
  if(msg.id && pending.has(msg.id)){
    const {resolve,reject}=pending.get(msg.id);
    pending.delete(msg.id);
    if(msg.error) reject(new Error(JSON.stringify(msg.error)));
    else resolve(msg.result);
  }
});

function cdp(method,params={}){
  return new Promise((resolve,reject)=>{
    const id=++seq;
    pending.set(id,{resolve,reject});
    ws.send(JSON.stringify({id,method,params}));
    setTimeout(()=>{
      if(pending.has(id)){
        pending.delete(id);
        reject(new Error(`Timeout CDP ${method}`));
      }
    },20000);
  });
}

async function evaluate(expression){
  const r=await cdp("Runtime.evaluate",{
    expression,
    returnByValue:true,
    awaitPromise:true
  });
  if(r.exceptionDetails){
    throw new Error(`Runtime.evaluate exception: ${JSON.stringify(r.exceptionDetails)}`);
  }
  return r.result?.value;
}

async function navigate(url){
  await cdp("Page.navigate",{url});
  for(let i=0;i<80;i++){
    const ready=await evaluate("document.readyState");
    if(ready==="complete") break;
    await sleep(100);
  }
  await sleep(1800);
}

async function screenshot(file){
  const r=await cdp("Page.captureScreenshot",{
    format:"png",
    captureBeyondViewport:true
  });
  fs.writeFileSync(file,Buffer.from(r.data,"base64"));
}

function cleanText(s){
  return String(s||"").replace(/\s+/g," ").trim();
}

function tokenSet(s){
  const normalized=cleanText(s)
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g,"");
  return new Set(normalized.match(/[a-z0-9][a-z0-9-]{2,}/g)||[]);
}

function similarity(a,b){
  const A=tokenSet(a), B=tokenSet(b);
  const U=new Set([...A,...B]);
  if(!U.size) return 0;
  let I=0;
  for(const x of A) if(B.has(x)) I++;
  return Math.round((I/U.size)*1000)/10;
}

await cdp("Page.enable");
await cdp("Runtime.enable");

const rows=[];

for(const [name,route] of modules){
  console.log(`----- ${name} -----`);

  // Modelo Mestre: abre home e CLICA a aba real.
  await navigate(modelBase);

  const clicked = await evaluate(`(() => {
    const el=document.querySelector('.tab-button[data-tab="${route}"]');
    if(!el) return false;
    el.click();
    return true;
  })()`);

  if(!clicked){
    throw new Error(`Aba do Modelo Mestre nao localizada: ${route}`);
  }

  await sleep(1800);

  const oldText = cleanText(await evaluate(`(() => {
    const el=document.querySelector('#app') || document.querySelector('main') || document.body;
    return el ? el.innerText : '';
  })()`));

  const oldHtml = String(await evaluate(`(() => {
    const el=document.querySelector('#app') || document.querySelector('main') || document.body;
    return el ? el.innerHTML : '';
  })()`));

  fs.writeFileSync(path.join(out,`modelo_${route}.txt`),oldText,"utf8");
  fs.writeFileSync(path.join(out,`modelo_${route}.html`),oldHtml,"utf8");
  await screenshot(path.join(out,`modelo_${route}.png`));

  // Nova versao LOCAL J1+J2.
  await navigate(`${localBase}/#${route}`);

  const newText = cleanText(await evaluate(`(() => {
    const el=document.querySelector('.app-content') || document.querySelector('main') || document.body;
    return el ? el.innerText : '';
  })()`));

  const newHtml = String(await evaluate(`(() => {
    const el=document.querySelector('.app-content') || document.querySelector('main') || document.body;
    return el ? el.innerHTML : '';
  })()`));

  fs.writeFileSync(path.join(out,`novo_${route}.txt`),newText,"utf8");
  fs.writeFileSync(path.join(out,`novo_${route}.html`),newHtml,"utf8");
  await screenshot(path.join(out,`novo_${route}.png`));

  const sim=similarity(oldText,newText);
  const sizeRatio=oldText.length
    ? Math.round((newText.length/oldText.length)*1000)/10
    : 0;

  const status = sim >= 70 && sizeRatio >= 60 && sizeRatio <= 160
    ? "PARIDADE_ALTA"
    : "DIVERGENTE";

  rows.push({
    modulo:name,
    rota:route,
    similaridadeTextoPct:sim,
    razaoTextoPct:sizeRatio,
    modeloChars:oldText.length,
    novoChars:newText.length,
    status
  });

  console.log(`Similaridade=${sim}% | texto novo/modelo=${sizeRatio}% | ${status}`);
}

fs.writeFileSync(resultPath,JSON.stringify(rows,null,2),"utf8");

try { ws.close(); } catch {}
try { chrome.kill("SIGKILL"); } catch {}
await new Promise(resolve=>server.close(resolve));

try { fs.rmSync(profile,{recursive:true,force:true}); } catch {}