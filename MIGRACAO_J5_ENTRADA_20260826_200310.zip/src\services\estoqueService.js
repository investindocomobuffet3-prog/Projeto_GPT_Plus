import { v4 as uuidv4 } from './uuid.js';
import { saveToStorage } from './storage.js';

export function createEstoqueService(data) {
  if (!Array.isArray(data.estoque_itens)) {
    data.estoque_itens = [];
  }

  if (!Array.isArray(data.estoque_mov)) {
    data.estoque_mov = [];
  }

  migrarLegadoSeNecessario();

  const state = {
    get itens() {
      return data.estoque_itens;
    },

    set itens(value) {
      data.estoque_itens = value;
    },

    get movimentacoes() {
      return data.estoque_mov;
    },

    set movimentacoes(value) {
      data.estoque_mov = value;
    },
  };

  function listarItens() {
    return state.itens;
  }

  function listarMovimentacoes() {
    return state.movimentacoes;
  }

  function buscarItemPorInsumoId(insumoId) {
    return state.itens.find(
      item => String(item.insumoId) === String(insumoId)
    ) || null;
  }

  function _recalcularCMPDoHistorico(insumoId) {
    const entradas = state.movimentacoes
      .filter(
        mov =>
          String(mov.insumoId) === String(insumoId) &&
          mov.tipo === 'entrada'
      )
      .sort(
        (a, b) => new Date(a.data) - new Date(b.data)
      );

    if (entradas.length === 0) {
      return null;
    }

    let quantidade = 0;
    let valor = 0;

    for (const entrada of entradas) {
      const qtd = Number(entrada.quantidade || 0);
      const custo = Number(entrada.custoUnitario || 0);

      if (custo < 0.0001) continue;

      quantidade += qtd;
      valor += qtd * custo;
    }

    return quantidade > 0
      ? valor / quantidade
      : 0;
  }

  function recalcularSaldoECusto(insumoId) {
    let item = buscarItemPorInsumoId(insumoId);

    if (!item) {
      item = {
        insumoId,
        quantidade: 0,
        custoMedio: 0,
        ultimaEntrada: null,
      };

      state.itens.push(item);
    }

    const entradas = state.movimentacoes.filter(
      mov =>
        String(mov.insumoId) === String(insumoId) &&
        mov.tipo === 'entrada'
    );

    const saidas = state.movimentacoes.filter(
      mov =>
        String(mov.insumoId) === String(insumoId) &&
        mov.tipo === 'saida'
    );

    const qtdEntradas =
      entradas.reduce(
        (total, mov) => total + Number(mov.quantidade || 0),
        0
      );

    const qtdSaidas =
      saidas.reduce(
        (total, mov) => total + Number(mov.quantidade || 0),
        0
      );

    item.quantidade =
      Math.max(0, qtdEntradas - qtdSaidas);

    const cmp =
      _recalcularCMPDoHistorico(insumoId);

    item.custoMedio =
      cmp !== null ? cmp : 0;

    item.ultimaEntrada =
      entradas.length
        ? entradas
            .slice()
            .sort(
              (a, b) =>
                new Date(b.data) - new Date(a.data)
            )[0].data
        : null;

    return item;
  }

  function registrarEntrada({
    insumoId,
    quantidade,
    custoUnitario,
    origem,
    referenciaId,
  }) {
    const qtd = Number(quantidade);
    const custo = Number(custoUnitario);

    if (!insumoId) {
      return {
        ok: false,
        erro: 'Insumo não informado',
      };
    }

    if (!Number.isFinite(qtd) || qtd <= 0) {
      return {
        ok: false,
        erro: 'Quantidade deve ser maior que zero',
      };
    }

    if (!Number.isFinite(custo) || custo < 0) {
      return {
        ok: false,
        erro: 'Custo unitário inválido',
      };
    }

    let item = buscarItemPorInsumoId(insumoId);

    if (!item) {
      item = {
        insumoId,
        quantidade: 0,
        custoMedio: 0,
        ultimaEntrada: null,
      };

      state.itens.push(item);
    }

    const valorAtual =
      Number(item.quantidade || 0) *
      Number(item.custoMedio || 0);

    const valorEntrada =
      qtd * custo;

    const novaQuantidade =
      Number(item.quantidade || 0) + qtd;

    item.custoMedio =
      novaQuantidade > 0
        ? (valorAtual + valorEntrada) /
          novaQuantidade
        : 0;

    item.quantidade = novaQuantidade;
    item.ultimaEntrada = new Date().toISOString();

    state.movimentacoes.push({
      id: uuidv4(),
      insumoId,
      tipo: 'entrada',
      quantidade: qtd,
      custoUnitario: custo,
      origem: origem || 'ajuste-manual',
      referenciaId: referenciaId || null,
      data: new Date().toISOString(),
      _migrado: true,
    });

    salvar();

    return { ok: true };
  }

  function registrarSaida({
    insumoId,
    quantidade,
    origem,
    referenciaId,
  }) {
    const qtd = Number(quantidade);
    const item = buscarItemPorInsumoId(insumoId);

    if (!insumoId) {
      return {
        ok: false,
        erro: 'Insumo não informado',
      };
    }

    if (!Number.isFinite(qtd) || qtd <= 0) {
      return {
        ok: false,
        erro: 'Quantidade deve ser maior que zero',
      };
    }

    if (!item || Number(item.quantidade || 0) < qtd) {
      return {
        ok: false,
        erro: 'Estoque insuficiente',
      };
    }

    item.quantidade =
      Number(item.quantidade || 0) - qtd;

    state.movimentacoes.push({
      id: uuidv4(),
      insumoId,
      tipo: 'saida',
      quantidade: qtd,
      custoUnitario: Number(item.custoMedio || 0),
      origem: origem || 'ajuste-manual',
      referenciaId: referenciaId || null,
      data: new Date().toISOString(),
      _migrado: true,
    });

    salvar();

    return { ok: true };
  }

  function compraJaRecebida(compraId) {
    return state.movimentacoes.some(
      mov =>
        mov.tipo === 'entrada' &&
        mov.origem === 'compra' &&
        String(mov.referenciaId) === String(compraId)
    );
  }

  function removerEntradasDaCompra(compraId) {
    const afetados = [
      ...new Set(
        state.movimentacoes
          .filter(
            mov =>
              mov.tipo === 'entrada' &&
              mov.origem === 'compra' &&
              String(mov.referenciaId) ===
                String(compraId)
          )
          .map(mov => mov.insumoId)
      ),
    ];

    if (afetados.length === 0) {
      return {
        sucesso: false,
        erro: 'Nenhuma entrada ativa encontrada para esta compra',
      };
    }

    state.movimentacoes =
      state.movimentacoes.filter(
        mov =>
          !(
            mov.tipo === 'entrada' &&
            mov.origem === 'compra' &&
            String(mov.referenciaId) ===
              String(compraId)
          )
      );

    afetados.forEach(
      recalcularSaldoECusto
    );

    salvar();

    return {
      sucesso: true,
      insumosAfetados: afetados,
    };
  }

  function filtrarMovimentacoes({
    insumoId,
    dataInicio,
    dataFim,
    tipo,
    origem,
  } = {}) {
    return state.movimentacoes.filter(mov => {
      if (
        insumoId &&
        String(mov.insumoId) !== String(insumoId)
      ) {
        return false;
      }

      if (tipo && mov.tipo !== tipo) return false;
      if (origem && mov.origem !== origem) return false;

      if (
        dataInicio &&
        new Date(mov.data) < new Date(dataInicio)
      ) {
        return false;
      }

      if (
        dataFim &&
        new Date(mov.data) >
          new Date(`${dataFim}T23:59:59`)
      ) {
        return false;
      }

      return true;
    });
  }

  function historicoCustoInsumo(insumoId) {
    return state.movimentacoes
      .filter(
        mov =>
          String(mov.insumoId) === String(insumoId) &&
          mov.tipo === 'entrada'
      )
      .map(mov => ({
        data: mov.data,
        custoUnitario: mov.custoUnitario,
        quantidade: mov.quantidade,
        origem: mov.origem,
        referenciaId: mov.referenciaId,
      }));
  }

  function resumoEstoque(insumos = []) {
    let valorTotal = 0;
    let itensZerados = 0;
    let itensBaixos = 0;

    state.itens.forEach(item => {
      const insumo = insumos.find(
        x =>
          String(x.id) === String(item.insumoId)
      );

      const qtd = Number(item.quantidade || 0);
      const custo = Number(item.custoMedio || 0);

      valorTotal += qtd * custo;

      if (qtd === 0) {
        itensZerados++;
      } else if (
        insumo &&
        Number(insumo.minimoDesejado || 0) > 0 &&
        qtd < Number(insumo.minimoDesejado)
      ) {
        itensBaixos++;
      }
    });

    return {
      valorTotal,
      itensZerados,
      itensBaixos,
      totalItens: state.itens.length,
    };
  }

  function migrarLegadoSeNecessario() {
    if (
      data.estoque_mov.length > 0 ||
      !Array.isArray(data.movimentacoesEstoque) ||
      data.movimentacoesEstoque.length === 0
    ) {
      return;
    }

    data.estoque_mov =
      data.movimentacoesEstoque
        .filter(mov => mov.revertida !== true)
        .map(mov => ({
          id: mov.id || uuidv4(),
          insumoId: mov.insumoId,
          tipo: mov.tipo,
          quantidade: Number(mov.quantidade || 0),
          custoUnitario: Number(mov.valorUnitario || 0),
          origem: mov.origem || 'migracao',
          referenciaId:
            mov.compraId ||
            mov.referenciaId ||
            null,
          data:
            mov.criadoEm ||
            mov.data ||
            new Date().toISOString(),
          _migrado: true,
        }));

    const ids = [
      ...new Set(
        data.estoque_mov
          .map(mov => mov.insumoId)
          .filter(Boolean)
      ),
    ];

    ids.forEach(insumoId => {
      let item =
        data.estoque_itens.find(
          x =>
            String(x.insumoId) === String(insumoId)
        );

      if (!item) {
        item = {
          insumoId,
          quantidade: 0,
          custoMedio: 0,
          ultimaEntrada: null,
        };

        data.estoque_itens.push(item);
      }
    });

    ids.forEach(recalcularSaldoECusto);
    salvar();
  }

  function salvar() {
    saveToStorage({
      estoque_itens: data.estoque_itens,
      estoque_mov: data.estoque_mov,
    });
  }


  function recalibrarCustos(compras = [], insumos = []) {
    let atualizados = 0;
    state.movimentacoes.filter(m => m.tipo === 'entrada' && m.origem === 'compra' && m.referenciaId).forEach(m => {
      const compra = compras.find(c => String(c.id) === String(m.referenciaId)); if (!compra) return;
      const item = (compra.itens || []).find(i => String(i.insumoId) === String(m.insumoId)); if (!item) return;
      const insumo = insumos.find(i => String(i.id) === String(m.insumoId)); const qtdEmb = Number(insumo?.qtdPorEmbalagem || 0);
      let custo = Number(item.precoUnitarioLiquido ?? item.precoUnitario ?? item.valorUnitario ?? 0);
      if (Number(item.precoEmbalagem) > 0 && qtdEmb > 0) custo = Number(item.precoEmbalagem) / qtdEmb;
      if (custo > 0 && Math.abs(Number(m.custoUnitario || 0) - custo) > 0.000001) { m.custoUnitario = custo; atualizados++; }
    });
    state.itens.forEach(item => { const custo = _recalcularCMPDoHistorico(item.insumoId); if (custo !== null) item.custoMedio = custo; });
    salvar(); return { sucesso: true, atualizados };
  }
  return {
    state,
    salvar,
    listarItens,
    listarMovimentacoes,
    buscarItemPorInsumoId,
    registrarEntrada,
    registrarSaida,
    compraJaRecebida,
    removerEntradasDaCompra,
    filtrarMovimentacoes,
    historicoCustoInsumo,
    resumoEstoque,
    recalibrarCustos,
    _recalcularCMPDoHistorico,

    // Compatibilidade antiga.
    listMovimentacoes: listarMovimentacoes,
  };
}