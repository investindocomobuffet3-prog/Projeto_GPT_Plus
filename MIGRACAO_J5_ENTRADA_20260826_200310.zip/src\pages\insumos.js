let editandoId = null;

export function renderInsumos(
  insumos = [],
  tipos = []
) {
  const item =
    editandoId
      ? insumos.find(
          i =>
            String(i.id) ===
            String(editandoId)
        ) || null
      : null;

  return `
    <h2 class="insumos-page-title">Insumos</h2>

    <section class="page-content">

      <section class="card card-form">

        <h3>
          ${item
            ? 'Editar Insumo'
            : 'Novo Insumo'}
        </h3>

        <form id="form-insumo">

          <input
            type="hidden"
            name="id"
            value="${escapeHtml(
              item?.id || ''
            )}"
          />

          <div class="form-row">

            <div class="form-group">
              <label>Nome *</label>

              <input
                type="text"
                name="nome"
                class="form-control"
                required
                value="${escapeHtml(
                  item?.nome || ''
                )}"
              />
            </div>

            <div class="form-group">
              <label>Marca *</label>

              <input
                type="text"
                name="marca"
                class="form-control"
                required
                value="${escapeHtml(
                  item?.marca || ''
                )}"
              />
            </div>

            <div class="form-group">
              <label>Tipo *</label>

              <div
                style="
                  display:flex;
                  gap:0.5rem;
                "
              >
                <select
                  name="tipo"
                  class="form-control"
                  required
                  style="flex:1"
                >
                  <option value="">
                    Selecione...
                  </option>

                  ${tipos
                    .map(
                      tipo => `
                        <option
                          value="${escapeHtml(
                            tipo.id
                          )}"
                          ${
                            item?.tipo ===
                            tipo.id
                              ? 'selected'
                              : ''
                          }
                        >
                          ${escapeHtml(
                            tipo.nome
                          )}
                        </option>
                      `
                    )
                    .join('')}
                </select>

                <button
                  type="button"
                  id="btn-novo-tipo"
                  class="btn btn-secondary"
                >
                  + Tipo
                </button>

              </div>
            </div>

          </div>

          <div class="form-row">

            <div class="form-group">
              <label>Unidade *</label>

              <select
                name="unidade"
                class="form-control"
                required
              >
                ${renderUnidades(
                  item?.unidade
                )}
              </select>
            </div>

            <div class="form-group">
              <label>
                Conteúdo da embalagem
              </label>

              <input
                type="number"
                name="qtdPorEmbalagem"
                class="form-control"
                step="0.01"
                min="0"
                value="${numberValue(
                  item?.qtdPorEmbalagem
                )}"
              />
            </div>

            <div class="form-group">

              <label>
                Embalagem
              </label>

              <div
                style="
                  display:grid;
                  grid-template-columns:minmax(0,1fr) auto;
                  gap:0.5rem;
                "
              >

                <select
                  name="nomeEmbalagem"
                  id="select-embalagem"
                  class="form-control"
                  data-current="${escapeHtml(
                    item?.nomeEmbalagem || ''
                  )}"
                >
                  <option value="">
                    Selecione...
                  </option>
                </select>

                <button
                  type="button"
                  id="btn-nova-embalagem"
                  class="btn btn-secondary"
                >
                  + Embalagem
                </button>

              </div>

            </div>

            <div class="form-group">
              <label>
                Mínimo desejado
              </label>

              <input
                type="number"
                name="minimoDesejado"
                class="form-control"
                step="0.01"
                min="0"
                value="${numberValue(
                  item?.minimoDesejado
                )}"
              />
            </div>

          </div>

          <div class="form-row">

            <div
              class="
                form-group
                full-width
              "
            >
              <label>
                Observações
              </label>

              <textarea
                name="observacoes"
                class="form-control"
                rows="2"
              >${escapeHtml(
                item?.observacoes ||
                  ''
              )}</textarea>
            </div>

          </div>

          <div class="form-actions">

            <button
              type="submit"
              class="btn btn-primary"
            >
              ${item
                ? 'Salvar'
                : 'Adicionar'}
            </button>

            ${
              item
                ? `
                  <button
                    type="button"
                    id="btn-cancelar-insumo"
                    class="btn btn-secondary"
                  >
                    Cancelar
                  </button>
                `
                : ''
            }

          </div>

          <div
            id="form-errors"
            style="
              color:#e74c3c;
              margin-top:0.5rem;
              font-size:0.875rem;
            "
          ></div>

        </form>
      </section>

      <section class="card">

        <div
          style="
            display:flex;
            justify-content:space-between;
            align-items:center;
          "
        >
          <h3>
            Insumos Cadastrados
          </h3>

          <button
            type="button"
            id="btn-exportar-insumos"
            class="btn btn-secondary"
          >
            ⇩ Exportar
          </button>
        </div>

        <div class="table-container">

          <table class="table">

            <thead>
              <tr>
                <th>Nome</th>
                <th>Marca</th>
                <th>Tipo</th>
                <th>Conteúdo da embalagem</th>
                <th>Unidade</th>
                <th>Mínimo</th>
                <th>Ações</th>
              </tr>
            </thead>

            <tbody>

              ${
                insumos.length
                  ? [...insumos]
                      .sort(
                        (a, b) =>
                          String(
                            a.nome ||
                            ''
                          ).localeCompare(
                            String(
                              b.nome ||
                              ''
                            ),
                            'pt-BR'
                          )
                      )
                      .map(
                        i => {

                          const tipo =
                            tipos.find(
                              t =>
                                t.id ===
                                i.tipo
                            );

                          return `
                            <tr>

                              <td>
                                ${escapeHtml(
                                  i.nome
                                )}
                              </td>

                              <td>
                                ${escapeHtml(
                                  i.marca ||
                                  '-'
                                )}
                              </td>

                              <td>
                                ${escapeHtml(
                                  tipo?.nome ||
                                  i.tipo ||
                                  '-'
                                )}
                              </td>

                              <td>
                                ${
                                  i.qtdPorEmbalagem ||
                                  '-'
                                }
                              </td>

                              <td>
                                ${escapeHtml(
                                  i.unidade
                                )}
                              </td>

                              <td>
                                ${
                                  i.minimoDesejado ||
                                  '-'
                                }
                              </td>

                              <td
                                style="
                                  white-space:nowrap;
                                "
                              >

                                <button
                                  type="button"
                                  class="
                                    btn
                                    btn-secondary
                                    btn-edit-insumo
                                  "
                                  data-id="${escapeHtml(
                                    i.id
                                  )}"
                                >
                                  Editar
                                </button>

                                <button
                                  type="button"
                                  class="
                                    btn
                                    btn-danger
                                    btn-delete-insumo
                                  "
                                  data-id="${escapeHtml(
                                    i.id
                                  )}"
                                >
                                  Excluir
                                </button>

                              </td>

                            </tr>
                          `;
                        }
                      )
                      .join('')
                  : `
                    <tr>
                      <td
                        colspan="7"
                        class="empty-state"
                      >
                        Nenhum insumo cadastrado
                      </td>
                    </tr>
                  `
              }

            </tbody>

          </table>

        </div>

      </section>

    </section>
  `;
}

export function attachInsumosHandlers(
  service,
  rerender
) {
  const form =
    document.getElementById(
      'form-insumo'
    );

  if (form) {

    form.addEventListener(
      'submit',
      event => {

        event.preventDefault();

        const fd =
          new FormData(form);

        const payload = {
          nome:
            fd.get('nome'),

          marca:
            fd.get('marca'),

          tipo:
            fd.get('tipo'),

          unidade:
            fd.get('unidade'),

          qtdPorEmbalagem:
            fd.get(
              'qtdPorEmbalagem'
            )
              ? Number(
                  fd.get(
                    'qtdPorEmbalagem'
                  )
                )
              : 0,

          nomeEmbalagem:
            fd.get(
              'nomeEmbalagem'
            ),

          minimoDesejado:
            fd.get(
              'minimoDesejado'
            )
              ? Number(
                  fd.get(
                    'minimoDesejado'
                  )
                )
              : 0,

          observacoes:
            fd.get(
              'observacoes'
            ),
        };

        const id =
          fd.get('id');

        const resultado =
          id
            ? service.editar(
                id,
                payload
              )
            : service.adicionar(
                payload
              );

        const erros =
          document.getElementById(
            'form-errors'
          );

        if (
          !resultado.sucesso
        ) {

          if (erros) {

            erros.textContent =
              (
                resultado.erros ||
                ['Erro ao salvar']
              ).join(' | ');
          }

          return;
        }

        editandoId = null;
        rerender();
      }
    );
  }

  document
    .querySelectorAll(
      '.btn-edit-insumo'
    )
    .forEach(
      button => {

        button.addEventListener(
          'click',
          () => {

            editandoId =
              button.dataset.id;

            rerender();
          }
        );
      }
    );

  document
    .querySelectorAll(
      '.btn-delete-insumo'
    )
    .forEach(
      button => {

        button.addEventListener(
          'click',
          () => {

            const existente =
              document.getElementById(
                'modal-excluir-insumo'
              );

            if (existente) {
              existente.remove();
            }

            const overlay =
              document.createElement(
                'div'
              );

            overlay.id =
              'modal-excluir-insumo';

            overlay.className =
              'confirm-overlay';

            overlay.innerHTML = `
              <div
                class="confirm-dialog"
                role="dialog"
                aria-modal="true"
                aria-labelledby="confirm-excluir-titulo"
              >
                <h3 id="confirm-excluir-titulo">
                  Excluir insumo?
                </h3>

                <p>
                  Esta ação removerá o insumo selecionado.
                </p>

                <div class="confirm-actions">
                  <button
                    type="button"
                    class="btn btn-secondary"
                    id="confirm-excluir-cancelar"
                  >
                    Cancelar
                  </button>

                  <button
                    type="button"
                    class="btn btn-danger"
                    id="confirm-excluir-ok"
                  >
                    Excluir
                  </button>
                </div>
              </div>
            `;

            document.body.appendChild(
              overlay
            );

            const cancelarModal =
              document.getElementById(
                'confirm-excluir-cancelar'
              );

            const excluirModal =
              document.getElementById(
                'confirm-excluir-ok'
              );

            cancelarModal.addEventListener(
              'click',
              () => {
                overlay.remove();
              }
            );

            excluirModal.addEventListener(
              'click',
              () => {

                service.remover(
                  button.dataset.id
                );

                overlay.remove();

                editandoId = null;
                rerender();
              }
            );

            excluirModal.focus();
          }
        );
      }
    );

  const cancelar =
    document.getElementById(
      'btn-cancelar-insumo'
    );

  if (cancelar) {

    cancelar.addEventListener(
      'click',
      () => {

        editandoId = null;
        rerender();
      }
    );
  }

  const novoTipo =
    document.getElementById(
      'btn-novo-tipo'
    );

  if (novoTipo) {

    novoTipo.addEventListener(
      'click',
      () => {

        const nome =
          prompt(
            'Nome do novo tipo:'
          );

        if (!nome) {
          return;
        }

        service
          .adicionarTipoCustomizado(
            nome
          );

        rerender();
      }
    );
  }

  const selectEmbalagem =
    document.getElementById(
      'select-embalagem'
    );

  const atualizarEmbalagens = (
    selecionada = ''
  ) => {

    if (!selectEmbalagem) {
      return;
    }

    const lista =
      service.obterEmbalagens();

    selectEmbalagem.innerHTML = `
      <option value="">
        Selecione...
      </option>

      ${lista
        .map(
          embalagem => `
            <option
              value="${escapeHtml(
                embalagem
              )}"
            >
              ${escapeHtml(
                embalagem
              )}
            </option>
          `
        )
        .join('')}
    `;

    if (
      selecionada &&
      !lista.includes(selecionada)
    ) {

      const option =
        document.createElement(
          'option'
        );

      option.value = selecionada;
      option.textContent = selecionada;

      selectEmbalagem.appendChild(
        option
      );
    }

    selectEmbalagem.value =
      selecionada || '';
  };

  if (selectEmbalagem) {

    atualizarEmbalagens(
      selectEmbalagem.dataset.current || ''
    );
  }

  const novaEmbalagem =
    document.getElementById(
      'btn-nova-embalagem'
    );

  if (novaEmbalagem) {

    novaEmbalagem.addEventListener(
      'click',
      () => {

        const existente =
          document.getElementById(
            'modal-nova-embalagem'
          );

        if (existente) {
          existente.remove();
        }

        const overlay =
          document.createElement(
            'div'
          );

        overlay.id =
          'modal-nova-embalagem';

        overlay.className =
          'confirm-overlay';

        overlay.innerHTML = `
          <div
            class="confirm-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="nova-embalagem-titulo"
          >

            <h3 id="nova-embalagem-titulo">
              Nova embalagem
            </h3>

            <label
              for="nova-embalagem-nome"
              style="
                display:block;
                margin-bottom:0.35rem;
                font-weight:600;
              "
            >
              Nome da embalagem
            </label>

            <input
              type="text"
              id="nova-embalagem-nome"
              class="form-control"
              placeholder="Ex.: Bisnaga"
              autocomplete="off"
            />

            <div
              class="confirm-actions"
              style="margin-top:1rem;"
            >

              <button
                type="button"
                class="btn btn-secondary"
                id="nova-embalagem-cancelar"
              >
                Cancelar
              </button>

              <button
                type="button"
                class="btn btn-primary"
                id="nova-embalagem-adicionar"
              >
                Adicionar
              </button>

            </div>

          </div>
        `;

        document.body.appendChild(
          overlay
        );

        const input =
          document.getElementById(
            'nova-embalagem-nome'
          );

        const cancelarModal =
          document.getElementById(
            'nova-embalagem-cancelar'
          );

        const adicionarModal =
          document.getElementById(
            'nova-embalagem-adicionar'
          );

        const concluir = () => {

          const nome =
            String(
              input.value || ''
            ).trim();

          if (!nome) {
            input.focus();
            return;
          }

          const criada =
            service
              .adicionarEmbalagemCustomizada(
                nome
              );

          if (!criada) {
            input.focus();
            return;
          }

          overlay.remove();

          atualizarEmbalagens(
            criada
          );
        };

        cancelarModal.addEventListener(
          'click',
          () => {
            overlay.remove();
          }
        );

        adicionarModal.addEventListener(
          'click',
          concluir
        );

        input.addEventListener(
          'keydown',
          event => {

            if (event.key === 'Enter') {
              event.preventDefault();
              concluir();
            }
          }
        );

        input.focus();
      }
    );
  }
  const exportar =
    document.getElementById(
      'btn-exportar-insumos'
    );

  if (exportar) {

    exportar.addEventListener(
      'click',
      () => {

        const tipos =
          service.obterTipos();

        const linhas =
          service.listar()
            .map(
              item => {

                const tipo =
                  tipos.find(
                    t =>
                      t.id ===
                      item.tipo
                  );

                return {
                  nome:
                    item.nome,

                  marca:
                    item.marca,

                  tipo:
                    tipo?.nome ||
                    item.tipo,

                  qtdPorEmbalagem:
                    item.qtdPorEmbalagem,

                  nomeEmbalagem:
                    item.nomeEmbalagem,

                  unidade:
                    item.unidade,

                  minimoDesejado:
                    item.minimoDesejado,

                  observacoes:
                    item.observacoes,
                };
              }
            );

        exportCSV(
          linhas
        );
      }
    );
  }
}

function exportCSV(lista) {
  const colunas = [
    'Nome',
    'Marca',
    'Tipo',
    'Conteúdo da embalagem',
    'Embalagem',
    'Unidade',
    'Mínimo',
    'Observações',
  ];

  const linhas =
    lista.map(
      i => [
        i.nome,
        i.marca,
        i.tipo,
        i.qtdPorEmbalagem,
        i.nomeEmbalagem,
        i.unidade,
        i.minimoDesejado,
        i.observacoes,
      ]
    );

  const escape = value => {
    const text =
      String(value ?? '');

    if (
      text.includes(';') ||
      text.includes('"') ||
      text.includes('\n')
    ) {
      return `"${text.replace(
        /"/g,
        '""'
      )}"`;
    }

    return text;
  };

  const csv =
    '\uFEFF' +
    [
      colunas
        .map(escape)
        .join(';'),

      ...linhas.map(
        linha =>
          linha
            .map(escape)
            .join(';')
      ),
    ].join('\r\n');

  const blob =
    new Blob(
      [csv],
      {
        type:
          'text/csv;charset=utf-8;',
      }
    );

  const url =
    URL.createObjectURL(blob);

  const a =
    document.createElement('a');

  a.href = url;

  a.download =
    `insumos-${
      new Date()
        .toISOString()
        .slice(0, 10)
        .replace(/-/g, '')
    }.csv`;

  document.body.appendChild(a);
  a.click();
  a.remove();

  URL.revokeObjectURL(url);
}

function renderUnidades(atual = '') {
  const unidades = [
    ['', 'Selecione...'],
    ['g', 'g (gramas)'],
    ['kg', 'kg (quilogramas)'],
    ['ml', 'ml (mililitros)'],
    ['L', 'L (litros)'],
    ['un', 'un (unidades)'],
  ];

  return unidades
    .map(
      ([value, label]) => `
        <option
          value="${value}"
          ${
            atual === value
              ? 'selected'
              : ''
          }
        >
          ${label}
        </option>
      `
    )
    .join('');
}

function numberValue(value) {
  const n =
    Number(value);

  return Number.isFinite(n) &&
    n !== 0
    ? n
    : '';
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
