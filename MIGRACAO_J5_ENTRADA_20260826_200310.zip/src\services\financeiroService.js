import { storageProvider } from './storage.js';

function generateId() {
  if (globalThis.crypto?.randomUUID) {
    return globalThis.crypto.randomUUID();
  }

  return `fin-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function dateToISO(date) {
  const ano = date.getFullYear();
  const mes = String(date.getMonth() + 1).padStart(2, '0');
  const dia = String(date.getDate()).padStart(2, '0');
  return `${ano}-${mes}-${dia}`;
}

function hojeISO() {
  return dateToISO(new Date());
}

export function createFinanceiroService(sharedStore = null) {
  function listarPersistidos() {
    if (
      sharedStore &&
      Array.isArray(sharedStore.financeiro)
    ) {
      return sharedStore.financeiro;
    }

    const persisted =
      storageProvider.get('financeiro') || [];

    if (sharedStore) {
      sharedStore.financeiro = persisted;
    }

    return persisted;
  }

  function persistFinanceiro(lancamentos) {
    const next = Array.isArray(lancamentos)
      ? [...lancamentos]
      : [];

    if (sharedStore) {
      sharedStore.financeiro = next;
    }

    storageProvider.save('financeiro', next);

    return next;
  }

  const service = {
    listar() {
      return listarPersistidos();
    },

    listarPorCompra(compraId) {
      return this.listar().filter(item => item.compraId === compraId);
    },

    buscarPorId(id) {
      return this.listar().find(item => item.id === id) || null;
    },

    lancarCompra(compra, comprasService, opcoes = {}) {
      if (!compra) {
        return {
          sucesso: false,
          erro: 'Compra não encontrada',
        };
      }

      const existentes = this.listarPorCompra(compra.id);

      if (existentes.length > 0) {
        const existente = existentes[0];

        if (
          comprasService &&
          compra.lancamentoFinanceiroId !== existente.id
        ) {
          comprasService.vincularLancamentoFinanceiro(
            compra.id,
            existente.id
          );
        }

        return {
          sucesso: false,
          erro: 'Esta compra já possui lançamento financeiro',
          lancamento: existente,
        };
      }

      const valor = Number(
        compra.total !== undefined
          ? compra.total
          : compra.valor
      ) || 0;

      if (valor <= 0) {
        return {
          sucesso: false,
          erro: 'A compra não possui valor válido',
        };
      }

      const primeiroVencimento =
        opcoes.primeiroVencimento ||
        compra.data ||
        hojeISO();

      const quantidadeParcelas =
        Math.max(1, Number(opcoes.parcelas || 1));

      const parcelas = this.gerarParcelas(
        valor,
        quantidadeParcelas,
        primeiroVencimento
      );

      const cartaoId = opcoes.cartaoId || null;
      const cartoesService = opcoes.cartoesService || null;
      let creditoConsumido = false;

      if (cartaoId) {
        if (!cartoesService) {
          return {
            sucesso: false,
            erro: 'Serviço de cartões não disponível',
          };
        }

        const usoCredito = cartoesService.usarCredito(
          cartaoId,
          valor,
          compra.id
        );

        if (!usoCredito.sucesso) {
          return {
            sucesso: false,
            erro:
              usoCredito.erro ||
              'Não foi possível utilizar o crédito do cartão',
          };
        }

        creditoConsumido = true;
      }

      const resultado = this.adicionarLancamento({
        tipo: 'pagar',
        origem: 'compra',
        compraId: compra.id,
        fornecedorId: compra.fornecedorId || null,
        valorTotal: valor,
        meioPagamento:
          opcoes.meioPagamento ||
          (cartaoId ? 'cartao_credito' : ''),
        cartaoId,
        parcelas,
      });

      if (!resultado.sucesso) {
        if (
          creditoConsumido &&
          cartoesService &&
          cartaoId
        ) {
          cartoesService.liberarCredito(
            cartaoId,
            valor,
            compra.id
          );
        }

        return resultado;
      }

      if (comprasService) {
        const vinculo =
          comprasService.vincularLancamentoFinanceiro(
            compra.id,
            resultado.lancamento.id
          );

        if (!vinculo.sucesso) {
          this.excluirLancamento(resultado.lancamento.id);

          if (
            creditoConsumido &&
            cartoesService &&
            cartaoId
          ) {
            cartoesService.liberarCredito(
              cartaoId,
              valor,
              compra.id
            );
          }

          return {
            sucesso: false,
            erro:
              vinculo.erro ||
              'Falha ao vincular compra',
          };
        }
      }

      return resultado;
    },
    adicionarLancamento(payload) {
      const lancamentos = this.listar();

      const lancamento = {
        id: generateId(),
        tipo: payload.tipo || 'pagar',
        origem: payload.origem || 'compra',
        compraId: payload.compraId || null,
        fornecedorId: payload.fornecedorId || null,
        clienteNome: payload.clienteNome || null,
        valorTotal: Number(payload.valorTotal) || 0,
        meioPagamento: payload.meioPagamento || '',
        cartaoId: payload.cartaoId || null,
        parcelas: (payload.parcelas || []).map((parcela, index) => ({
          n: parcela.n || index + 1,
          valor: Number(parcela.valor) || 0,
          vencimento: parcela.vencimento || '',
          status: parcela.status || 'pendente',
          pagoEm: parcela.pagoEm || null,
        })),
        criadoEm: new Date().toISOString(),
        atualizadoEm: null,
      };

      lancamentos.push(lancamento);
      persistFinanceiro(lancamentos);

      return { sucesso: true, lancamento };
    },

    marcarParcelaComoPaga(id, numero, opcoes = {}) {
      const lancamentos = this.listar();
      const lancamento = lancamentos.find(item => item.id === id);

      if (!lancamento) {
        return { sucesso: false, erro: 'Lançamento não encontrado' };
      }

      const parcela = (lancamento.parcelas || [])
        .find(item => Number(item.n) === Number(numero));

      if (!parcela) {
        return { sucesso: false, erro: 'Parcela não encontrada' };
      }

      parcela.status = 'pago';
      parcela.pagoEm = opcoes.dataPagamento || new Date().toISOString();

      if (opcoes.meioPagamentoReal) {
        lancamento.meioPagamento = opcoes.meioPagamentoReal;
      }

      lancamento.atualizadoEm = new Date().toISOString();

      persistFinanceiro(lancamentos);

      return { sucesso: true, lancamento };
    },

    desfazerBaixaParcela(id, numero) {
      const lancamentos = this.listar();
      const lancamento = lancamentos.find(item => item.id === id);

      if (!lancamento) {
        return { sucesso: false, erro: 'Lançamento não encontrado' };
      }

      const parcela = (lancamento.parcelas || [])
        .find(item => Number(item.n) === Number(numero));

      if (!parcela) {
        return { sucesso: false, erro: 'Parcela não encontrada' };
      }

      if (parcela.status !== 'pago') {
        return { sucesso: false, erro: 'A parcela não está paga' };
      }

      parcela.status = 'pendente';
      parcela.pagoEm = null;
      lancamento.atualizadoEm = new Date().toISOString();

      persistFinanceiro(lancamentos);

      return { sucesso: true, lancamento };
    },

    gerarParcelas(valorTotal, quantidade, primeiroVencimento) {
      const total = Number(valorTotal);
      const numeroParcelas = Number(quantidade);

      if (!total || !numeroParcelas || !primeiroVencimento) {
        return [];
      }

      const valorBase =
        Math.round((total / numeroParcelas) * 100) / 100;

      const parcelas = [];
      const inicio = new Date(`${primeiroVencimento}T12:00:00`);

      for (let index = 0; index < numeroParcelas; index += 1) {
        const data = new Date(inicio);
        data.setMonth(data.getMonth() + index);

        const valor =
          index === numeroParcelas - 1
            ? Math.round(
                (total - valorBase * (numeroParcelas - 1)) * 100
              ) / 100
            : valorBase;

        parcelas.push({
          n: index + 1,
          valor,
          vencimento: dateToISO(data),
          status: 'pendente',
          pagoEm: null,
        });
      }

      return parcelas;
    },

    listarVencidos() {
      const hoje = hojeISO();

      return this.listar().filter(lancamento =>
        (lancamento.parcelas || []).some(
          parcela =>
            parcela.status === 'pendente' &&
            parcela.vencimento &&
            parcela.vencimento < hoje
        )
      );
    },

    listarAVencer(dias = 7) {
      const inicio = new Date();
      const fim = new Date();

      fim.setDate(fim.getDate() + dias);

      const de = dateToISO(inicio);
      const ate = dateToISO(fim);

      return this.listar().filter(lancamento =>
        (lancamento.parcelas || []).some(
          parcela =>
            parcela.status === 'pendente' &&
            parcela.vencimento >= de &&
            parcela.vencimento <= ate
        )
      );
    },

    excluirLancamento(id) {
      const lancamentos = this.listar();
      const index = lancamentos.findIndex(item => item.id === id);

      if (index === -1) {
        return { sucesso: false, erro: 'Lançamento não encontrado' };
      }

      const removido = lancamentos[index];
      lancamentos.splice(index, 1);

      persistFinanceiro(lancamentos);

      return {
        sucesso: true,
        compraId: removido.compraId,
      };
    },

    estornarLancamento(
      id,
      comprasService,
      cartoesService
    ) {
      const lancamento = this.buscarPorId(id);

      if (!lancamento) {
        return {
          sucesso: false,
          erro: 'Lançamento não encontrado',
        };
      }

      const possuiParcelaPaga =
        (lancamento.parcelas || [])
          .some(parcela => parcela.status === 'pago');

      if (possuiParcelaPaga) {
        return {
          sucesso: false,
          erro:
            'Existem parcelas pagas. ' +
            'Desfaça as baixas antes de estornar o lançamento.',
        };
      }

      const compraId = lancamento.compraId || null;
      const cartaoId = lancamento.cartaoId || null;
      const valor = Number(lancamento.valorTotal) || 0;

      let creditoLiberado = false;

      if (
        cartaoId &&
        valor > 0
      ) {
        if (!cartoesService) {
          return {
            sucesso: false,
            erro: 'Serviço de cartões não disponível para o estorno',
          };
        }

        const liberacao = cartoesService.liberarCredito(
          cartaoId,
          valor,
          compraId
        );

        if (!liberacao.sucesso) {
          return {
            sucesso: false,
            erro:
              liberacao.erro ||
              'Não foi possível devolver o crédito ao cartão',
          };
        }

        creditoLiberado = true;
      }

      if (
        compraId &&
        comprasService
      ) {
        const desvinculo =
          comprasService.desvincularLancamentoFinanceiro(
            compraId
          );

        if (!desvinculo.sucesso) {
          if (
            creditoLiberado &&
            cartaoId &&
            cartoesService
          ) {
            cartoesService.usarCredito(
              cartaoId,
              valor,
              compraId
            );
          }

          return {
            sucesso: false,
            erro:
              desvinculo.erro ||
              'Não foi possível desvincular a compra',
          };
        }
      }

      const exclusao = this.excluirLancamento(id);

      if (!exclusao.sucesso) {
        if (
          compraId &&
          comprasService
        ) {
          comprasService.vincularLancamentoFinanceiro(
            compraId,
            id
          );
        }

        if (
          creditoLiberado &&
          cartaoId &&
          cartoesService
        ) {
          cartoesService.usarCredito(
            cartaoId,
            valor,
            compraId
          );
        }

        return {
          sucesso: false,
          erro:
            exclusao.erro ||
            'Não foi possível excluir o lançamento',
        };
      }

      return {
        sucesso: true,
        lancamento,
        compraId,
        cartaoId,
        creditoLiberado,
      };
    },
    limparDuplicatas() {
      const lancamentos = this.listar();
      const porCompra = {};

      lancamentos.forEach(item => {
        if (!item.compraId) return;

        porCompra[item.compraId] ||= [];
        porCompra[item.compraId].push(item);
      });

      const remover = new Set();
      const comprasAfetadas = [];

      Object.entries(porCompra).forEach(([compraId, itens]) => {
        if (itens.length <= 1) return;

        itens.sort((a, b) =>
          (b.criadoEm || '').localeCompare(a.criadoEm || '')
        );

        itens.slice(1).forEach(item => remover.add(item.id));

        comprasAfetadas.push({
          compraId,
          manter: itens[0].id,
        });
      });

      if (remover.size === 0) {
        return {
          removidos: 0,
          comprasAfetadas: [],
        };
      }

      persistFinanceiro(
        lancamentos.filter(item => !remover.has(item.id))
      );

      return {
        removidos: remover.size,
        comprasAfetadas,
      };
    },
  };

  return service;
}