let filtroNome = '';
let filtroTipo = '';
let filtroSituacao = '';
let ordemCol = 'nome';
let ordemDir = 'asc';
let abaAtiva = 'movimentacoes';

let movDataIni = '';
let movDataFim = '';
let movInsumo = '';
let movTipo = '';

let histInsumo = '';

let crelDataIni = '';
let crelDataFim = '';
let crelFornecedor = '';
let crelInsumo = '';

export function renderEstoque(
  estoqueService,
  insumosService,
  comprasService,
  fornecedoresService
) {
  const insumos = insumosService.listar();
  const itens = estoqueService.listarItens();
  const resumo = estoqueService.resumoEstoque(insumos);

  return `
    <section class="est-wrap">
      ${styles()}

      <div class="est-cards">
        ${card(resumo.totalItens, 'Itens em estoque')}
        ${card(money(resumo.valorTotal), 'Valor total em estoque')}
        ${card(resumo.itensBaixos, 'Abaixo do m\u00ednimo', 'est-card-warn')}
        ${card(resumo.itensZerados, 'Itens zerados', 'est-card-danger')}
      </div>

      <section class="est-box">
        <div class="est-box-header">
          <strong>Estoque Atual</strong>
          <div class="est-actions">
            <button type="button" id="est-recalibrar" class="btn btn-secondary">&#8635; Recalibrar Custos</button>
            <button type="button" id="est-exportar" class="btn btn-secondary">&#8681; Exportar</button>
          </div>
        </div>

        <div class="est-filtros">
          <input id="est-busca" class="est-input" placeholder="Buscar insumo..." value="${esc(filtroNome)}">
          <select id="est-filtro-tipo" class="est-input">${tipoOptions(insumosService, filtroTipo, 'Todos os tipos')}</select>
          <select id="est-filtro-sit" class="est-input">
            <option value="">Todas situa\u00e7\u00f5es</option>
            <option value="ok" ${sel(filtroSituacao,'ok')}>OK</option>
            <option value="baixo" ${sel(filtroSituacao,'baixo')}>Estoque baixo</option>
            <option value="zerado" ${sel(filtroSituacao,'zerado')}>Zerado</option>
          </select>
          <button id="est-limpar" type="button" class="btn btn-secondary">Limpar</button>
        </div>

        <div id="est-tabela-wrap">
          ${renderTabela(itens, insumos, insumosService)}
        </div>
      </section>

      <section class="est-box">
        <div class="est-box-header">
          <strong>Entrada Manual de Estoque</strong>
        </div>

        <form id="est-form-entrada" class="est-form-row">
          <div class="est-fg est-fg-insumo">
            <label>Insumo *</label>
            <div class="est-inline">
              <select id="est-insumo" name="insumo" class="est-input" required>
                <option value="">Selecione...</option>
                ${insumos.map(i => `<option value="${esc(i.id)}">${esc(i.nome)}</option>`).join('')}
              </select>
              <button type="button" id="btn-novo-insumo" class="btn btn-secondary">+ Novo</button>
            </div>
          </div>

          <div class="est-fg">
            <label id="lbl-qtd-manual">Quantidade *</label>
            <input id="quantidade" name="quantidade" type="number" min="0.01" step="0.01" class="est-input" required>
          </div>

          <div class="est-fg">
            <label id="lbl-preco-manual">Custo unit\u00e1rio (R$) <small>opcional</small></label>
            <input id="custoUnitario" name="custoUnitario" type="number" min="0" step="0.0001" class="est-input">
            <small id="est-custo-help">mant\u00e9m custo atual se vazio</small>
          </div>

          <div class="est-fg">
            <label>Origem</label>
            <select id="origem" name="origem" class="est-input">
              <option value="ajuste-manual">Ajuste manual</option>
              <option value="outro">Outro</option>
            </select>
          </div>

          <button type="submit" class="btn btn-primary">Registrar entrada</button>
        </form>

        <div id="fg-resumo-manual" class="est-resumo-manual" style="display:none">
          <span id="resumo-entrada-manual"></span>
        </div>
      </section>

      <section class="est-box">
        <div class="est-box-header"><strong>Relat\u00f3rios e Pesquisas</strong></div>

        <div class="est-tabs">
          ${tabButton('movimentacoes','Movimenta\u00e7\u00f5es')}
          ${tabButton('historico','Hist\u00f3rico de Pre\u00e7os')}
          ${tabButton('compras','Compras por Per\u00edodo')}
          ${tabButton('reposicao','Lista de Reposi\u00e7\u00e3o')}
        </div>

        <div id="est-tab-content">
          ${renderTab(estoqueService, insumosService, comprasService, fornecedoresService)}
        </div>
      </section>

      ${renderModalNovoInsumo(insumosService)}
    </section>
  `;
}

export function attachEstoqueHandlers(
  estoqueService,
  insumosService,
  comprasService,
  fornecedoresService,
  rerender
) {
  const on = (id, evt, fn) => document.getElementById(id)?.addEventListener(evt, fn);

  on('est-busca','input',e => { filtroNome = e.target.value; rerender(); });
  on('est-filtro-tipo','change',e => { filtroTipo = e.target.value; rerender(); });
  on('est-filtro-sit','change',e => { filtroSituacao = e.target.value; rerender(); });

  on('est-limpar','click',() => {
    filtroNome = '';
    filtroTipo = '';
    filtroSituacao = '';
    rerender();
  });

  document.querySelectorAll('#est-tabela th.sortable').forEach(th => {
    th.addEventListener('click',() => {
      const col = th.dataset.col;
      if (ordemCol === col) ordemDir = ordemDir === 'asc' ? 'desc' : 'asc';
      else { ordemCol = col; ordemDir = 'asc'; }
      rerender();
    });
  });

  document.querySelectorAll('.est-tab').forEach(btn => {
    btn.addEventListener('click',() => {
      abaAtiva = btn.dataset.tab;
      rerender();
    });
  });

  on('est-insumo','change',() => atualizarBlocoEntradaManual(insumosService, estoqueService));
  on('quantidade','input',() => calcularEntradaManual(insumosService));
  on('custoUnitario','input',() => calcularEntradaManual(insumosService));

  on('est-form-entrada','submit',e => {
    e.preventDefault();

    const form = e.currentTarget;
    const insumo = insumosService.buscarPorId(form.insumo.value);
    if (!insumo) return alert('Selecione um insumo.');

    const qtdPorEmb = Number(insumo.qtdPorEmbalagem || 0);
    let quantidade = Number(form.quantidade.value || 0);
    let custo = Number(form.custoUnitario.value || 0);

    if (qtdPorEmb > 0) {
      quantidade *= qtdPorEmb;
      if (custo > 0) custo /= qtdPorEmb;
    }

    if (!custo || custo <= 0) {
      custo = estoqueService.buscarItemPorInsumoId(insumo.id)?.custoMedio || 0;
    }

    const r = estoqueService.registrarEntrada({
      insumoId: insumo.id,
      quantidade,
      custoUnitario: custo,
      origem: form.origem.value
    });

    if (!r.ok) return alert(r.erro);
    rerender();
  });

  on('est-recalibrar','click',() => {
    if (!confirm(
      'RECALIBRAR CUSTOS?\\n\\nRecalcula o custo m\u00e9dio diretamente das compras recebidas.'
    )) return;

    const r = estoqueService.recalibrarCustos(
      comprasService.list(),
      insumosService.listar()
    );

    alert(`Recalibra\u00e7\u00e3o conclu\u00edda. ${r.atualizados} item(ns) atualizado(s).`);
    rerender();
  });

  on('est-exportar','click',() => exportarEstoque(estoqueService, insumosService));

  on('btn-novo-insumo','click',() => {
    const modal = document.getElementById('modal-novo-insumo');
    if (modal) modal.style.display = 'flex';
  });

  on('btn-fechar-modal','click',() => document.getElementById('modal-novo-insumo').style.display = 'none');
  on('btn-cancelar-modal','click',() => document.getElementById('modal-novo-insumo').style.display = 'none');

  on('modal-novo-insumo','click',e => {
    if (e.target === e.currentTarget) e.currentTarget.style.display = 'none';
  });

  on('form-novo-insumo','submit',e => {
    e.preventDefault();
    const err = document.getElementById('modal-errors');
    const f = e.currentTarget;

    const payload = {
      nome: f.nome.value,
      marca: f.marca.value,
      tipo: f.tipo.value,
      unidade: f.unidade.value,
      qtdPorEmbalagem: Number(f.qtdPorEmbalagem.value || 0),
      nomeEmbalagem: f.nomeEmbalagem.value,
      minimoDesejado: Number(f.minimoDesejado.value || 0),
      observacoes: ''
    };

    const r = insumosService.adicionar(payload);
    if (!r.sucesso) {
      err.textContent = (r.erros || ['Erro ao salvar']).join(', ');
      return;
    }

    rerender();
  });

  on('btn-filtrar-mov','click',() => {
    movDataIni = document.getElementById('mov-data-ini')?.value || '';
    movDataFim = document.getElementById('mov-data-fim')?.value || '';
    movInsumo = document.getElementById('mov-insumo')?.value || '';
    movTipo = document.getElementById('mov-tipo')?.value || '';
    rerender();
  });

  on('btn-export-mov','click',() => exportarMovimentacoes(
    estoqueService,
    insumosService,
    { dataInicio: movDataIni, dataFim: movDataFim, insumoId: movInsumo, tipo: movTipo }
  ));

  on('btn-ver-hist','click',() => {
    histInsumo = document.getElementById('hist-insumo')?.value || '';
    rerender();
  });

  on('btn-filtrar-crel','click',() => {
    crelDataIni = document.getElementById('crel-data-ini')?.value || '';
    crelDataFim = document.getElementById('crel-data-fim')?.value || '';
    crelFornecedor = document.getElementById('crel-fornecedor')?.value || '';
    crelInsumo = document.getElementById('crel-insumo')?.value || '';
    rerender();
  });

  on('btn-export-crel','click',() => exportarCompras(
    comprasService,
    fornecedoresService,
    insumosService,
    { dataInicio: crelDataIni, dataFim: crelDataFim, fornecedorId: crelFornecedor, insumoId: crelInsumo }
  ));
}

function renderTabela(itens, insumos, insumosService) {
  let rows = itens.map(item => {
    const insumo = insumos.find(i => String(i.id) === String(item.insumoId));
    if (!insumo) return null;

    const sit = situacao(item, insumo);
    const hay = `${insumo.nome || ''} ${insumo.marca || ''}`.toLowerCase();

    if (filtroNome && !hay.includes(filtroNome.toLowerCase())) return null;
    if (filtroTipo && insumo.tipo !== filtroTipo) return null;
    if (filtroSituacao && sit.id !== filtroSituacao) return null;

    return { item, insumo, sit };
  }).filter(Boolean);

  const val = (r,col) => {
    if (col === 'nome') return String(r.insumo.nome || '').toLowerCase();
    if (col === 'tipo') return String(tipoNome(insumosService,r.insumo.tipo) || '').toLowerCase();
    if (col === 'quantidade') return Number(r.item.quantidade || 0);
    if (col === 'custo') return Number(r.item.custoMedio || 0);
    return '';
  };

  rows.sort((a,b) => {
    const av = val(a,ordemCol), bv = val(b,ordemCol);
    const cmp = typeof av === 'number' ? av - bv : String(av).localeCompare(String(bv),'pt-BR');
    return ordemDir === 'asc' ? cmp : -cmp;
  });

  const arrow = col => ordemCol === col ? (ordemDir === 'asc' ? ' \u2191' : ' \u2193') : ' \u2195';

  return `<div class="est-table-wrap">
    <table class="est-table" id="est-tabela">
      <thead><tr>
        <th class="sortable" data-col="nome">Insumo${arrow('nome')}</th>
        <th class="sortable" data-col="tipo">Tipo${arrow('tipo')}</th>
        <th class="sortable est-num" data-col="quantidade">Quantidade${arrow('quantidade')}</th>
        <th class="sortable est-num" data-col="custo">Custo M\u00e9dio${arrow('custo')}</th>
        <th class="est-num">Valor em Estoque</th>
        <th>\u00daltima Entrada</th>
        <th>Situa\u00e7\u00e3o</th>
        <th>A\u00e7\u00f5es</th>
      </tr></thead>
      <tbody>
        ${rows.length ? rows.map(({item,insumo,sit}) => `
          <tr>
            <td><strong>${esc(insumo.nome)}</strong>${insumo.marca ? `<div class="est-muted">${esc(insumo.marca)}</div>` : ''}</td>
            <td>${esc(tipoNome(insumosService,insumo.tipo))}</td>
            <td class="est-num">${num(item.quantidade)} ${esc(insumo.unidade || '')}</td>
            <td class="est-num">${money4(item.custoMedio)}</td>
            <td class="est-num">${money(Number(item.quantidade || 0)*Number(item.custoMedio || 0))}</td>
            <td>${fmtDate(item.ultimaEntrada)}</td>
            <td><span class="sit-badge ${sit.cls}">${sit.label}</span></td>
            <td><button type="button" class="btn btn-secondary est-hist-btn" data-id="${esc(item.insumoId)}" onclick="void(0)">Ver hist\u00f3rico</button></td>
          </tr>`).join('') : '<tr><td colspan="8" class="empty-state">Nenhum item encontrado</td></tr>'}
      </tbody>
    </table>
  </div>`;
}

function renderTab(estoqueService, insumosService, comprasService, fornecedoresService) {
  if (abaAtiva === 'historico') return renderHistorico(estoqueService, insumosService);
  if (abaAtiva === 'compras') return renderCompras( comprasService, fornecedoresService, insumosService );
  if (abaAtiva === 'reposicao') return renderReposicao(estoqueService, insumosService);
  return renderMovimentacoes(estoqueService, insumosService);
}

function renderMovimentacoes(estoqueService, insumosService) {
  const filtros = {
    dataInicio: movDataIni || undefined,
    dataFim: movDataFim || undefined,
    insumoId: movInsumo || undefined,
    tipo: movTipo || undefined
  };

  const movs = estoqueService.filtrarMovimentacoes(filtros).slice().reverse();

  return `
    <div class="est-report-filters">
      <input type="date" id="mov-data-ini" class="est-input" value="${esc(movDataIni)}">
      <input type="date" id="mov-data-fim" class="est-input" value="${esc(movDataFim)}">
      <select id="mov-insumo" class="est-input">
        <option value="">Todos os insumos</option>
        ${insumosService.listar().map(i => `<option value="${esc(i.id)}" ${sel(movInsumo,i.id)}>${esc(i.nome)}</option>`).join('')}
      </select>
      <select id="mov-tipo" class="est-input">
        <option value="">Entrada e Sa\u00edda</option>
        <option value="entrada" ${sel(movTipo,'entrada')}>Entrada</option>
        <option value="saida" ${sel(movTipo,'saida')}>Sa\u00edda</option>
      </select>
      <button type="button" id="btn-filtrar-mov" class="btn btn-primary">Filtrar</button>
      <button type="button" id="btn-export-mov" class="btn btn-secondary">Exportar CSV</button>
    </div>

    <div class="est-table-wrap">
      <table class="est-table">
        <thead><tr><th>Data</th><th>Insumo</th><th>Tipo</th><th class="est-num">Quantidade</th><th class="est-num">Custo Unit.</th><th class="est-num">Total</th><th>Origem</th></tr></thead>
        <tbody>
          ${movs.length ? movs.map(m => {
            const i = insumosService.buscarPorId(m.insumoId);
            return `<tr>
              <td>${fmtDate(m.data)}</td>
              <td>${esc(i?.nome || 'N/A')}</td>
              <td>${esc(String(m.tipo || '').toUpperCase())}</td>
              <td class="est-num">${num(m.quantidade)} ${esc(i?.unidade || '')}</td>
              <td class="est-num">${Number(m.custoUnitario || 0) > 0 ? money4(m.custoUnitario) : '\u2014'}</td>
              <td class="est-num">${Number(m.custoUnitario || 0) > 0 ? money(Number(m.quantidade || 0)*Number(m.custoUnitario || 0)) : '\u2014'}</td>
              <td>${esc(m.origem || '-')}</td>
            </tr>`;
          }).join('') : '<tr><td colspan="7" class="empty-state">Nenhuma movimenta\u00e7\u00e3o encontrada</td></tr>'}
        </tbody>
      </table>
    </div>`;
}

function renderHistorico(estoqueService, insumosService) {
  const insumo = histInsumo ? insumosService.buscarPorId(histInsumo) : null;
  const hist = histInsumo ? estoqueService.historicoCustoInsumo(histInsumo) : [];

  let stats = '';
  if (hist.length && insumo) {
    const custos = hist.map(h => Number(h.custoUnitario || 0)).filter(v => v > 0);
    const item = estoqueService.buscarItemPorInsumoId(histInsumo);
    stats = `<div class="est-mini-cards">
      ${miniCard(item ? `${num(item.quantidade)} ${esc(insumo.unidade)}` : '\u2014','Saldo atual')}
      ${miniCard(custos.length ? `${money4(Math.min(...custos))}/${esc(insumo.unidade)}` : '\u2014','Menor pre\u00e7o')}
      ${miniCard(custos.length ? `${money4(Math.max(...custos))}/${esc(insumo.unidade)}` : '\u2014','Maior pre\u00e7o')}
      ${miniCard(item ? `${money4(item.custoMedio)}/${esc(insumo.unidade)}` : '\u2014','Custo m\u00e9dio atual')}
    </div>`;
  }

  return `
    <div class="est-report-filters est-hist-filter">
      <select id="hist-insumo" class="est-input">
        <option value="">Selecione um insumo...</option>
        ${insumosService.listar().map(i => `<option value="${esc(i.id)}" ${sel(histInsumo,i.id)}>${esc(i.nome)}</option>`).join('')}
      </select>
      <button type="button" id="btn-ver-hist" class="btn btn-primary">Ver hist\u00f3rico</button>
    </div>
    ${stats}
    <div class="est-table-wrap">
      <table class="est-table">
        <thead><tr><th>Data</th><th class="est-num">Custo Unit.</th><th class="est-num">Quantidade</th><th>Origem</th></tr></thead>
        <tbody>
          ${hist.length ? hist.slice().reverse().map(h => `<tr>
            <td>${fmtDate(h.data)}</td><td class="est-num">${money4(h.custoUnitario)}</td><td class="est-num">${num(h.quantidade)} ${esc(insumo?.unidade || '')}</td><td>${esc(h.origem || '-')}</td>
          </tr>`).join('') : '<tr><td colspan="4" class="empty-state">Selecione um insumo para consultar o hist\u00f3rico de pre\u00e7os.</td></tr>'}
        </tbody>
      </table>
    </div>`;
}

function renderCompras(comprasService, fornecedoresService, insumosService) {
  let compras = comprasService.list().slice();

  if (crelDataIni) compras = compras.filter(c => String(c.data || '') >= crelDataIni);
  if (crelDataFim) compras = compras.filter(c => String(c.data || '') <= crelDataFim);
  if (crelFornecedor) compras = compras.filter(c => String(c.fornecedorId) === String(crelFornecedor));
  if (crelInsumo) compras = compras.filter(c => (c.itens || []).some(i => String(i.insumoId) === String(crelInsumo)));

  compras.sort((a,b) => String(b.data || '').localeCompare(String(a.data || '')));

  return `
    <div class="est-report-filters est-compras-filters">
      <input type="date" id="crel-data-ini" class="est-input" value="${esc(crelDataIni)}">
      <input type="date" id="crel-data-fim" class="est-input" value="${esc(crelDataFim)}">
      <select id="crel-fornecedor" class="est-input">
        <option value="">Todos os fornecedores</option>
        ${fornecedoresService.list().map(f => `<option value="${esc(f.id)}" ${sel(crelFornecedor,f.id)}>${esc(f.nome)}</option>`).join('')}
      </select>
      <select id="crel-insumo" class="est-input">
        <option value="">Todos os insumos</option>
        ${insumosService.listar().map(i => `<option value="${esc(i.id)}" ${sel(crelInsumo,i.id)}>${esc(i.nome)}</option>`).join('')}
      </select>
      <button type="button" id="btn-filtrar-crel" class="btn btn-primary">Filtrar</button>
      <button type="button" id="btn-export-crel" class="btn btn-secondary">Exportar CSV</button>
    </div>

    <div class="est-table-wrap">
      <table class="est-table">
        <thead><tr><th>Data</th><th>Fornecedor</th><th>Itens</th><th class="est-num">Total</th><th class="est-num">Desconto</th><th>Status</th></tr></thead>
        <tbody>
          ${compras.length ? compras.map(c => {
            const f = fornecedoresService.getById(c.fornecedorId);
            const itens = (c.itens || []).map(item => {
              const i = insumosService.buscarPorId(item.insumoId);
              return i ? `${i.nome} (${num(item.quantidade)}${i.unidade || ''})` : '';
            }).filter(Boolean).join(' | ');
            const desconto = (c.itens || []).reduce((t,i) => t + Number(i.descontoValor || 0),0);
            return `<tr><td>${fmtDate(c.data)}</td><td>${esc(f?.nome || '\u2014')}</td><td>${esc(itens)}</td><td class="est-num">${money(c.total ?? c.valor)}</td><td class="est-num">${desconto > 0 ? money(desconto) : '\u2014'}</td><td>${esc(c.status || '-')}</td></tr>`;
          }).join('') : '<tr><td colspan="6" class="empty-state">Nenhuma compra encontrada.</td></tr>'}
        </tbody>
      </table>
    </div>`;
}

function renderReposicao(estoqueService, insumosService) {
  const rows = estoqueService.listarItens().map(item => {
    const i = insumosService.buscarPorId(item.insumoId);
    if (!i) return null;
    const sit = situacao(item,i);
    if (sit.id === 'ok') return null;
    const minimo = Number(i.minimoDesejado || 0);
    const falta = minimo > 0 ? Math.max(0,minimo-Number(item.quantidade || 0)) : 0;
    return `<tr class="${sit.id === 'zerado' ? 'row-zerado' : 'row-baixo'}">
      <td><strong>${esc(i.nome)}</strong>${i.marca ? ` - ${esc(i.marca)}` : ''}</td>
      <td>${esc(tipoNome(insumosService,i.tipo))}</td>
      <td class="est-num">${num(item.quantidade)} ${esc(i.unidade)}</td>
      <td class="est-num">${minimo > 0 ? `${num(minimo)} ${esc(i.unidade)}` : '\u2014'}</td>
      <td class="est-num">${minimo > 0 ? `${num(falta)} ${esc(i.unidade)}` : '\u2014'}</td>
      <td><span class="sit-badge ${sit.cls}">${sit.label}</span></td>
    </tr>`;
  }).filter(Boolean);

  if (!rows.length) return '<p class="est-ok-msg">&#10003; Todos os itens est\u00e3o com estoque adequado.</p>';

  return `<p class="est-warn-msg">${rows.length} item(ns) precisam de reposi\u00e7\u00e3o:</p>
    <div class="est-table-wrap"><table class="est-table">
      <thead><tr><th>Insumo</th><th>Tipo</th><th class="est-num">Estoque Atual</th><th class="est-num">M\u00ednimo</th><th class="est-num">Falta</th><th>Situa\u00e7\u00e3o</th></tr></thead>
      <tbody>${rows.join('')}</tbody>
    </table></div>`;
}

function renderModalNovoInsumo(insumosService) {
  const tipos = insumosService.obterTipos();
  return `
    <div id="modal-novo-insumo" class="est-modal" style="display:none">
      <div class="est-modal-card">
        <div class="est-modal-head"><strong>Novo Insumo</strong><button type="button" id="btn-fechar-modal" class="est-x">x</button></div>
        <form id="form-novo-insumo">
          <div class="est-modal-grid">
            <label>Nome *<input name="nome" class="est-input" required></label>
            <label>Marca *<input name="marca" class="est-input" required></label>
            <label>Tipo *<select name="tipo" class="est-input" required><option value="">Selecione...</option>${tipos.map(t=>`<option value="${esc(t.id)}">${esc(t.nome)}</option>`).join('')}</select></label>
            <label>Unidade *<select name="unidade" class="est-input" required>
              <option value="">Selecione...</option><option value="g">g (gramas)</option><option value="kg">kg (quilogramas)</option><option value="ml">ml (mililitros)</option><option value="L">L (litros)</option><option value="un">un (unidades)</option>
            </select></label>
            <label>Qtd por embalagem<input name="qtdPorEmbalagem" type="number" min="0" step="0.01" class="est-input"></label>
            <label>Nome da embalagem<input name="nomeEmbalagem" class="est-input" placeholder="emb"></label>
            <label>M\u00ednimo desejado<input name="minimoDesejado" type="number" min="0" step="0.01" class="est-input"></label>
          </div>
          <div id="modal-errors" class="est-error"></div>
          <div class="est-modal-actions">
            <button type="button" id="btn-cancelar-modal" class="btn btn-secondary">Cancelar</button>
            <button type="submit" class="btn btn-primary">Adicionar</button>
          </div>
        </form>
      </div>
    </div>`;
}

function atualizarBlocoEntradaManual(insumosService, estoqueService) {
  const id = document.getElementById('est-insumo')?.value;
  const i = id ? insumosService.buscarPorId(id) : null;
  const qtd = document.getElementById('quantidade');
  const custo = document.getElementById('custoUnitario');
  const lblQtd = document.getElementById('lbl-qtd-manual');
  const lblCusto = document.getElementById('lbl-preco-manual');
  const help = document.getElementById('est-custo-help');

  if (!i || !qtd || !custo || !lblQtd || !lblCusto) return;

  const qtdEmb = Number(i.qtdPorEmbalagem || 0);
  if (qtdEmb > 0) {
    lblQtd.textContent = 'Qtd de embalagens *';
    lblCusto.innerHTML = 'Custo por embalagem (R$) <small>opcional</small>';
    qtd.step = '1'; qtd.min = '1'; qtd.placeholder = 'Ex: 2';
  } else {
    lblQtd.textContent = `Quantidade (${i.unidade || ''}) *`;
    lblCusto.innerHTML = 'Custo unit\u00e1rio (R$) <small>opcional</small>';
    qtd.step = '0.01'; qtd.min = '0.01'; qtd.placeholder = '0';
  }

  const item = estoqueService.buscarItemPorInsumoId(i.id);
  help.textContent = item?.custoMedio > 0
    ? `deixe vazio para manter custo atual (${money4(item.custoMedio)}/${i.unidade})`
    : 'custo atual ser\u00e1 usado se existir';
}

function calcularEntradaManual(insumosService) {
  const i = insumosService.buscarPorId(document.getElementById('est-insumo')?.value);
  const box = document.getElementById('fg-resumo-manual');
  const txt = document.getElementById('resumo-entrada-manual');
  if (!i || !box || !txt) return;

  const q = Number(document.getElementById('quantidade')?.value || 0);
  const c = Number(document.getElementById('custoUnitario')?.value || 0);
  const qtdEmb = Number(i.qtdPorEmbalagem || 0);

  if (qtdEmb > 0 && q > 0 && c > 0) {
    const base = q*qtdEmb;
    const custoBase = c/qtdEmb;
    txt.textContent = `${q} emb = ${num(base)} ${i.unidade} | ${money4(custoBase)}/${i.unidade} | Total: ${money(q*c)}`;
    box.style.display = 'block';
  } else box.style.display = 'none';
}

function exportarEstoque(estoqueService, insumosService) {
  const rows = estoqueService.listarItens().map(item => {
    const i = insumosService.buscarPorId(item.insumoId);
    if (!i) return null;
    return [i.nome,i.marca,tipoNome(insumosService,i.tipo),i.unidade,item.quantidade,item.custoMedio,Number(item.quantidade||0)*Number(item.custoMedio||0),situacao(item,i).label];
  }).filter(Boolean);

  downloadCSV('estoque.csv',['Insumo','Marca','Tipo','Unidade','Quantidade','Custo M\u00e9dio','Valor em Estoque','Situa\u00e7\u00e3o'],rows);
}

function exportarMovimentacoes(estoqueService, insumosService, filtros) {
  const rows = estoqueService.filtrarMovimentacoes({
    dataInicio:filtros.dataInicio||undefined,
    dataFim:filtros.dataFim||undefined,
    insumoId:filtros.insumoId||undefined,
    tipo:filtros.tipo||undefined
  }).slice().reverse().map(m => {
    const i=insumosService.buscarPorId(m.insumoId);
    return [fmtDate(m.data),i?.nome||'N/A',String(m.tipo||'').toUpperCase(),`${num(m.quantidade)} ${i?.unidade||''}`,m.custoUnitario,Number(m.quantidade||0)*Number(m.custoUnitario||0),m.origem||''];
  });

  downloadCSV('movimentacoes-estoque.csv',['Data','Insumo','Tipo','Quantidade','Custo Unit.','Total','Origem'],rows);
}

function exportarCompras(comprasService, fornecedoresService, insumosService, filtros) {
  let compras=comprasService.list().slice();
  if(filtros.dataInicio) compras=compras.filter(c=>String(c.data||'')>=filtros.dataInicio);
  if(filtros.dataFim) compras=compras.filter(c=>String(c.data||'')<=filtros.dataFim);
  if(filtros.fornecedorId) compras=compras.filter(c=>String(c.fornecedorId)===String(filtros.fornecedorId));
  if(filtros.insumoId) compras=compras.filter(c=>(c.itens||[]).some(i=>String(i.insumoId)===String(filtros.insumoId)));

  const rows=compras.map(c=>{
    const f=fornecedoresService.getById(c.fornecedorId);
    const itens=(c.itens||[]).map(item=>{const i=insumosService.buscarPorId(item.insumoId);return i?`${i.nome} (${num(item.quantidade)}${i.unidade||''})`:'';}).filter(Boolean).join(' | ');
    const desconto=(c.itens||[]).reduce((t,i)=>t+Number(i.descontoValor||0),0);
    return [fmtDate(c.data),f?.nome||'',itens,c.total??c.valor,desconto,c.status||''];
  });

  downloadCSV('relatorio-compras.csv',['Data','Fornecedor','Itens','Total','Desconto','Status'],rows);
}

function downloadCSV(filename,headers,rows) {
  const q=v=>`"${String(v??'').replace(/"/g,'""')}"`;
  const csv='\uFEFF'+[headers.map(q).join(';'),...rows.map(r=>r.map(q).join(';'))].join('\r\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
}

function situacao(item,insumo) {
  const q=Number(item.quantidade||0),m=Number(insumo.minimoDesejado||0);
  if(q<=0)return{id:'zerado',label:'Zerado',cls:'sit-zerado'};
  if(m>0&&q<m)return{id:'baixo',label:'Estoque baixo',cls:'sit-baixo'};
  return{id:'ok',label:'OK',cls:'sit-ok'};
}

function tipoOptions(service,current,label) {
  return `<option value="">${label}</option>${service.obterTipos().map(t=>`<option value="${esc(t.id)}" ${sel(current,t.id)}>${esc(t.nome)}</option>`).join('')}`;
}

function tipoNome(service,id) { return service.obterTipos().find(t=>t.id===id)?.nome||id||'-'; }
function tabButton(id,label){return `<button type="button" class="est-tab ${abaAtiva===id?'active':''}" data-tab="${id}">${label}</button>`;}
function card(value,label,extra=''){return `<div class="est-card ${extra}"><div class="est-card-val">${value}</div><div class="est-card-lbl">${label}</div></div>`;}
function miniCard(value,label){return `<div class="est-mini-card"><strong>${value}</strong><span>${label}</span></div>`;}
function sel(a,b){return String(a)===String(b)?'selected':'';}
function money(v){return Number(v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});}
function money4(v){return `R$ ${Number(v||0).toFixed(4).replace('.',',')}`;}
function num(v){return Number(v||0).toLocaleString('pt-BR',{maximumFractionDigits:3});}
function fmtDate(v){if(!v)return'-';const d=new Date(v);return Number.isNaN(d.getTime())?String(v):d.toLocaleDateString('pt-BR');}
function esc(v){return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}

function styles(){return `<style>
.est-wrap{max-width:1200px}.est-box{background:#fff;border-radius:8px;padding:1.25rem 1.5rem;margin-bottom:1.5rem;box-shadow:0 1px 4px rgba(0,0,0,.08)}
.est-box-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;gap:10px}.est-actions,.est-inline{display:flex;gap:6px;align-items:center}
.est-cards{display:flex;gap:1rem;margin-bottom:1.5rem;flex-wrap:wrap}.est-card{flex:1;min-width:140px;background:#fff;border-radius:8px;padding:1rem 1.25rem;box-shadow:0 1px 4px rgba(0,0,0,.08);border-left:4px solid #4a90d9}
.est-card-warn{border-left-color:#e67e22}.est-card-danger{border-left-color:#e74c3c}.est-card-val{font-size:1.4rem;font-weight:bold}.est-card-lbl{font-size:.78rem;color:#888;margin-top:2px}
.est-filtros,.est-form-row,.est-report-filters{display:flex;gap:8px;flex-wrap:wrap;align-items:end}.est-filtros .est-input{flex:1}.est-filtros #est-busca{flex:2}
.est-input{padding:6px 10px;border:1px solid #ddd;border-radius:4px;font-size:13px;background:#fff;width:100%;box-sizing:border-box}.est-fg{flex:1;min-width:150px}.est-fg-insumo{flex:1.2}.est-fg label{display:block;margin-bottom:4px;font-size:.82rem;font-weight:600}.est-fg small{font-size:.7rem;color:#8B7355}
.est-table-wrap{overflow-x:auto;margin-top:10px}.est-table{width:100%;border-collapse:collapse;font-size:.82rem}.est-table th,.est-table td{padding:8px;border-bottom:1px solid #eee;text-align:left}.est-table th{background:#f6f6f6;font-weight:600}.est-table th.sortable{cursor:pointer}.est-num{text-align:right!important}.est-muted{color:#999;font-size:.72rem;margin-top:2px}
.sit-badge{display:inline-block;padding:3px 7px;border-radius:10px;font-size:.72rem;font-weight:700}.sit-ok{color:#1e8449;background:#e9f7ef}.sit-baixo{color:#b9770e;background:#fef5e7}.sit-zerado{color:#c0392b;background:#fdedec}
.est-tabs{display:flex;border-bottom:1px solid #ddd;margin-bottom:12px;gap:8px}.est-tab{border:0;background:none;padding:8px 10px;cursor:pointer}.est-tab.active{color:#2874a6;border-bottom:2px solid #2874a6;font-weight:600}
.est-report-filters .est-input{flex:1;min-width:130px}.est-compras-filters .est-input{min-width:145px}.est-hist-filter #hist-insumo{max-width:420px}
.est-mini-cards{display:grid;grid-template-columns:repeat(4,minmax(120px,1fr));gap:8px;margin:10px 0}.est-mini-card{background:#fafafa;border:1px solid #eee;border-radius:6px;padding:10px}.est-mini-card strong,.est-mini-card span{display:block}.est-mini-card span{font-size:.72rem;color:#888;margin-top:3px}
.est-resumo-manual{margin-top:8px;padding:7px 10px;background:#f7fbf7;border:1px solid #dfeadf;border-radius:5px;font-size:.78rem;color:#287a42}
.est-ok-msg{color:#27ae60;padding:1rem;font-weight:bold}.est-warn-msg{color:#e67e22;font-weight:bold}.row-zerado{background:#fff8f8}.row-baixo{background:#fffdf6}
.est-modal{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center;padding:1rem}.est-modal-card{background:#fff;border-radius:10px;padding:1.25rem;max-width:650px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,.3)}.est-modal-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem}.est-x{background:none;border:0;font-size:1.2rem;cursor:pointer}.est-modal-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.est-modal-grid label{font-size:.8rem;font-weight:600}.est-modal-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:12px}.est-error{color:#c0392b;margin-top:8px;font-size:.8rem}.empty-state{text-align:center;color:#999;padding:20px}
@media(max-width:720px){.est-modal-grid{grid-template-columns:1fr}.est-mini-cards{grid-template-columns:1fr 1fr}}
</style>`;}