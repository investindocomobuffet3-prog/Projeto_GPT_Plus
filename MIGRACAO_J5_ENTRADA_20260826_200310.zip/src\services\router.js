export function createRouter({ pages, defaultPage }) {
  const state = { currentPage: getPageFromHash(defaultPage) };

  function getPageFromHash(defaultPage) {
    const hash = window.location.hash.replace(/^#/, '');
    return pages[hash] ? hash : defaultPage;
  }

  function setPage(page) {
    if (pages[page]) {
      if (window.location.hash.replace(/^#/, '') !== page) {
        window.location.hash = page;
      } else {
        state.currentPage = page;
        renderCurrentPage();
      }
    }
  }

  function renderCurrentPage() {
    const page = pages[state.currentPage] || pages[defaultPage];
    const container = document.getElementById('app');
    if (!container) return;

    const content = typeof page.render === 'function' ? page.render() : page;
    container.innerHTML = content;
    if (typeof page.attach === 'function') {
      page.attach();
    }
    attachPageHandlers(state.currentPage);
  }

  function attachPageHandlers(page) {
    const buttons = document.querySelectorAll('[data-tab]');
    buttons.forEach(button => {
      button.classList.toggle('active', button.dataset.tab === page);
    });
  }

  function render() {
    window.addEventListener('hashchange', () => {
      const page = getPageFromHash(defaultPage);
      if (page !== state.currentPage) {
        state.currentPage = page;
        renderCurrentPage();
      }
    });
    renderCurrentPage();
  }

  return { state, setPage, render };
}
