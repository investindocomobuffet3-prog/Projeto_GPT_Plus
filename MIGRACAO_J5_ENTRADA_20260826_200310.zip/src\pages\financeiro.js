function moeda(valor) {
  return Number(valor || 0).toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
}

function nomeFornecedor(fornecedoresService, fornecedorId) {
  const fornecedor =
    fornecedoresService?.getById?.(fornecedorId);

  return fornecedor?.nome || 'Fornecedor';
}

export function renderFinanceiro(
  service,
  comprasService,
  fornecedoresService,
  cartoesService
) {
  const lancamentos = service.listar();
  const compras = comprasService?.list?.() || [];
  const cartoes = cartoesService?.listar?.() || [];

  const comprasSemLancamento = compras.filter(compra => {
    const existentes =
      service.listarPorCompra(compra.id);

    return existentes.length === 0;
  });

  const parcelas = lancamentos.flatMap(lancamento =>
    (lancamento.parcelas || []).map(parcela => ({
      ...parcela,
      lancamento,
    }))
  );

  const pendente = parcelas
    .filter(item => item.status === 'pendente')
    .reduce((total, item) => total + Number(item.valor || 0), 0);

  const pago = parcelas
    .filter(item => item.status === 'pago')
    .reduce((total, item) => total + Number(item.valor || 0), 0);

  return `
    <section class="page-section">
      <div class="page-header">
        <div>
          <h2>Financeiro</h2>
          <p>Contas a pagar e recebimentos da operação.</p>
        </div>
      </div>

      <div class="stats-grid">
        <div class="card">
          <strong>Em aberto</strong>
          <div>${moeda(pendente)}</div>
        </div>

        <div class="card">
          <strong>Pago</strong>
          <div>${moeda(pago)}</div>
        </div>

        <div class="card">
          <strong>Lançamentos</strong>
          <div>${lancamentos.length}</div>
        </div>
      </div>

      ${
        comprasSemLancamento.length > 0
          ? `
            <div class="card">
              <h3>Compras aguardando lançamento financeiro</h3>

              <table class="table">
                <thead>
                  <tr>
                    <th>Fornecedor</th>
                    <th>Data</th>
                    <th>Valor</th>
                    <th>Ação</th>
                  </tr>
                </thead>
                <tbody>
                  ${comprasSemLancamento.map(compra => `
                    <tr>
                      <td>
                        ${nomeFornecedor(
                          fornecedoresService,
                          compra.fornecedorId
                        )}
                      </td>
                      <td>${compra.data || '-'}</td>
                      <td>
                        ${moeda(
                          compra.total !== undefined
                            ? compra.total
                            : compra.valor
                        )}
                      </td>
                      <td>
                        ${
                          cartoes.length > 0
                            ? `
                              <select
                                class="compra-cartao"
                                data-id="${compra.id}"
                              >
                                <option value="">
                                  Sem cartão
                                </option>
                                ${cartoes.map(cartao => `
                                  <option value="${cartao.id}">
                                    ${cartao.banco || 'Cartão'}${
                                      cartao.ultimos4
                                        ? ` ****${cartao.ultimos4}`
                                        : ''
                                    }
                                  </option>
                                `).join('')}
                              </select>

                              <select
                                class="compra-parcelas"
                                data-id="${compra.id}"
                              >
                                ${[1,2,3,4,5,6,7,8,9,10,11,12]
                                  .map(numero => `
                                    <option value="${numero}">
                                      ${numero}x
                                    </option>
                                  `).join('')}
                              </select>
                            `
                            : ''
                        }

                        <button
                          type="button"
                          class="btn btn-primary lancar-compra-financeiro"
                          data-id="${compra.id}"
                        >
                          Lançar no financeiro
                        </button>
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          `
          : ''
      }

      <div class="card">
        ${
          parcelas.length === 0
            ? '<p>Nenhum lançamento financeiro cadastrado.</p>'
            : `
              <table class="table">
                <thead>
                  <tr>
                    <th>Tipo</th>
                    <th>Origem</th>
                    <th>Parcela</th>
                    <th>Valor</th>
                    <th>Vencimento</th>
                    <th>Status</th>
                    <th>Ação</th>
                  </tr>
                </thead>
                <tbody>
                  ${parcelas.map(item => `
                    <tr>
                      <td>${item.lancamento.tipo || '-'}</td>
                      <td>${item.lancamento.origem || '-'}</td>
                      <td>${item.n}</td>
                      <td>${moeda(item.valor)}</td>
                      <td>${item.vencimento || '-'}</td>
                      <td>${item.status || 'pendente'}</td>
                      <td>
                        ${
                          item.status === 'pendente'
                            ? `
                              <button
                                type="button"
                                class="btn pagar-parcela"
                                data-id="${item.lancamento.id}"
                                data-parcela="${item.n}"
                              >
                                Marcar paga
                              </button>
                            `
                            : item.status === 'pago'
                              ? `
                                <button
                                  type="button"
                                  class="btn desfazer-baixa-parcela"
                                  data-id="${item.lancamento.id}"
                                  data-parcela="${item.n}"
                                >
                                  Desfazer baixa
                                </button>
                              `
                              : '-'
                        }

                        ${
                          Number(item.n) === 1
                            ? `
                              <button
                                type="button"
                                class="btn estornar-lancamento"
                                data-id="${item.lancamento.id}"
                              >
                                Estornar lançamento
                              </button>
                            `
                            : ''
                        }
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            `
        }
      </div>
    </section>
  `;
}

export function attachFinanceiroHandlers(
  service,
  comprasService,
  rerender,
  cartoesService
) {
  document
    .querySelectorAll('.lancar-compra-financeiro')
    .forEach(button => {
      button.addEventListener('click', () => {
        const compra =
          comprasService.getById(button.dataset.id);

        if (!compra) {
          alert('Compra não encontrada.');
          return;
        }

        const valor =
          compra.total !== undefined
            ? compra.total
            : compra.valor;

        const confirmar = confirm(
          `Criar lançamento financeiro de ${moeda(valor)} ` +
          `para esta compra?`
        );

        if (!confirmar) {
          return;
        }

        const seletorCartao = document.querySelector(
          `.compra-cartao[data-id="${compra.id}"]`
        );

        const seletorParcelas = document.querySelector(
          `.compra-parcelas[data-id="${compra.id}"]`
        );

        const cartaoId =
          seletorCartao?.value || null;

        const parcelas =
          Math.max(
            1,
            Number(seletorParcelas?.value || 1)
          );

        const resultado = service.lancarCompra(
          compra,
          comprasService,
          {
            parcelas,
            primeiroVencimento:
              compra.data || new Date().toISOString().slice(0, 10),
            meioPagamento:
              cartaoId ? 'cartao_credito' : '',
            cartaoId,
            cartoesService,
          }
        );

        if (!resultado.sucesso) {
          alert(resultado.erro || 'Falha ao criar lançamento.');
          return;
        }

        rerender();
      });
    });

  document.querySelectorAll('.pagar-parcela').forEach(button => {
    button.addEventListener('click', () => {
      const resultado = service.marcarParcelaComoPaga(
        button.dataset.id,
        Number(button.dataset.parcela)
      );

      if (!resultado.sucesso) {
        alert(resultado.erro);
        return;
      }

      rerender();
    });
  });

  document
    .querySelectorAll('.desfazer-baixa-parcela')
    .forEach(button => {
      button.addEventListener('click', () => {
        const confirmado = confirm(
          'Desfazer a baixa desta parcela? Ela voltará para pendente.'
        );

        if (!confirmado) {
          return;
        }

        const resultado = service.desfazerBaixaParcela(
          button.dataset.id,
          Number(button.dataset.parcela)
        );

        if (!resultado.sucesso) {
          alert(resultado.erro);
          return;
        }

        rerender();
      });
    });

  document
    .querySelectorAll('.estornar-lancamento')
    .forEach(button => {
      button.addEventListener('click', () => {
        const confirmado = confirm(
          'Estornar este lançamento inteiro? ' +
          'A compra voltará a aguardar lançamento financeiro.'
        );

        if (!confirmado) {
          return;
        }

        const resultado = service.estornarLancamento(
          button.dataset.id,
          comprasService,
          cartoesService
        );

        if (!resultado.sucesso) {
          alert(resultado.erro);
          return;
        }

        rerender();
      });
    });
}