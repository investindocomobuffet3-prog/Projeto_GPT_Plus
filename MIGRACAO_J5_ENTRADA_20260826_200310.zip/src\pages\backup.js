export function renderBackup(data) {
  const counts = [
    { label: 'Insumos', value: data.insumos?.length || 0 },
    { label: 'Fornecedores', value: data.fornecedores?.length || 0 },
    { label: 'Compras', value: data.compras?.length || 0 },
    { label: 'Fichas', value: data.fichas?.length || 0 },
  ];

  return `
    <section class="page-header">
      <div>
        <h2>Backup</h2>
        <p class="page-description">Verifique os dados presentes no backup local.</p>
      </div>
    </section>
    <section class="cards-grid">
      ${counts.map(stat => `
        <article class="card card-stat">
          <span class="card-label">${stat.label}</span>
          <strong class="card-value">${stat.value}</strong>
        </article>
      `).join('')}
    </section>
    <section class="page-content">
      <div class="backup-panel">
        <p class="info-text">A aplicação carrega o backup público de <code>data/backup.json</code>.</p>
        <div class="backup-actions">
          <button id="backup-restore" type="button" class="btn btn-primary">Restaurar backup</button>
          <button id="backup-export" type="button" class="btn btn-secondary">Exportar backup</button>
        </div>
        <div class="empty-state">
          <p>Esta página está pronta para receber ações de backup e importação de dados.</p>
        </div>
      </div>
    </section>
  `;
}
