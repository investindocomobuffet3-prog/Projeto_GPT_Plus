let editandoId = null;

export function renderFornecedores(
  service
) {
  const fornecedores =
    service.list()
      .slice()
      .sort((a, b) =>
        String(a.nome || '').localeCompare(
          String(b.nome || ''),
          'pt-BR'
        )
      );

  const editItem =
    editandoId
      ? service.getById(editandoId)
      : null;

  return `
    <section class="page-header">
      <div>
        <h2>Fornecedores</h2>
        <p class="page-description">
          Cadastro de fornecedores do modelo mestre.
        </p>
      </div>
    </section>

    <section class="page-content">

      <div class="info-box">
        <p>
          Total de fornecedores:
          <strong>${fornecedores.length}</strong>
        </p>
      </div>

      ${renderFormulario(editItem)}

      ${renderTabela(fornecedores)}

    </section>
  `;
}

function renderFormulario(item) {
  return `
    <section class="card card-form">

      <h3>
        ${item ? 'Editar fornecedor' : 'Novo fornecedor'}
      </h3>

      <form id="form-fornecedor">

        <input
          type="hidden"
          name="id"
          value="${escapeHtml(item?.id || '')}"
        />

        <div class="form-row">

          <div class="form-group">
            <label>Nome *</label>

            <input
              type="text"
              name="nome"
              class="form-control"
              required
              value="${escapeHtml(item?.nome || '')}"
            />
          </div>

          <div class="form-group">
            <label>CNPJ / CPF *</label>

            <input
              type="text"
              name="cnpj"
              class="form-control"
              required
              placeholder="00.000.000/0000-00 ou 000.000.000-00"
              value="${escapeHtml(item?.cnpj || '')}"
            />
          </div>

        </div>

        <div class="form-row">

          <div class="form-group">
            <label>Contato</label>

            <input
              type="text"
              name="contato"
              class="form-control"
              placeholder="Nome do contato"
              value="${escapeHtml(item?.contato || '')}"
            />
          </div>

          <div class="form-group">
            <label>Telefone</label>

            <input
              type="tel"
              name="telefone"
              class="form-control"
              placeholder="(00) 00000-0000"
              value="${escapeHtml(item?.telefone || '')}"
            />
          </div>

          <div class="form-group">
            <label>Email</label>

            <input
              type="email"
              name="email"
              class="form-control"
              placeholder="email@exemplo.com"
              value="${escapeHtml(item?.email || '')}"
            />
          </div>

        </div>

        <div class="form-row">

          <div class="form-group full-width">
            <label>Endereço</label>

            <textarea
              name="endereco"
              class="form-control"
              rows="2"
            >${escapeHtml(item?.endereco || '')}</textarea>
          </div>

        </div>

        <div class="form-row">

          <div class="form-group full-width">
            <label>Observações</label>

            <textarea
              name="observacoes"
              class="form-control"
              rows="2"
            >${escapeHtml(item?.observacoes || '')}</textarea>
          </div>

        </div>

        <div class="form-actions">

          <button
            type="submit"
            class="btn btn-primary"
          >
            ${item ? 'Salvar' : 'Adicionar'}
          </button>

          ${
            item
              ? `
                <button
                  id="fornecedor-cancel"
                  type="button"
                  class="btn btn-secondary"
                >
                  Cancelar
                </button>
              `
              : ''
          }

        </div>

      </form>

    </section>
  `;
}

function renderTabela(fornecedores) {
  return `
    <section class="card">

      <h3>Fornecedores Cadastrados</h3>

      <div class="table-container">

        <table class="table">

          <thead>
            <tr>
              <th>Nome</th>
              <th>CNPJ/CPF</th>
              <th>Contato</th>
              <th>Telefone</th>
              <th>Email</th>
              <th>Ações</th>
            </tr>
          </thead>

          <tbody>

            ${
              fornecedores.length
                ? fornecedores.map(item => `
                    <tr>

                      <td>
                        <strong>
                          ${escapeHtml(item.nome)}
                        </strong>
                      </td>

                      <td>
                        ${formatDocumento(item.cnpj)}
                      </td>

                      <td>
                        ${escapeHtml(item.contato || '—')}
                      </td>

                      <td>
                        ${escapeHtml(item.telefone || '—')}
                      </td>

                      <td>
                        ${escapeHtml(item.email || '—')}
                      </td>

                      <td class="table-actions">

                        <button
                          type="button"
                          class="btn btn-secondary edit-fornecedor"
                          data-id="${escapeHtml(item.id)}"
                        >
                          Editar
                        </button>

                        <button
                          type="button"
                          class="btn btn-danger delete-fornecedor"
                          data-id="${escapeHtml(item.id)}"
                        >
                          Excluir
                        </button>

                      </td>

                    </tr>
                  `).join('')
                : `
                    <tr>
                      <td
                        colspan="6"
                        class="empty-state"
                      >
                        Nenhum fornecedor cadastrado
                      </td>
                    </tr>
                  `
            }

          </tbody>

        </table>

      </div>

    </section>
  `;
}

export function attachFornecedoresMasterHandlers(
  service,
  rerender
) {
  const form =
    document.getElementById(
      'form-fornecedor'
    );

  if (form) {
    form.addEventListener(
      'submit',
      event => {
        event.preventDefault();

        const fd =
          new FormData(form);

        const payload = {
          nome: fd.get('nome'),
          cnpj: fd.get('cnpj'),
          contato: fd.get('contato'),
          telefone: fd.get('telefone'),
          email: fd.get('email'),
          endereco: fd.get('endereco'),
          observacoes:
            fd.get('observacoes'),
        };

        const id =
          fd.get('id');

        const resultado =
          id
            ? service.update(id, payload)
            : service.create(payload);

        if (!resultado.sucesso) {
          alert(
            (
              resultado.erros ||
              ['Erro ao salvar fornecedor']
            ).join('\n')
          );

          return;
        }

        editandoId = null;
        rerender();
      }
    );
  }

  document
    .querySelectorAll(
      '.edit-fornecedor'
    )
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          editandoId =
            button.dataset.id;

          rerender();
        }
      );
    });

  document
    .querySelectorAll(
      '.delete-fornecedor'
    )
    .forEach(button => {
      button.addEventListener(
        'click',
        () => {
          if (
            !confirm(
              'Excluir este fornecedor?'
            )
          ) {
            return;
          }

          const resultado =
            service.remove(
              button.dataset.id
            );

          if (!resultado.sucesso) {
            alert(
              (
                resultado.erros ||
                ['Erro ao excluir fornecedor']
              ).join('\n')
            );

            return;
          }

          editandoId = null;
          rerender();
        }
      );
    });

  const cancelar =
    document.getElementById(
      'fornecedor-cancel'
    );

  if (cancelar) {
    cancelar.addEventListener(
      'click',
      () => {
        editandoId = null;
        rerender();
      }
    );
  }
}

function formatDocumento(value) {
  const digitos =
    String(value || '')
      .replace(/\D/g, '');

  if (digitos.length === 11) {
    return digitos.replace(
      /(\d{3})(\d{3})(\d{3})(\d{2})/,
      '$1.$2.$3-$4'
    );
  }

  if (digitos.length === 14) {
    return digitos.replace(
      /(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/,
      '$1.$2.$3/$4-$5'
    );
  }

  return escapeHtml(value || '—');
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}