import { fichasService } from '../services/fichasService.js';

const TIPOS_KEY = 'fichas_tipos_todos';
const TIPOS_PADRAO = [
  { value: 'massa', label: 'Massa' },
  { value: 'recheio', label: 'Recheio' },
  { value: 'reducao', label: 'Redução' },
  { value: 'doce', label: 'Doce' },
  { value: 'sobremesa', label: 'Sobremesa' },
  { value: 'cobertura', label: 'Cobertura' },
];

const state = { fichaEditandoId: null, ingredientesTemporarios: [], ingredienteEditandoIndex: null };

const esc = value => String(value ?? '')
  .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
  .replaceAll('"','&quot;').replaceAll("'",'&#039;');

const money = value => Number(value || 0).toLocaleString('pt-BR', {
  style: 'currency',
  currency: 'BRL',
});

function getTipos() {
  try {
    const raw = localStorage.getItem(TIPOS_KEY);
    if (!raw) {
      localStorage.setItem(TIPOS_KEY, JSON.stringify(TIPOS_PADRAO));
      return [...TIPOS_PADRAO];
    }

    let tipos = JSON.parse(raw);
    if (!Array.isArray(tipos)) tipos = [];
    tipos = tipos.filter(tipo => tipo?.value !== 'outro');

    let mudou = false;
    for (const padrao of TIPOS_PADRAO) {
      if (!tipos.some(tipo => tipo.value === padrao.value)) {
        const cobertura = tipos.findIndex(tipo => tipo.value === 'cobertura');
        cobertura >= 0 ? tipos.splice(cobertura, 0, padrao) : tipos.push(padrao);
        mudou = true;
      }
    }

    if (mudou) localStorage.setItem(TIPOS_KEY, JSON.stringify(tipos));
    return tipos;
  } catch {
    localStorage.setItem(TIPOS_KEY, JSON.stringify(TIPOS_PADRAO));
    return [...TIPOS_PADRAO];
  }
}

function saveTipos(tipos) {
  localStorage.setItem(TIPOS_KEY, JSON.stringify(tipos));
}

function labelTipo(value) {
  return getTipos().find(tipo => tipo.value === value)?.label || value || 'Outro';
}

function slugTipo(nome) {
  return nome.toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '') || `tipo_${Date.now()}`;
}

function custoInsumo(insumoId, estoqueService) {
  return Number(estoqueService?.buscarItemPorInsumoId?.(insumoId)?.custoMedio || 0);
}

function nomeInsumo(insumoId, insumos) {
  const i = insumos.find(item => String(item.id) === String(insumoId));
  return i ? `${i.nome}${i.marca ? ` - ${i.marca}` : ''}` : 'N/A';
}

function pesoBruto(insumos) {
  const catalogo = insumos || [];
  const total = state.ingredientesTemporarios.reduce((soma, ing) => {
    const cadastro = catalogo.find(item => String(item.id) === String(ing.insumoId));
    const quantidade = Number(ing.quantidade || 0);
    return cadastro && ['kg','L'].includes(cadastro.unidade)
      ? soma + quantidade * 1000
      : soma + quantidade;
  }, 0);
  return Math.round(total * 10) / 10;
}

function renderIngredientes(insumos) {
  if (!state.ingredientesTemporarios.length) {
    return '<div id="ficha-ingredientes-wrap"><p class="empty-state">Nenhum ingrediente adicionado.</p></div>';
  }

  return `<div id="ficha-ingredientes-wrap"><table class="data-table">
    <thead><tr><th>Ingrediente</th><th>Quantidade</th><th>Custo unit.</th><th>Subtotal</th><th>Ações</th></tr></thead>
    <tbody>${state.ingredientesTemporarios.map((ing,index)=>{
      const cadastro = insumos.find(item => String(item.id) === String(ing.insumoId));
      const unidade = cadastro?.unidade || '';
      const quantidade = Number(ing.quantidade || 0);
      const subtotal = quantidade * Number(ing.custoUnitario || 0);

      if (state.ingredienteEditandoIndex === index) {
        return `<tr style="background:#fffbf0;">
          <td>${esc(nomeInsumo(ing.insumoId,insumos))}</td>
          <td>
            <div style="display:flex;align-items:center;gap:6px;">
              <input type="number"
                class="ficha-edit-qtd"
                data-index="${index}"
                value="${quantidade}"
                min="0.001"
                step="${['kg','L'].includes(unidade) ? '0.001' : '0.01'}"
                style="width:100px;">
              <span>${esc(unidade)}</span>
            </div>
          </td>
          <td>${money(ing.custoUnitario)}</td>
          <td>${money(subtotal)}</td>
          <td>
            <button type="button" class="btn ficha-confirmar-ingrediente" data-index="${index}">✓ Confirmar</button>
            <button type="button" class="btn secondary ficha-cancelar-edicao-ingrediente">Cancelar</button>
          </td>
        </tr>`;
      }

      return `<tr>
        <td>${esc(nomeInsumo(ing.insumoId,insumos))}</td>
        <td>${quantidade} ${esc(unidade)}</td>
        <td>${money(ing.custoUnitario)}</td>
        <td>${money(subtotal)}</td>
        <td>
          <button type="button" class="btn secondary ficha-editar-ingrediente" data-index="${index}">Editar</button>
          <button type="button" class="btn secondary ficha-remove-ingrediente" data-index="${index}">Remover</button>
        </td>
      </tr>`;
    }).join('')}</tbody>
  </table></div>`;
}

function renderLista(fichas) {
  if (!fichas.length) return '<div class="empty-state"><p>Nenhuma ficha técnica cadastrada.</p></div>';

  return `<div class="table-wrap"><table class="data-table">
    <thead><tr><th>Nome</th><th>Tipo</th><th>Rendimento</th><th>Ingredientes</th><th>Custo total</th><th>Custo unitário</th><th>Ações</th></tr></thead>
    <tbody>${fichas.map(f=>`
      <tr>
        <td><strong>${esc(f.nome)}</strong>${f.panelaReferencia ? `<br><small>Panela ${esc(f.panelaReferencia)}</small>` : ''}</td>
        <td>${esc(labelTipo(f.tipo))}</td>
        <td>${Number(f.rendimento || 0)} ${esc(f.unidadeMedida || '')}</td>
        <td>${f.ingredientes?.length || 0}</td>
        <td>${money(f.custoTotal)}</td>
        <td>${money(f.custoUnitario)}</td>
        <td>
          <button type="button" class="btn secondary ficha-editar" data-id="${esc(f.id)}">Editar</button>
          <button type="button" class="btn ficha-excluir" data-id="${esc(f.id)}">Excluir</button>
        </td>
      </tr>`).join('')}</tbody>
  </table></div>`;
}

function renderBase(fichas, editando, tipoAtual) {
  const mostrar = ['doce','sobremesa'].includes(tipoAtual);
  const bases = fichas
    .filter(f => ['massa','recheio','reducao'].includes(f.tipo))
    .filter(f => String(f.id) !== String(editando?.id || ''))
    .sort((a,b) => a.nome.localeCompare(b.nome,'pt-BR'));

  return `<div id="bloco-base-ficha" style="display:${mostrar ? 'block' : 'none'};margin-bottom:1rem;padding:1rem;background:#f0f7ff;border-radius:8px;border:1px solid #c8dff7;">
    <div style="font-size:0.8rem;font-weight:700;color:#2c6fad;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:0.75rem;">🍬 Base (semipronto da Fase 1)</div>
    <div style="display:flex;gap:1rem;flex-wrap:wrap;">
      <label style="flex:2;min-width:200px;">Massa / Recheio / Redução *
        <select name="baseId">
          <option value="">Selecione a base...</option>
          ${bases.map(f=>`<option value="${esc(f.id)}" ${String(editando?.baseId||'')===String(f.id)?'selected':''}>${esc(f.nome)}</option>`).join('')}
        </select>
      </label>
      <label style="flex:1;min-width:120px;">Qtd por doce (g) *
        <input name="baseQuantidadeG" type="number" min="0.1" step="0.1" placeholder="ex: 15" value="${esc(editando?.baseQuantidadeG ?? '')}">
      </label>
    </div>
    <small style="color:#6b8cae;margin-top:6px;display:block;">A Fase 2 usará esses valores para calcular o custo da base automaticamente.</small>
  </div>`;
}

export function renderFichas(insumosService, estoqueService) {
  const fichas = fichasService.listar();
  const insumos = insumosService.listar();
  const editando = state.fichaEditandoId ? fichasService.buscarPorId(state.fichaEditandoId) : null;

  if (editando && state.ingredientesTemporarios.length === 0) {
    state.ingredientesTemporarios = editando.ingredientes.map(ing => ({
      ...ing,
      custoUnitario: custoInsumo(ing.insumoId, estoqueService) || ing.custoUnitario,
    }));
  }

  const custoTotal = fichasService.calcularCustoTotal(state.ingredientesTemporarios);
  const bruto = pesoBruto(insumos);
  const tipoAtual = editando?.tipo || 'massa';
  const tipos = getTipos();

  return `
    <section class="page-header"><div>
      <h2>Fichas Técnicas</h2>
      <p class="page-description">Receitas, rendimento, ingredientes e custo calculado pelo estoque.</p>
    </div></section>

    <section class="page-content">
      <div class="info-box"><p>Total de fichas técnicas: <strong>${fichas.length}</strong></p></div>

      <div class="form-container">
        <h3>${editando ? 'Editar' : 'Nova'} Ficha Técnica</h3>
        <form id="ficha-form">
          <label>Nome *<input name="nome" required value="${esc(editando?.nome || '')}"></label>

          <div class="form-grid">
            <label>Tipo *
              <span style="display:flex;gap:6px;align-items:center;">
                <select name="tipo" id="ficha-tipo" style="flex:1;">
                  ${tipos.map(tipo=>`<option value="${esc(tipo.value)}" ${tipoAtual===tipo.value?'selected':''}>${esc(tipo.label)}</option>`).join('')}
                </select>
                <button type="button" id="ficha-gerenciar-tipos" class="btn secondary" style="white-space:nowrap;">+ Tipo</button>
              </span>
            </label>

            <label>Peso bruto (g) <small style="font-weight:normal;color:#666">soma dos ingredientes</small>
              <input id="ficha-rendimento" type="number" readonly value="${bruto || ''}" placeholder="Soma dos ingredientes" style="background:#f5f5f5;cursor:not-allowed;">
            </label>

            <label>Panela de Referência <small style="font-weight:normal;color:#666">opcional</small>
              <select name="panelaReferencia">
                <option value="">Não definida</option>
                ${[
                  ['PP','PP — Extra Pequena'],
                  ['P','P — Pequena'],
                  ['M','M — Média'],
                  ['G','G — Grande'],
                ].map(([v,l])=>`<option value="${v}" ${String(editando?.panelaReferencia||'')===v?'selected':''}>${l}</option>`).join('')}
              </select>
            </label>
          </div>

          ${renderBase(fichas, editando, tipoAtual)}

          <hr>
          <h4>Ingredientes</h4>
          <div class="form-grid">
            <label>Insumo
              <span style="display:flex;gap:6px;align-items:center;">
                <select id="ficha-insumo" style="flex:1;">
                  <option value="">Selecione...</option>
                  ${insumos.map(i=>`<option value="${esc(i.id)}" data-unidade="${esc(i.unidade || '')}">${esc(i.nome)}${i.marca?` - ${esc(i.marca)}`:''} (${esc(i.unidade || '')})</option>`).join('')}
                </select>
                <button type="button" id="ficha-novo-insumo" class="btn secondary" style="white-space:nowrap;">+ Novo</button>
              </span>
            </label>

            <label id="lbl-ficha-ing-qtd">
              Quantidade
              <input id="ficha-ing-qtd" type="number" min="0" step="0.001" placeholder="0">
            </label>

            <div>
              <button type="button" id="ficha-add-ingrediente" class="btn secondary">Adicionar</button>
            </div>
          </div>

          ${renderIngredientes(insumos)}

          <div class="info-box"><p>Custo Total: <strong id="ficha-custo-total">${money(custoTotal)}</strong></p></div>

          <div style="margin:-0.5rem 0 1.5rem 0;padding:1rem 1.25rem;background:#f8f4ee;border-radius:8px;border:1px dashed #c9b99a;">
            <div style="font-size:0.78rem;font-weight:600;color:#8B7355;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:0.6rem;">🧮 Calculadora rápida — não salva</div>
            <div style="display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap;">
              <label style="margin:0;">Ficha técnica:
                <select id="ficha-calc-ficha" style="min-width:220px;">
                  <option value="">Selecione uma ficha...</option>
                  ${fichas.map(f=>`<option value="${esc(f.id)}">${esc(f.nome)}${f.panelaReferencia?` — Panela ${esc(f.panelaReferencia)}`:''}</option>`).join('')}
                </select>
              </label>

              <label style="margin:0;">Peso por doce (g):
                <input type="number" id="ficha-calc-peso" min="0.1" step="0.1" placeholder="ex: 15" style="width:110px;">
              </label>

              <strong id="ficha-calc-resultado"></strong>
            </div>
          </div>

          <label>Modo de Preparo<textarea name="modoPreparo">${esc(editando?.modoPreparo || '')}</textarea></label>
          <label>Observações<textarea name="observacoes">${esc(editando?.observacoes || '')}</textarea></label>

          <div class="form-actions">
            <button type="submit" class="btn">${editando ? 'Salvar alterações' : 'Salvar'}</button>
            ${editando ? '<button type="button" id="ficha-cancelar" class="btn secondary">Cancelar</button>' : ''}
          </div>
        </form>
      </div>

      <div class="lista-container"><h3>Fichas cadastradas</h3>${renderLista(fichas)}</div>
    </section>`;
}

function abrirGerenciadorTipos(rerender) {
  document.getElementById('fichas-modal-tipos')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'fichas-modal-tipos';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;display:flex;align-items:center;justify-content:center;padding:1rem;';

  const renderModal = (editandoValue = null) => {
    const tipos = getTipos();
    overlay.innerHTML = `<div style="background:white;border-radius:12px;padding:1.5rem 2rem;max-width:420px;width:100%;max-height:80vh;overflow:auto;box-shadow:0 20px 60px rgba(0,0,0,.3);">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;">
        <h4 style="margin:0;">Gerenciar Tipos</h4>
        <button type="button" id="fichas-tipos-fechar" class="btn secondary">×</button>
      </div>
      <div>${tipos.map(tipo => editandoValue === tipo.value
        ? `<div style="display:flex;gap:6px;align-items:center;padding:8px 0;border-bottom:1px solid #ddd;">
            <input id="fichas-tipo-edit-input" value="${esc(tipo.label)}" style="flex:1;">
            <button type="button" class="btn ficha-tipo-salvar" data-value="${esc(tipo.value)}">✓</button>
            <button type="button" class="btn secondary ficha-tipo-cancelar">✕</button>
          </div>`
        : `<div style="display:flex;gap:6px;align-items:center;padding:8px 0;border-bottom:1px solid #ddd;">
            <span style="flex:1;">${esc(tipo.label)}</span>
            <button type="button" class="btn secondary ficha-tipo-editar" data-value="${esc(tipo.value)}">Editar</button>
            <button type="button" class="btn ficha-tipo-excluir" data-value="${esc(tipo.value)}">Excluir</button>
          </div>`).join('')}</div>
      <div style="border-top:1px solid #ddd;padding-top:1rem;margin-top:1rem;">
        <label>Adicionar novo tipo</label>
        <div style="display:flex;gap:6px;">
          <input id="fichas-novo-tipo-nome" placeholder="ex: Ganache, Glacê, Calda..." style="flex:1;">
          <button type="button" id="fichas-tipo-adicionar" class="btn">+ Adicionar</button>
        </div>
      </div>
    </div>`;

    overlay.querySelector('#fichas-tipos-fechar')?.addEventListener('click', () => overlay.remove());

    overlay.querySelectorAll('.ficha-tipo-editar').forEach(btn => {
      btn.addEventListener('click', () => renderModal(btn.dataset.value));
    });

    overlay.querySelectorAll('.ficha-tipo-cancelar').forEach(btn => {
      btn.addEventListener('click', () => renderModal());
    });

    overlay.querySelectorAll('.ficha-tipo-salvar').forEach(btn => {
      btn.addEventListener('click', () => {
        const nome = overlay.querySelector('#fichas-tipo-edit-input')?.value.trim();
        if (!nome) return alert('Nome não pode ser vazio');
        const tiposAtuais = getTipos();
        const index = tiposAtuais.findIndex(tipo => tipo.value === btn.dataset.value);
        if (index < 0) return alert('Tipo não encontrado');
        tiposAtuais[index].label = nome;
        saveTipos(tiposAtuais);
        renderModal();
      });
    });

    overlay.querySelectorAll('.ficha-tipo-excluir').forEach(btn => {
      btn.addEventListener('click', () => {
        const tipo = getTipos().find(item => item.value === btn.dataset.value);
        if (!tipo) return;
        if (!confirm(`Excluir o tipo "${tipo.label}"?\nFichas que usam este tipo não serão afetadas.`)) return;
        saveTipos(getTipos().filter(item => item.value !== btn.dataset.value));
        renderModal();
      });
    });

    overlay.querySelector('#fichas-tipo-adicionar')?.addEventListener('click', () => {
      const input = overlay.querySelector('#fichas-novo-tipo-nome');
      const nome = input?.value.trim();
      if (!nome) return alert('Informe o nome do tipo');

      const tiposAtuais = getTipos();
      if (tiposAtuais.some(tipo => tipo.label.toLowerCase() === nome.toLowerCase())) {
        return alert('Tipo já existe');
      }

      let value = slugTipo(nome);
      if (tiposAtuais.some(tipo => tipo.value === value)) value = `${value}_${Date.now()}`;
      tiposAtuais.push({ value, label: nome });
      saveTipos(tiposAtuais);
      renderModal();
    });

    overlay.querySelector('#fichas-novo-tipo-nome')?.addEventListener('keydown', event => {
      if (event.key === 'Enter') {
        event.preventDefault();
        overlay.querySelector('#fichas-tipo-adicionar')?.click();
      }
    });
  };

  renderModal();
  document.body.appendChild(overlay);
  overlay.addEventListener('click', event => {
    if (event.target === overlay) overlay.remove();
  });

  const observer = new MutationObserver(() => {
    if (!document.body.contains(overlay)) {
      observer.disconnect();
      rerender();
    }
  });
  observer.observe(document.body, { childList: true });
}

function atualizarCalculadora() {
  const fichaId = document.getElementById('ficha-calc-ficha')?.value || '';
  const peso = Number(document.getElementById('ficha-calc-peso')?.value || 0);
  const resultado = document.getElementById('ficha-calc-resultado');
  if (!resultado) return;

  if (!fichaId) {
    resultado.textContent = peso > 0 ? 'Selecione uma ficha técnica' : '';
    return;
  }

  const ficha =
    fichasService.buscarPorId?.(fichaId) ||
    fichasService.getById?.(fichaId);

  if (!ficha) {
    resultado.textContent = 'Ficha técnica não encontrada';
    return;
  }

  const custo = Number(
    ficha.custoTotal ||
    fichasService.calcularCustoTotal(ficha.ingredientes || [])
  );

  const rendimento = Number(
    ficha.rendimento ||
    fichasService.calcularRendimentoTeorico(ficha)
  );

  if (peso > 0 && rendimento > 0 && custo > 0) {
    const qtd = rendimento / peso;
    const custoDoce = custo / qtd;
    resultado.innerHTML =
      `→ <span>${money(custoDoce)}/doce</span> ` +
      `<small>(~${Math.floor(qtd)} doces de ${peso}g)</small>`;
  } else if (peso > 0 && rendimento <= 0) {
    resultado.textContent = 'Ficha sem rendimento válido';
  } else {
    resultado.textContent = '';
  }
}

function abrirNovoInsumoNaFicha(insumosService) {
  document.getElementById('ficha-modal-novo-insumo')?.remove();

  const tipos = insumosService?.obterTipos?.() || insumosService?.listarTipos?.() || [];
  const overlay = document.createElement('div');
  overlay.id = 'ficha-modal-novo-insumo';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;display:flex;align-items:center;justify-content:center;padding:1rem;';

  overlay.innerHTML = `
    <div style="background:#fff;border-radius:10px;padding:1.25rem;width:min(560px,95vw);max-height:90vh;overflow:auto;">
      <h3 style="margin-top:0;">Novo Insumo</h3>

      <div class="form-grid">
        <label>Nome *<input id="ficha-ni-nome"></label>
        <label>Marca *<input id="ficha-ni-marca"></label>

        <label>Tipo *
          <select id="ficha-ni-tipo">
            <option value="">Selecione...</option>
            ${tipos.map(t=>`<option value="${esc(t.id)}">${esc(t.nome)}</option>`).join('')}
          </select>
        </label>

        <label>Unidade *
          <select id="ficha-ni-unidade">
            <option value="">Selecione...</option>
            <option value="g">g (gramas)</option>
            <option value="kg">kg (quilogramas)</option>
            <option value="ml">ml (mililitros)</option>
            <option value="L">L (litros)</option>
            <option value="un">un (unidades)</option>
          </select>
        </label>

        <label>Qtd por embalagem
          <input id="ficha-ni-qtdemb" type="number" min="0" step="0.01">
        </label>

        <label>Nome da embalagem
          <input id="ficha-ni-nomeemb" placeholder="ex: pacote, caixa">
        </label>

        <label>Mínimo desejado
          <input id="ficha-ni-minimo" type="number" min="0" step="0.01">
        </label>
      </div>

      <label>Observações
        <textarea id="ficha-ni-obs"></textarea>
      </label>

      <div id="ficha-ni-erros" style="color:#b42318;margin-top:8px;"></div>

      <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px;">
        <button type="button" id="ficha-ni-cancelar" class="btn secondary">Cancelar</button>
        <button type="button" id="ficha-ni-salvar" class="btn">Adicionar insumo</button>
      </div>
    </div>`;

  document.body.appendChild(overlay);

  const fechar = () => overlay.remove();

  document.getElementById('ficha-ni-cancelar')?.addEventListener('click', fechar);
  overlay.addEventListener('click', event => {
    if (event.target === overlay) fechar();
  });

  document.getElementById('ficha-ni-salvar')?.addEventListener('click', () => {
    const payload = {
      nome: document.getElementById('ficha-ni-nome')?.value || '',
      marca: document.getElementById('ficha-ni-marca')?.value || '',
      tipo: document.getElementById('ficha-ni-tipo')?.value || '',
      unidade: document.getElementById('ficha-ni-unidade')?.value || '',
      qtdPorEmbalagem: Number(document.getElementById('ficha-ni-qtdemb')?.value || 0),
      nomeEmbalagem: document.getElementById('ficha-ni-nomeemb')?.value || '',
      minimoDesejado: Number(document.getElementById('ficha-ni-minimo')?.value || 0),
      observacoes: document.getElementById('ficha-ni-obs')?.value || '',
    };

    const retorno =
      insumosService?.adicionar?.(payload) ||
      insumosService?.create?.(payload);

    if (!retorno?.sucesso) {
      const erros = retorno?.erros || ['Não foi possível cadastrar o insumo.'];
      const erroEl = document.getElementById('ficha-ni-erros');
      if (erroEl) erroEl.textContent = erros.join(' | ');
      return;
    }

    const novo = retorno.insumo;
    const select = document.getElementById('ficha-insumo');

    if (select && novo) {
      const option = document.createElement('option');
      option.value = novo.id;
      option.dataset.unidade = novo.unidade || '';
      option.textContent = `${novo.nome}${novo.marca ? ` - ${novo.marca}` : ''} (${novo.unidade || ''})`;
      select.appendChild(option);
      select.value = String(novo.id);
      select.dispatchEvent(new Event('change'));
    }

    fechar();
  });

  setTimeout(() => document.getElementById('ficha-ni-nome')?.focus(), 50);
}

export function attachFichasHandlers(insumosService, estoqueService, rerender) {
  const form = document.getElementById('ficha-form');
  if (!form) return;

  document.getElementById('ficha-gerenciar-tipos')?.addEventListener('click', () => {
    abrirGerenciadorTipos(rerender);
  });

  document.getElementById('ficha-tipo')?.addEventListener('change', event => {
    const bloco = document.getElementById('bloco-base-ficha');
    if (bloco) bloco.style.display = ['doce','sobremesa'].includes(event.target.value) ? 'block' : 'none';
  });

  document.getElementById('ficha-calc-peso')?.addEventListener('input', atualizarCalculadora);
  document.getElementById('ficha-calc-ficha')?.addEventListener('change', atualizarCalculadora);

  document.getElementById('ficha-novo-insumo')?.addEventListener('click', () => {
    abrirNovoInsumoNaFicha(insumosService);
  });

  document.getElementById('ficha-insumo')?.addEventListener('change', event => {
    const option = event.target.options[event.target.selectedIndex];
    const unidade = option?.dataset?.unidade || '';
    const label = document.getElementById('lbl-ficha-ing-qtd');
    const input = document.getElementById('ficha-ing-qtd');

    if (label) {
      const inputHtml = input ? input.outerHTML : '';
      label.innerHTML = `${unidade ? `Quantidade (${unidade})` : 'Quantidade'}${inputHtml}`;
    }

    const refreshedInput = document.getElementById('ficha-ing-qtd');
    if (refreshedInput) {
      refreshedInput.step = ['kg','L'].includes(unidade) ? '0.001' : '0.01';
      refreshedInput.placeholder = unidade ? `em ${unidade}` : '0';
    }
  });

  const bindIngredienteActions = () => {
    document.querySelectorAll('.ficha-editar-ingrediente').forEach(button => {
      button.addEventListener('click', () => {
        state.ingredienteEditandoIndex = Number(button.dataset.index);
        refreshIngredientes();
        setTimeout(() => {
          const input = document.querySelector(`.ficha-edit-qtd[data-index="${state.ingredienteEditandoIndex}"]`);
          input?.focus();
          input?.select();
        }, 0);
      });
    });

    document.querySelectorAll('.ficha-confirmar-ingrediente').forEach(button => {
      button.addEventListener('click', () => {
        const index = Number(button.dataset.index);
        const input = document.querySelector(`.ficha-edit-qtd[data-index="${index}"]`);
        const quantidade = Number(input?.value || 0);
        if (quantidade <= 0) return alert('A quantidade deve ser maior que zero.');

        state.ingredientesTemporarios[index].quantidade = quantidade;
        state.ingredienteEditandoIndex = null;
        refreshIngredientes();
      });
    });

    document.querySelectorAll('.ficha-cancelar-edicao-ingrediente').forEach(button => {
      button.addEventListener('click', () => {
        state.ingredienteEditandoIndex = null;
        refreshIngredientes();
      });
    });

    document.querySelectorAll('.ficha-edit-qtd').forEach(input => {
      input.addEventListener('keydown', event => {
        if (event.key === 'Enter') {
          event.preventDefault();
          const index = Number(input.dataset.index);
          document.querySelector(`.ficha-confirmar-ingrediente[data-index="${index}"]`)?.click();
        }
        if (event.key === 'Escape') {
          event.preventDefault();
          document.querySelector('.ficha-cancelar-edicao-ingrediente')?.click();
        }
      });
    });

    document.querySelectorAll('.ficha-remove-ingrediente').forEach(button => {
      button.addEventListener('click', () => {
        state.ingredientesTemporarios.splice(Number(button.dataset.index), 1);
        state.ingredienteEditandoIndex = null;
        refreshIngredientes();
      });
    });
  };

  const refreshIngredientes = () => {
    const insumos = insumosService?.listar?.() || insumosService?.list?.() || [];
    const atual = document.getElementById('ficha-ingredientes-wrap');

    if (atual) {
      const holder = document.createElement('div');
      holder.innerHTML = renderIngredientes(insumos);
      const novo = holder.firstElementChild;
      if (novo) atual.replaceWith(novo);
    }

    const custo = fichasService.calcularCustoTotal(state.ingredientesTemporarios);
    const custoEl = document.getElementById('ficha-custo-total');
    if (custoEl) custoEl.textContent = money(custo);

    const bruto = pesoBruto(insumos);
    const rendimentoEl = document.getElementById('ficha-rendimento');
    if (rendimentoEl) rendimentoEl.value = bruto || '';

    bindIngredienteActions();
  };

  document.getElementById('ficha-add-ingrediente')?.addEventListener('click', () => {
    const selectInsumo = document.getElementById('ficha-insumo');
    const insumoId = selectInsumo?.value;
    const quantidade = Number(document.getElementById('ficha-ing-qtd')?.value || 0);
    const unidade = selectInsumo?.options?.[selectInsumo.selectedIndex]?.dataset?.unidade || '';

    if (!insumoId) return alert('Selecione um insumo.');
    if (quantidade <= 0) return alert('A quantidade deve ser maior que zero.');

    // Convenção canônica: a quantidade da ficha é informada na unidade-base
    // cadastrada do insumo. Ex.: farinha em kg -> informar 1 para 1 kg.
    if (['kg','L'].includes(unidade) && quantidade >= 100) {
      const confirma = confirm(
        `O insumo está cadastrado em ${unidade}. Você informou ${quantidade} ${unidade}. ` +
        `Para 1000 g, por exemplo, informe 1 kg. Deseja continuar com ${quantidade} ${unidade}?`
      );
      if (!confirma) return;
    }

    const atual = state.ingredientesTemporarios.find(i => String(i.insumoId) === String(insumoId));
    if (atual) {
      atual.quantidade += quantidade;
      atual.custoUnitario = custoInsumo(insumoId, estoqueService);
    } else {
      state.ingredientesTemporarios.push({
        insumoId,
        quantidade,
        custoUnitario: custoInsumo(insumoId, estoqueService),
      });
    }

    state.ingredienteEditandoIndex = null;
    const qtdInput = document.getElementById('ficha-ing-qtd');
    if (qtdInput) qtdInput.value = '';
    refreshIngredientes();
  });

  bindIngredienteActions();

  form.addEventListener('submit', event => {
    event.preventDefault();
    const fd = new FormData(form);
    const tipo = String(fd.get('tipo') || 'massa');
    const rendimento = fichasService.calcularRendimentoTeorico({
      ingredientes: state.ingredientesTemporarios,
    });

    const payload = {
      nome: fd.get('nome'),
      tipo,
      rendimento,
      unidadeMedida: 'g',
      ingredientes: state.ingredientesTemporarios,
      pesoPadraoDoce: null,
      baseId: ['doce','sobremesa'].includes(tipo) ? (fd.get('baseId') || null) : null,
      baseQuantidadeG: ['doce','sobremesa'].includes(tipo) ? Number(fd.get('baseQuantidadeG') || 0) || null : null,
      panelaReferencia: fd.get('panelaReferencia') || null,
      modoPreparo: fd.get('modoPreparo'),
      observacoes: fd.get('observacoes'),
    };

    if (['doce','sobremesa'].includes(tipo) && !payload.baseId) {
      return alert(`Selecione a base (massa/recheio/redução) para a ficha de ${tipo}`);
    }
    if (['doce','sobremesa'].includes(tipo) && (!payload.baseQuantidadeG || payload.baseQuantidadeG <= 0)) {
      return alert('Informe a quantidade de base por porção (g)');
    }

    let result = state.fichaEditandoId
      ? fichasService.editar(state.fichaEditandoId,payload)
      : fichasService.adicionar(payload);

    if (!result.sucesso && result.avisoNomeDuplicado && confirm(result.erros.join('\n'))) {
      result = state.fichaEditandoId
        ? fichasService.editar(state.fichaEditandoId,{...payload,forceAdd:true})
        : fichasService.adicionar({...payload,forceAdd:true});
    }

    if (!result.sucesso) return alert((result.erros || ['Falha ao salvar ficha.']).join('\n'));

    state.fichaEditandoId = null;
    state.ingredientesTemporarios = [];
    rerender();
  });

  document.getElementById('ficha-cancelar')?.addEventListener('click', () => {
    state.fichaEditandoId = null;
    state.ingredientesTemporarios = [];
    rerender();
  });

  document.querySelectorAll('.ficha-editar').forEach(button => {
    button.addEventListener('click', () => {
      const ficha = fichasService.buscarPorId(button.dataset.id);
      if (!ficha) return;
      state.fichaEditandoId = ficha.id;
      state.ingredientesTemporarios = ficha.ingredientes.map(ing => ({
        ...ing,
        custoUnitario: custoInsumo(ing.insumoId,estoqueService) || ing.custoUnitario,
      }));
      rerender();
    });
  });

  document.querySelectorAll('.ficha-excluir').forEach(button => {
    button.addEventListener('click', () => {
      if (!confirm('Deseja realmente excluir esta ficha técnica?')) return;
      fichasService.remover(button.dataset.id);
      state.fichaEditandoId = null;
      state.ingredientesTemporarios = [];
      rerender();
    });
  });

  atualizarCalculadora();
}
