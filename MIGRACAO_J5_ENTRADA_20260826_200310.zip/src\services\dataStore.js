import { loadFromStorage, saveToStorage } from './storage.js';

const backupUrl = './data/backup.json';
const defaultStore = {
  insumos: [],
  fornecedores: [],
  compras: [],
  fichas: [],
  producoes: [],
  estoque_itens: [],
  estoque_mov: [],
  montagens: [],
  encomendas: [],
  vendas: [],
  clientes: [],
  financeiro: [],
  cartoes: [],
};

export async function loadInitialData() {
  const persistedStore = loadFromStorage(defaultStore);
  const hasPersistedData = Object.keys(persistedStore).some(key => Array.isArray(persistedStore[key]) && persistedStore[key].length > 0);

  if (hasPersistedData) {
    return persistedStore;
  }

  try {
    const response = await fetch(backupUrl);
    if (!response.ok) {
      throw new Error('Não foi possível carregar o backup de dados.');
    }
    const payload = await response.json();
    const initialData = { ...defaultStore, ...(payload.data || {}) };
    saveToStorage(initialData);
    return initialData;
  } catch (error) {
    console.warn('Falha ao carregar dados iniciais:', error);
    saveToStorage(defaultStore);
    return defaultStore;
  }
}
