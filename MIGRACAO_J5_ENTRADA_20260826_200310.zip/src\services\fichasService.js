import { storageProvider } from './storage.js';

const num = value => Number.isFinite(Number(value)) ? Number(value) : 0;
const text = value => String(value ?? '').trim();

function id() {
  return globalThis.crypto?.randomUUID?.() ||
    `ficha_${Date.now()}_${Math.random().toString(36).slice(2,10)}`;
}

function syncSemipronto(fichaId, nome) {
  const itens = storageProvider.get('estoque-semiprontos') || [];
  const item = itens.find(i => String(i.fichaId) === String(fichaId));
  if (!item) return;
  item.fichaNome = nome;
  storageProvider.save('estoque-semiprontos', itens);
}

export const fichasService = {
  listar() {
    return storageProvider.get('fichas') || [];
  },

  salvar(fichas) {
    storageProvider.save('fichas', fichas);
  },

  buscarPorId(fichaId) {
    return this.listar().find(f => String(f.id) === String(fichaId)) || null;
  },

  validar(payload) {
    const erros = [];
    if (!text(payload?.nome)) erros.push('Nome é obrigatório');
    if (num(payload?.rendimento) <= 0) erros.push('Rendimento deve ser maior que zero');
    if (!payload?.ingredientes?.length) erros.push('Adicione pelo menos um ingrediente');

    (payload?.ingredientes || []).forEach((ing, index) => {
      if (!ing.insumoId) erros.push(`Ingrediente ${index + 1}: Insumo é obrigatório`);
      if (num(ing.quantidade) <= 0) erros.push(`Ingrediente ${index + 1}: Quantidade deve ser maior que zero`);
    });

    return erros;
  },

  calcularCustoTotal(ingredientes) {
    return (ingredientes || []).reduce(
      (total, ing) => total + num(ing.quantidade) * num(ing.custoUnitario),
      0,
    );
  },

  calcularCustoUnitario(custoTotal, rendimento) {
    return num(rendimento) > 0 ? num(custoTotal) / num(rendimento) : 0;
  },

  adicionar(payload) {
    const erros = this.validar(payload);
    if (erros.length) return { sucesso: false, erros };

    const fichas = this.listar();
    const nome = text(payload.nome);
    const panela = text(payload.panelaReferencia);

    const duplicada = fichas.find(f =>
      text(f.nome).toUpperCase() === nome.toUpperCase() &&
      text(f.panelaReferencia) === panela
    );

    if (duplicada && !payload.forceAdd) {
      return {
        sucesso: false,
        avisoNomeDuplicado: true,
        erros: [`Já existe uma ficha com este nome${panela ? ` para Panela ${panela}` : ''}. Confirme para salvar mesmo assim.`],
      };
    }

    const ingredientes = payload.ingredientes.map(ing => ({
      insumoId: ing.insumoId,
      quantidade: num(ing.quantidade),
      custoUnitario: num(ing.custoUnitario),
    }));

    const rendimento = num(payload.rendimento);
    const custoTotal = this.calcularCustoTotal(ingredientes);

    const ficha = {
      id: id(),
      nome,
      tipo: text(payload.tipo) || 'massa',
      rendimento,
      unidadeMedida: text(payload.unidadeMedida) || 'g',
      ingredientes,
      custoTotal,
      custoUnitario: this.calcularCustoUnitario(custoTotal, rendimento),
      pesoPadraoDoce: num(payload.pesoPadraoDoce) || null,
      baseId: payload.baseId || null,
      baseQuantidadeG: num(payload.baseQuantidadeG) || null,
      panelaReferencia: panela || null,
      modoPreparo: text(payload.modoPreparo),
      observacoes: text(payload.observacoes),
      criadoEm: new Date().toISOString(),
      atualizadoEm: null,
    };

    fichas.push(ficha);
    this.salvar(fichas);
    return { sucesso: true, ficha };
  },

  editar(fichaId, payload) {
    const erros = this.validar(payload);
    if (erros.length) return { sucesso: false, erros };

    const fichas = this.listar();
    const index = fichas.findIndex(f => String(f.id) === String(fichaId));
    if (index < 0) return { sucesso: false, erros: ['Ficha não encontrada'] };

    const anterior = fichas[index];
    const ingredientes = payload.ingredientes.map(ing => ({
      insumoId: ing.insumoId,
      quantidade: num(ing.quantidade),
      custoUnitario: num(ing.custoUnitario),
    }));

    const rendimento = num(payload.rendimento);
    const custoTotal = this.calcularCustoTotal(ingredientes);
    const panela = text(payload.panelaReferencia) || null;

    fichas[index] = {
      ...anterior,
      nome: text(payload.nome),
      tipo: text(payload.tipo) || anterior.tipo || 'massa',
      rendimento,
      unidadeMedida: text(payload.unidadeMedida) || 'g',
      ingredientes,
      custoTotal,
      custoUnitario: this.calcularCustoUnitario(custoTotal, rendimento),
      pesoPadraoDoce: num(payload.pesoPadraoDoce) || null,
      baseId: payload.baseId || null,
      baseQuantidadeG: num(payload.baseQuantidadeG) || null,
      panelaReferencia: panela,
      modoPreparo: text(payload.modoPreparo),
      observacoes: text(payload.observacoes),
      atualizadoEm: new Date().toISOString(),
    };

    this.salvar(fichas);

    if (anterior.nome !== fichas[index].nome || anterior.panelaReferencia !== panela) {
      syncSemipronto(
        fichaId,
        `${fichas[index].nome}${panela ? ` — Panela ${panela}` : ''}`,
      );
    }

    return { sucesso: true, ficha: fichas[index] };
  },

  remover(fichaId) {
    const fichas = this.listar();
    this.salvar(fichas.filter(f => String(f.id) !== String(fichaId)));
    return { sucesso: true };
  },

  calcularRendimentoTeorico(ficha) {
    return Math.round((ficha?.ingredientes || []).reduce(
      (total, ing) => total + num(ing.quantidade),
      0,
    ) * 1000) / 1000;
  },

  calcularQtdDoces(ficha, rendimentoReal) {
    const peso = num(ficha?.pesoPadraoDoce);
    if (peso <= 0) return null;
    return num(rendimentoReal) > 0 ? Math.floor(num(rendimentoReal) / peso) : 0;
  },

  listarParaSelect() {
    return this.listar().map(f => ({
      id: f.id,
      nome: f.nome,
      rendimento: f.rendimento,
      unidadeMedida: f.unidadeMedida,
      custoUnitario: f.custoUnitario,
      panelaReferencia: f.panelaReferencia || null,
    }));
  },
};