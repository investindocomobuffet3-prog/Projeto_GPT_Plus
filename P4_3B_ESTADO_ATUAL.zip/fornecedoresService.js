import { v4 as uuidv4 } from './uuid.js';
import { saveToStorage } from './storage.js';

function texto(value) {
  return String(value || '').trim();
}

function documento(value) {
  return texto(value).replace(/\D/g, '');
}

export function createFornecedoresService(data) {
  if (!Array.isArray(data.fornecedores)) {
    data.fornecedores = [];
  }

  function list() {
    return data.fornecedores;
  }

  function getById(id) {
    return list().find(
      item => String(item.id) === String(id)
    ) || null;
  }

  function validar(payload = {}) {
    const erros = [];

    if (!texto(payload.nome)) {
      erros.push('Nome é obrigatório');
    }

    if (!texto(payload.cnpj)) {
      erros.push('CNPJ ou CPF é obrigatório');
    } else {
      const digits = documento(payload.cnpj);

      if (digits.length !== 11 && digits.length !== 14) {
        erros.push(
          'CNPJ deve ter 14 dígitos ou CPF deve ter 11 dígitos'
        );
      }
    }

    if (
      texto(payload.email) &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(texto(payload.email))
    ) {
      erros.push('Email inválido');
    }

    return erros;
  }

  function existeDuplicado(nome, ignorarId = null) {
    const alvo = texto(nome).toLowerCase();

    return list().some(item => {
      if (
        ignorarId &&
        String(item.id) === String(ignorarId)
      ) {
        return false;
      }

      return texto(item.nome).toLowerCase() === alvo;
    });
  }

  function existeCNPJDuplicado(cnpj, ignorarId = null) {
    const alvo = documento(cnpj);

    if (!alvo) return false;

    return list().some(item => {
      if (
        ignorarId &&
        String(item.id) === String(ignorarId)
      ) {
        return false;
      }

      return documento(item.cnpj) === alvo;
    });
  }

  function create(payload = {}) {
    const erros = validar(payload);

    if (erros.length) {
      return { sucesso: false, erros };
    }

    if (existeDuplicado(payload.nome)) {
      return {
        sucesso: false,
        erros: ['Já existe um fornecedor com este nome'],
      };
    }

    if (existeCNPJDuplicado(payload.cnpj)) {
      return {
        sucesso: false,
        erros: ['CNPJ já cadastrado'],
      };
    }

    const fornecedor = {
      id: payload.id || uuidv4(),
      nome: texto(payload.nome),
      cnpj: texto(payload.cnpj),
      contato: texto(payload.contato),
      telefone: texto(payload.telefone),
      email: texto(payload.email),
      endereco: texto(payload.endereco),
      observacoes: texto(payload.observacoes),
      criadoEm: new Date().toISOString(),
    };

    data.fornecedores.push(fornecedor);
    persist();

    return {
      sucesso: true,
      fornecedor,
    };
  }

  function update(id, payload = {}) {
    const erros = validar(payload);

    if (erros.length) {
      return { sucesso: false, erros };
    }

    const index = list().findIndex(
      item => String(item.id) === String(id)
    );

    if (index === -1) {
      return {
        sucesso: false,
        erros: ['Fornecedor não encontrado'],
      };
    }

    if (existeDuplicado(payload.nome, id)) {
      return {
        sucesso: false,
        erros: ['Já existe um fornecedor com este nome'],
      };
    }

    if (existeCNPJDuplicado(payload.cnpj, id)) {
      return {
        sucesso: false,
        erros: ['CNPJ já cadastrado'],
      };
    }

    data.fornecedores[index] = {
      ...data.fornecedores[index],
      nome: texto(payload.nome),
      cnpj: texto(payload.cnpj),
      contato: texto(payload.contato),
      telefone: texto(payload.telefone),
      email: texto(payload.email),
      endereco: texto(payload.endereco),
      observacoes: texto(payload.observacoes),
      atualizadoEm: new Date().toISOString(),
    };

    persist();

    return {
      sucesso: true,
      fornecedor: data.fornecedores[index],
    };
  }

  function remove(id) {
    data.fornecedores = list().filter(
      item => String(item.id) !== String(id)
    );

    persist();

    return { sucesso: true };
  }

  function listarParaSelect() {
    return list().map(item => ({
      id: item.id,
      nome: item.nome,
    }));
  }

  function persist() {
    saveToStorage({
      fornecedores: data.fornecedores,
    });
  }

  return {
    list,
    getById,
    validar,
    create,
    update,
    remove,
    listarParaSelect,
    existeDuplicado,
    existeCNPJDuplicado,
  };
}