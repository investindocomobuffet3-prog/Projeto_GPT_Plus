import { MULTIUSER_FLAGS } from '../config/multiuser.js';
import { CentralStore } from './centralStore.js';

const central = new CentralStore(MULTIUSER_FLAGS.apiBase);

function fireAndForget(task, label) {
  Promise.resolve()
    .then(task)
    .catch(error => {
      console.warn(`[P4.3B:${label}] shadow write pendente`, error);
    });
}

async function upsertShadow(entity, record) {
  if (!record || !record.id) return;

  try {
    const current = await central.get(entity, record.id);

    await central.update(entity, {
      ...record,
      _version: current._version
    });
  } catch (error) {
    if (error?.status === 404) {
      await central.create(entity, record);
      return;
    }

    throw error;
  }
}

async function removeShadow(entity, id) {
  if (!id) return;

  try {
    const current = await central.get(entity, id);
    await central.remove(entity, id, current._version);
  } catch (error) {
    if (error?.status !== 404) {
      throw error;
    }
  }
}

function findRecord(service, id) {
  if (!id) return null;

  if (typeof service.getById === 'function') {
    return service.getById(id);
  }

  const list =
    typeof service.list === 'function'
      ? service.list()
      : typeof service.listar === 'function'
        ? service.listar()
        : [];

  return Array.isArray(list)
    ? list.find(item => String(item?.id) === String(id)) || null
    : null;
}

export function withShadowWrite(baseService, entity) {
  if (!baseService || typeof baseService !== 'object') {
    return baseService;
  }

  const wrapped = Object.create(baseService);

  if (typeof baseService.create === 'function') {
    wrapped.create = (...args) => {
      const result = baseService.create(...args);

      if (MULTIUSER_FLAGS.shadowWrite) {
        const id = result?.id ?? args[0]?.id;
        const record = result?.id ? result : findRecord(baseService, id);

        fireAndForget(
          () => upsertShadow(entity, record),
          `${entity}:create`
        );
      }

      return result;
    };
  }

  if (typeof baseService.update === 'function') {
    wrapped.update = (id, ...rest) => {
      const result = baseService.update(id, ...rest);

      if (MULTIUSER_FLAGS.shadowWrite) {
        const record =
          result?.id
            ? result
            : findRecord(baseService, id);

        fireAndForget(
          () => upsertShadow(entity, record),
          `${entity}:update`
        );
      }

      return result;
    };
  }

  if (typeof baseService.remove === 'function') {
    wrapped.remove = (id, ...rest) => {
      const result = baseService.remove(id, ...rest);

      if (MULTIUSER_FLAGS.shadowWrite) {
        fireAndForget(
          () => removeShadow(entity, id),
          `${entity}:remove`
        );
      }

      return result;
    };
  }

  return wrapped;
}