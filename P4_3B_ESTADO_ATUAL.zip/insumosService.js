import { storageProvider } from './storage.js';

const TIPOS_KEY = 'insumos_tipos_custom';
const EMBALAGENS_KEY = 'insumos_embalagens_custom';

const EMBALAGENS_PADRAO = [
  'Caixa',
  'Pacote',
  'Saco',
  'Pote',
  'Frasco',
  'Garrafa',
  'Lata',
  'Balde',
  'Bandeja',
  'Rolo',
  'Unidade',
];

const TIPOS_PADRAO = [
  { id: 'materia-prima', nome: 'Matéria-prima' },
  { id: 'embalagem', nome: 'Embalagem' },
  { id: 'acessorio', nome: 'Acessório / Utensílio' },
  { id: 'limpeza', nome: 'Limpeza / Higiene' },
  { id: 'administrativo', nome: 'Administrativo' },
  { id: 'outro', nome: 'Outro' },
];

function generateId() {
  return `${Date.now()}-${Math.random()
    .toString(36)
    .substr(2, 9)}`;
}

function texto(value) {
  return String(value || '').trim();
}

function slug(value) {
  return texto(value)
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function createInsumosService() {
  function listarRaw() {
    return storageProvider.get('insumos') || [];
  }

  function salvar(lista) {
    storageProvider.save('insumos', lista);
  }

  function carregarTiposCustomizados() {
    return storageProvider.get(TIPOS_KEY) || [];
  }

  function salvarTiposCustomizados(lista) {
    storageProvider.save(TIPOS_KEY, lista);
  }

  function obterTipos() {
    return [
      ...TIPOS_PADRAO,
      ...carregarTiposCustomizados(),
    ];
  }

  function adicionarTipoCustomizado(nome) {
    const valor = texto(nome);

    if (!valor) {
      return null;
    }

    const id = slug(valor);

    const existente =
      obterTipos().find(
        item => item.id === id
      );

    if (existente) {
      return existente;
    }

    const tipo = {
      id,
      nome: valor,
    };

    const personalizados =
      carregarTiposCustomizados();

    personalizados.push(tipo);

    salvarTiposCustomizados(
      personalizados
    );

    return tipo;
  }

  function carregarEmbalagensCustomizadas() {
    return storageProvider.get(EMBALAGENS_KEY) || [];
  }

  function salvarEmbalagensCustomizadas(lista) {
    storageProvider.save(
      EMBALAGENS_KEY,
      lista
    );
  }

  function obterEmbalagens() {
    const todas = [
      ...EMBALAGENS_PADRAO,
      ...carregarEmbalagensCustomizadas(),
    ];

    return [...new Set(
      todas
        .map(item => texto(item))
        .filter(Boolean)
    )].sort(
      (a, b) =>
        a.localeCompare(
          b,
          'pt-BR'
        )
    );
  }

  function adicionarEmbalagemCustomizada(nome) {
    const valor = texto(nome);

    if (!valor) {
      return null;
    }

    const existente =
      obterEmbalagens().find(
        item =>
          item.localeCompare(
            valor,
            'pt-BR',
            {
              sensitivity: 'base',
            }
          ) === 0
      );

    if (existente) {
      return existente;
    }

    const personalizadas =
      carregarEmbalagensCustomizadas();

    personalizadas.push(valor);

    salvarEmbalagensCustomizadas(
      personalizadas
    );

    return valor;
  }
  function listar() {
    return [...listarRaw()].sort(
      (a, b) =>
        String(a.nome || '')
          .localeCompare(
            String(b.nome || ''),
            'pt-BR'
          )
    );
  }

  function buscarPorId(id) {
    const alvo = String(id);

    return listarRaw().find(
      item =>
        String(item.id) === alvo
    ) || null;
  }

  function existeDuplicado(
    payload,
    ignorarId = null
  ) {
    const nome =
      texto(payload.nome)
        .toLowerCase();

    const marca =
      texto(payload.marca)
        .toLowerCase();

    const tipo =
      texto(payload.tipo);

    const unidade =
      texto(payload.unidade);

    return listarRaw().some(
      item => {

        if (
          ignorarId &&
          String(item.id) ===
            String(ignorarId)
        ) {
          return false;
        }

        return (
          texto(item.nome)
            .toLowerCase() === nome &&
          texto(item.marca)
            .toLowerCase() === marca &&
          texto(item.tipo) === tipo &&
          texto(item.unidade) ===
            unidade
        );
      }
    );
  }

  function validar(payload = {}) {
    const erros = [];

    if (!texto(payload.nome)) {
      erros.push('Nome é obrigatório');
    }

    if (!texto(payload.marca)) {
      erros.push('Marca é obrigatória');
    }

    if (!texto(payload.unidade)) {
      erros.push('Unidade é obrigatória');
    }

    if (!texto(payload.tipo)) {
      erros.push('Tipo é obrigatório');
    }

    const qtd =
      Number(
        payload.qtdPorEmbalagem || 0
      );

    const minimo =
      Number(
        payload.minimoDesejado || 0
      );

    if (
      payload.qtdPorEmbalagem &&
      qtd <= 0
    ) {
      erros.push(
        'Quantidade por embalagem deve ser maior que zero'
      );
    }

    if (
      payload.minimoDesejado &&
      minimo <= 0
    ) {
      erros.push(
        'Mínimo desejado deve ser maior que zero'
      );
    }

    return erros;
  }

  function adicionar(payload) {
    const erros =
      validar(payload);

    if (erros.length > 0) {
      return {
        sucesso: false,
        erros,
      };
    }

    if (existeDuplicado(payload)) {
      return {
        sucesso: false,
        erros: [
          'Já existe um insumo com este Nome, Marca, Tipo e Unidade.',
        ],
      };
    }

    const item = {
      id: generateId(),
      nome: texto(payload.nome),
      marca: texto(payload.marca),
      tipo: texto(payload.tipo),
      unidade: texto(payload.unidade),
      qtdPorEmbalagem:
        Number(
          payload.qtdPorEmbalagem || 0
        ),
      nomeEmbalagem:
        texto(payload.nomeEmbalagem),
      minimoDesejado:
        Number(
          payload.minimoDesejado || 0
        ),
      observacoes:
        texto(payload.observacoes),
      criadoEm:
        new Date().toISOString(),
    };

    const lista =
      listarRaw();

    lista.push(item);

    salvar(lista);

    return {
      sucesso: true,
      insumo: item,
    };
  }

  function editar(id, payload) {
    const erros =
      validar(payload);

    if (erros.length > 0) {
      return {
        sucesso: false,
        erros,
      };
    }

    const lista =
      listarRaw();

    const index =
      lista.findIndex(
        item =>
          String(item.id) ===
          String(id)
      );

    if (index === -1) {
      return {
        sucesso: false,
        erros: [
          'Insumo não encontrado',
        ],
      };
    }

    if (
      existeDuplicado(
        payload,
        id
      )
    ) {
      return {
        sucesso: false,
        erros: [
          'Já existe um insumo com este Nome, Marca, Tipo e Unidade.',
        ],
      };
    }

    lista[index] = {
      ...lista[index],
      nome: texto(payload.nome),
      marca: texto(payload.marca),
      tipo: texto(payload.tipo),
      unidade: texto(payload.unidade),
      qtdPorEmbalagem:
        Number(
          payload.qtdPorEmbalagem || 0
        ),
      nomeEmbalagem:
        texto(payload.nomeEmbalagem),
      minimoDesejado:
        Number(
          payload.minimoDesejado || 0
        ),
      observacoes:
        texto(payload.observacoes),
      atualizadoEm:
        new Date().toISOString(),
    };

    salvar(lista);

    return {
      sucesso: true,
      insumo: lista[index],
    };
  }

  function remover(id) {
    salvar(
      listarRaw().filter(
        item =>
          String(item.id) !==
          String(id)
      )
    );

    return {
      sucesso: true,
    };
  }

  function listarParaSelect({
    categoria,
  } = {}) {
    return listar()
      .filter(
        item =>
          !categoria ||
          item.tipo === categoria
      )
      .map(
        item => ({
          id: item.id,
          nome: item.nome,
          unidade: item.unidade,
          marca: item.marca,
          tipoId: item.tipo,
        })
      );
  }

  return {
    list: listar,
    listar,
    getById: buscarPorId,
    buscarPorId,

    listarTipos: obterTipos,
    obterTipos,

    adicionarTipo:
      adicionarTipoCustomizado,
    adicionarTipoCustomizado,

    listarEmbalagens: obterEmbalagens,
    obterEmbalagens,

    adicionarEmbalagem:
      adicionarEmbalagemCustomizada,
    adicionarEmbalagemCustomizada,

    validar,
    existeDuplicado,

    create: adicionar,
    adicionar,

    update: editar,
    editar,

    remove: remover,
    remover,

    listarParaSelect,
  };
}