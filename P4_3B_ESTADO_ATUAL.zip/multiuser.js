export const MULTIUSER_FLAGS = Object.freeze({
  enabled: false,
  mode: 'local-first',
  centralRead: false,
  centralWrite: false,
  shadowWrite: true,
  failOpenLocal: true,
  conflictPolicy: 'optimistic-version',
  apiBase: ''
});

export function isMultiuserEnabled() {
  return MULTIUSER_FLAGS.enabled === true;
}